k=1;
[COEFF SCORE latent]=pca(Tnew1);
pcaData1=SCORE(:,1:k);
plot(time,pcaData1)
hold on
[COEFF SCORE latent]=pca(Tnew2);
pcaData2=SCORE(:,1:k);
plot(time,pcaData2)
hold on
[COEFF SCORE latent]=pca(Tnew3);
pcaData3=SCORE(:,1:k);
plot(time,pcaData3)
hold on
[COEFF SCORE latent]=pca(Tnew4);
pcaData4=SCORE(:,1:k);
plot(time,pcaData4)
hold on
[COEFF SCORE latent]=pca(Tnew5);
pcaData5=SCORE(:,1:k);
plot(time,pcaData5)
hold on
[COEFF SCORE latent]=pca(Tnew6);
pcaData6=SCORE(:,1:k);
plot(time,pcaData6)
hold on
[COEFF SCORE latent]=pca(Tnew7);
pcaData7=SCORE(:,1:k);
plot(time,pcaData7)
hold on
[COEFF SCORE latent]=pca(Tnew8);
pcaData8=SCORE(:,1:k);
plot(time,pcaData8)
hold on
[COEFF SCORE latent]=pca(Tnew9);
pcaData9=SCORE(:,1:k);
plot(time,pcaData9)
hold on
[COEFF SCORE latent]=pca(Tnew10);
pcaData10=SCORE(:,1:k);
plot(time,pcaData10)
legend(pattern{1},pattern{2},pattern{3},pattern{4},pattern{5},pattern{6},pattern{7}...
    ,pattern{8},pattern{9},pattern{10})
xlabel('Day')
ylabel('Hedonic Closed Price($)')