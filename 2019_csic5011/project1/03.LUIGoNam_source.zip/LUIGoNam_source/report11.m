
%%mini porject for CSIC5011 by Go Nam
% pattern = {"Industrials", "Financials","Health Care","Information Technology","Telecommunications Services"...
%     ,"Materials","Consumer Staples","Consumer Discretionary","Energy","Utilities"};% save all the class as a cell

a=1;
data = zeros(1258,74);
time  = linspace(1,1258,1258);
T = zeros(10,10);
q = zeros(1,i);
Tnew = zeros(1258,452);
%Categorize the data by class
for i = 1:10
    a = 1;
  for k = 1:452%each component
     
    TF = contains(stock{k}.class,pattern{i});
  if  TF == 1    
        T(a,i) = k;%storing the indices for different categories.
           a= a + 1;
  end
  end
  q(1,i) = a-1;
i = i+1;
end
X(:,1);
qt = q(1,1:10);
bar(qt);
hold on 
set(gca, 'XTickLabel',{pattern{1},pattern{2},pattern{3},pattern{4},pattern{5},pattern{6},pattern{7},pattern{8},pattern{9},pattern{10}},...
    'Fontname', 'Times New Roman', 'Fontsize', 8)
xlabel('Industry Categories')
ylabel('Number of Companies')
 for i  = 1:74%Industrials
     
     p = T(i,10);
     if p == 0
        break
     end     
      Tnew(:,i) = X(:,p);

 end                           

