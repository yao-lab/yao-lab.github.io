### Name: ram
### Title: RAM Matrix for a Structural-Equation Model
### Aliases: ram
### Keywords: models

### ** Examples


# ------------- assumes that Duncan, Haller and Portes peer-influences model
# -------------     has been fit and is in sem.dhp

    ## Not run: 
##D ram(sem.dhp)
##D 
##D ##        heads to from parameter  estimate                arrow
##D ##            1  1   11         0  1.000000 ROccAsp <--- RGenAsp
##D ## lam21      1  2   11         1  1.062673  REdAsp <--- RGenAsp
##D ##            1  3   12         0  1.000000 FOccAsp <--- FGenAsp
##D ## lam42      1  4   12         2  0.929732  FEdAsp <--- FGenAsp
##D ## gam11      1 11    5         3  0.161220 RGenAsp <--- RParAsp
##D ## gam12      1 11    6         4  0.249647     RGenAsp <--- RIQ
##D ## gam13      1 11    7         5  0.218402    RGenAsp <--- RSES
##D ## gam14      1 11    8         6  0.071836    RGenAsp <--- FSES
##D ## gam23      1 12    7         7  0.061879    FGenAsp <--- RSES
##D ## gam24      1 12    8         8  0.228863    FGenAsp <--- FSES
##D ## gam25      1 12    9         9  0.349030     FGenAsp <--- FIQ
##D ## gam26      1 12   10        10  0.159529 FGenAsp <--- FParAsp
##D ## beta12     1 11   12        11  0.184245 RGenAsp <--- FGenAsp
##D ## beta21     1 12   11        12  0.235502 FGenAsp <--- RGenAsp
##D ## theta1     2  1    1        13  0.412143 ROccAsp <--> ROccAsp
##D ## theta2     2  2    2        14  0.336146   REdAsp <--> REdAsp
##D ## theta3     2  3    3        15  0.311197 FOccAsp <--> FOccAsp
##D ## theta4     2  4    4        16  0.404601   FEdAsp <--> FEdAsp
##D ## psi11      2 11   11        17  0.280987 RGenAsp <--> RGenAsp
##D ## psi22      2 12   12        18  0.263832 FGenAsp <--> FGenAsp
##D ## psi12      2 11   12        19 -0.022620 RGenAsp <--> FGenAsp
##D ##            2  5    5         0  1.000000 RParAsp <--> RParAsp
##D ##            2  6    5         0  0.183900     RIQ <--> RParAsp
##D ##            2  6    6         0  1.000000         RIQ <--> RIQ
##D ##            2  7    5         0  0.048900    RSES <--> RParAsp
##D ##            2  7    6         0  0.222000        RSES <--> RIQ
##D ##            2  7    7         0  1.000000       RSES <--> RSES
##D ##            2  8    5         0  0.018600    FSES <--> RParAsp
##D ##            2  8    6         0  0.186100        FSES <--> RIQ
##D ##            2  8    7         0  0.270700       FSES <--> RSES
##D ##            2  8    8         0  1.000000       FSES <--> FSES
##D ##            2  9    5         0  0.078200     FIQ <--> RParAsp
##D ##            2  9    6         0  0.335500         FIQ <--> RIQ
##D ##            2  9    7         0  0.230200        FIQ <--> RSES
##D ##            2  9    8         0  0.295000        FIQ <--> FSES
##D ##            2  9    9         0  1.000000         FIQ <--> FIQ
##D ##            2 10    5         0  0.114700 FParAsp <--> RParAsp
##D ##            2 10    6         0  0.102100     FParAsp <--> RIQ
##D ##            2 10    7         0  0.093100    FParAsp <--> RSES
##D ##            2 10    8         0 -0.043800    FParAsp <--> FSES
##D ##            2 10    9         0  0.208700     FParAsp <--> FIQ
##D ##            2 10   10         0  1.000000 FParAsp <--> FParAsp
##D     
## End(Not run)



