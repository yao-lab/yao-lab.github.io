### Name: boot.sem
### Title: Bootstrap a Structural Equation Model
### Aliases: boot.sem print.bootsem summary.bootsem
### Keywords: htest models

### ** Examples

    ## Not run: 
##D 
##D # A simple confirmatory factor-analysis model using polychoric correlations.
##D #  The polycor package is required for the hetcor function.
##D 
##D library(polycor)
##D 
##D # The following function returns correlations computed by hetcor,
##D #   and is used for the bootstrapping.
##D 
##D hcor <- function(data) hetcor(data, std.err=FALSE)$correlations
##D 
##D model.cnes <- specify.model()
##D F -> MBSA2, lam1, NA
##D F -> MBSA7, lam2, NA
##D F -> MBSA8, lam3, NA
##D F -> MBSA9, lam4, NA
##D F <-> F, NA, 1
##D MBSA2 <-> MBSA2, the1, NA
##D MBSA7 <-> MBSA7, the2, NA
##D MBSA8 <-> MBSA8, the3, NA
##D MBSA9 <-> MBSA9, the4, NA
##D 
##D data(CNES)
##D R.cnes <- hcor(CNES)
##D 
##D sem.cnes <- sem(model.cnes, R.cnes, N=1529)
##D summary(sem.cnes)
##D 
##D #  Note: this can take a couple of minutes:
##D 
##D system.time(boot.cnes <- boot.sem(CNES, sem.cnes, R=100, cov=hcor), gcFirst=TRUE)
##D summary(boot.cnes, type="norm")  
##D # cf., standard errors to those computed by summary(sem.cnes)
##D 
##D     
## End(Not run)



