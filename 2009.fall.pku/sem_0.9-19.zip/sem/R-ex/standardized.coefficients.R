### Name: standardized.coefficients
### Title: Standardized Coefficients for Structural Equation Models
### Aliases: standardized.coefficients std.coef
### Keywords: models

### ** Examples


# ------------- assumes that Duncan, Haller and Portes peer-influences model
# -------------     has been fit and is in sem.dhp.1     
## Not run: 
##D standardized.coefficients(sem.dhp.1) 
##D 
##D ##           Std. Estimate                     
##D           Std. Estimate                     
##D ## 1  gam11   0.210278     RGenAsp <--- RParAsp
##D ## 2  gam12   0.325612     RGenAsp <--- RIQ    
##D ## 3  gam13   0.284855     RGenAsp <--- RSES   
##D ## 4  gam14   0.093702     RGenAsp <--- FSES   
##D ## 5  gam23   0.074576     FGenAsp <--- RSES   
##D ## 6  gam24   0.275763     FGenAsp <--- FSES   
##D ## 7  gam25   0.420558     FGenAsp <--- FIQ    
##D ## 8  gam26   0.192224     FGenAsp <--- FParAsp
##D ## 9  beta12  0.199418     RGenAsp <--- FGenAsp
##D ## 10 beta21  0.217521     FGenAsp <--- RGenAsp
##D ## 11         0.766717     ROccAsp <--- RGenAsp
##D ## 12 lam21   0.814771     REdAsp <--- RGenAsp 
##D ## 13         0.829943     FOccAsp <--- FGenAsp
##D ## 14 lam42   0.771619     FEdAsp <--- FGenAsp 
##D ## 15 ps11    0.477987     RGenAsp <--> RGenAsp
##D ## 16 ps22    0.383036     FGenAsp <--> FGenAsp
##D ## 17 ps12   -0.035518     FGenAsp <--> RGenAsp
##D ## 18 theta1  0.412144     ROccAsp <--> ROccAsp
##D ## 19 theta2  0.336148     REdAsp <--> REdAsp  
##D ## 20 theta3  0.311194     FOccAsp <--> FOccAsp
##D ## 21 theta4  0.404603     FEdAsp <--> FEdAsp  
##D ## 22         1.000000     RParAsp <--> RParAsp
##D ## 23         0.183900     RIQ <--> RParAsp    
##D ## 24         1.000000     RIQ <--> RIQ        
##D ## 25         0.048900     RSES <--> RParAsp   
##D ## 26         0.222000     RSES <--> RIQ       
##D ## 27         1.000000     RSES <--> RSES      
##D ## 28         0.018600     FSES <--> RParAsp   
##D ## 29         0.186100     FSES <--> RIQ       
##D ## 30         0.270700     FSES <--> RSES      
##D ## 31         1.000000     FSES <--> FSES      
##D ## 32         0.078200     FIQ <--> RParAsp    
##D ## 33         0.335500     FIQ <--> RIQ        
##D ## 34         0.230200     FIQ <--> RSES       
##D ## 35         0.295000     FIQ <--> FSES       
##D ## 36         1.000000     FIQ <--> FIQ        
##D ## 37         0.114700     FParAsp <--> RParAsp
##D ## 38         0.102100     FParAsp <--> RIQ    
##D ## 39         0.093100     FParAsp <--> RSES   
##D ## 40        -0.043800     FParAsp <--> FSES   
##D ## 41         0.208700     FParAsp <--> FIQ    
##D ## 42         1.000000     FParAsp <--> FParAsp
##D     
## End(Not run)



