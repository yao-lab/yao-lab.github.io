### Name: tsls
### Title: Two-Stage Least Squares
### Aliases: tsls tsls.formula tsls.default fitted.tsls residuals.tsls
###   coef.tsls vcov.tsls anova.tsls print.tsls summary.tsls
### Keywords: models

### ** Examples

data(Kmenta)
summary(tsls(Q ~ P + D, ~ D + F + A, data=Kmenta))     # demand equation

##  2SLS Estimates
##  
##  Model Formula: Q ~ P + D
##  
##  Instruments: ~D + F + A
##  
##  Residuals:
##      Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
##  -3.43e+00 -1.24e+00 -1.89e-01 -2.49e-13  1.58e+00  2.49e+00 
##  
##              Estimate Std. Error t value  Pr(>|t|)
##  (Intercept)  94.6333    7.92084  11.947 1.076e-09
##  P            -0.2436    0.09648  -2.524 2.183e-02
##  D             0.3140    0.04694   6.689 3.811e-06
##  
##  Residual standard error: 1.9663 on 17 degrees of freedom

summary(tsls(Q ~ P + F + A, ~ D + F + A, data=Kmenta)) # supply equation

##  2SLS Estimates
##  
##  Model Formula: Q ~ P + F + A
##  
##  Instruments: ~D + F + A
##  
##  Residuals:
##      Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
##  -4.87e+00 -1.26e+00  6.42e-01 -5.64e-12  1.47e+00  3.49e+00 
##  
##              Estimate Std. Error t value  Pr(>|t|)
##  (Intercept)  49.5324   12.01053   4.124 7.954e-04
##  P             0.2401    0.09993   2.402 2.878e-02
##  F             0.2556    0.04725   5.410 5.785e-05
##  A             0.2529    0.09966   2.538 2.193e-02
##  
##  Residual standard error: 2.4576 on 16 degrees of freedom

anova(tsls(Q ~ P + F + A, ~ D + F + A, data=Kmenta),
    tsls(Q ~ 1, ~ D + F + A, data=Kmenta))
##    
##  Analysis of Variance
##    
##  Model 1:  Q ~ P + F + A   Instruments: ~D + F + A
##  Model 2:  Q ~ 1   Instruments: ~D + F + A
##    
##          Res.Df     RSS Df Sum of Sq      F    Pr(>F)    
##  Model 1     16  96.633                                  
##  Model 2     19 268.114  3   171.481 9.4643 0.0007834 ***
##  ---
##  Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1 




