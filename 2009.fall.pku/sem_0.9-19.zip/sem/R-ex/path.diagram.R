### Name: path.diagram
### Title: Draw Path Diagram
### Aliases: path.diagram path.diagram.sem
### Keywords: dplot models

### ** Examples

        ## Not run: 
##D # The Duncan, Haller, and Portes Peer-Influences Model
##D 
##D R.DHP <- read.moments(diag=FALSE, names=c('ROccAsp', 'REdAsp', 'FOccAsp', 
##D                 'FEdAsp', 'RParAsp', 'RIQ', 'RSES', 'FSES', 'FIQ', 'FParAsp'))
##D     .6247                                                              
##D     .3269  .3669                                                        
##D     .4216  .3275  .6404                                      
##D     .2137  .2742  .1124  .0839                                
##D     .4105  .4043  .2903  .2598  .1839                          
##D     .3240  .4047  .3054  .2786  .0489  .2220                    
##D     .2930  .2407  .4105  .3607  .0186  .1861  .2707              
##D     .2995  .2863  .5191  .5007  .0782  .3355  .2302  .2950        
##D     .0760  .0702  .2784  .1988  .1147  .1021  .0931 -.0438  .2087  
##D 
##D model.dhp <- specify.model()
##D     RParAsp  -> RGenAsp, gam11,  NA
##D     RIQ      -> RGenAsp, gam12,  NA
##D     RSES     -> RGenAsp, gam13,  NA
##D     FSES     -> RGenAsp, gam14,  NA
##D     RSES     -> FGenAsp, gam23,  NA
##D     FSES     -> FGenAsp, gam24,  NA
##D     FIQ      -> FGenAsp, gam25,  NA
##D     FParAsp  -> FGenAsp, gam26,  NA
##D     FGenAsp  -> RGenAsp, beta12, NA
##D     RGenAsp  -> FGenAsp, beta21, NA
##D     RGenAsp  -> ROccAsp,  NA,       1
##D     RGenAsp  -> REdAsp,  lam21,  NA
##D     FGenAsp  -> FOccAsp,  NA,       1
##D     FGenAsp  -> FEdAsp,  lam42,  NA
##D     RGenAsp <-> RGenAsp, ps11,   NA
##D     FGenAsp <-> FGenAsp, ps22,   NA
##D     RGenAsp <-> FGenAsp, ps12,   NA
##D     ROccAsp <-> ROccAsp, theta1, NA
##D     REdAsp  <-> REdAsp,  theta2, NA
##D     FOccAsp <-> FOccAsp, theta3, NA
##D     FEdAsp  <-> FEdAsp,  theta4, NA
##D 
##D sem.dhp <- sem(model.dhp, R.DHP, 329,
##D     fixed.x=c('RParAsp', 'RIQ', 'RSES', 'FSES', 'FIQ', 'FParAsp'))
##D     
##D path.diagram(sem.dhp, min.rank='RIQ, RSES, RParAsp, FParAsp, FSES, FIQ', 
##D     max.rank='ROccAsp, REdAsp, FEdAsp, FOccAsp')
##D 
##D ##   digraph "sem.dhp" {
##D ##   rankdir=LR;
##D ##   size="8,8";
##D ##   node [fontname="Helvetica" fontsize=14 shape=box];
##D ##   edge [fontname="Helvetica" fontsize=10];
##D ##   center=1;
##D ##   {rank=min "RIQ" "RSES" "RParAsp" "FParAsp" "FSES" "FIQ"}
##D ##   {rank=max "ROccAsp" "REdAsp" "FEdAsp" "FOccAsp"}
##D ##   "RGenAsp" [shape=ellipse]
##D ##   "FGenAsp" [shape=ellipse]
##D ##   "RParAsp" -> "RGenAsp" [label="gam11"];
##D ##   "RIQ" -> "RGenAsp" [label="gam12"];
##D ##   "RSES" -> "RGenAsp" [label="gam13"];
##D ##   "FSES" -> "RGenAsp" [label="gam14"];
##D ##   "RSES" -> "FGenAsp" [label="gam23"];
##D ##   "FSES" -> "FGenAsp" [label="gam24"];
##D ##   "FIQ" -> "FGenAsp" [label="gam25"];
##D ##   "FParAsp" -> "FGenAsp" [label="gam26"];
##D ##   "FGenAsp" -> "RGenAsp" [label="beta12"];
##D ##   "RGenAsp" -> "FGenAsp" [label="beta21"];
##D ##   "RGenAsp" -> "ROccAsp" [label=""];
##D ##   "RGenAsp" -> "REdAsp" [label="lam21"];
##D ##   "FGenAsp" -> "FOccAsp" [label=""];
##D ##   "FGenAsp" -> "FEdAsp" [label="lam42"];
##D ##   }
##D         
## End(Not run)



