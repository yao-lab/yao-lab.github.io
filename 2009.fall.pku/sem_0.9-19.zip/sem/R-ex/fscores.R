### Name: fscores
### Title: Factor Scores for Latent Variables
### Aliases: fscores fscores.sem
### Keywords: models manip

### ** Examples

           ## Not run: 
##D 
##D S.wh <- read.moments(names=c('Anomia67','Powerless67','Anomia71',
##D                                     'Powerless71','Education','SEI'))
##D    11.834                                    
##D     6.947    9.364                            
##D     6.819    5.091   12.532                    
##D     4.783    5.028    7.495    9.986            
##D    -3.839   -3.889   -3.841   -3.625   9.610     
##D   -21.899  -18.831  -21.748  -18.775  35.522  450.288
##D 
##D # This model in the SAS manual for PROC CALIS
##D 
##D model.wh.1 <- specify.model()
##D     Alienation67   ->  Anomia67,      NA,     1
##D     Alienation67   ->  Powerless67,   NA,     0.833
##D     Alienation71   ->  Anomia71,      NA,     1
##D     Alienation71   ->  Powerless71,   NA,     0.833 
##D     SES            ->  Education,     NA,     1     
##D     SES            ->  SEI,           lamb,   NA
##D     SES            ->  Alienation67,  gam1,   NA
##D     Alienation67   ->  Alienation71,  beta,   NA
##D     SES            ->  Alienation71,  gam2,   NA
##D     Anomia67       <-> Anomia67,      the1,   NA
##D     Anomia71       <-> Anomia71,      the1,   NA
##D     Powerless67    <-> Powerless67,   the2,   NA
##D     Powerless71    <-> Powerless71,   the2,   NA
##D     Education      <-> Education,     the3,   NA
##D     SEI            <-> SEI,           the4,   NA
##D     Anomia67       <-> Anomia71,      the5,   NA
##D     Powerless67    <-> Powerless71,   the5,   NA
##D     Alienation67   <-> Alienation67,  psi1,   NA
##D     Alienation71   <-> Alienation71,  psi2,   NA
##D     SES            <-> SES,           phi,    NA
##D     
##D                         
##D sem.wh.1 <- sem(model.wh.1, S.wh, 932)
##D 
##D fscores(sem.wh.1)
##D 
##D ##                Alienation67 Alienation71         SES
##D ##    Anomia67     0.413112363  0.048268330 -0.05212632
##D ##    Powerless67  0.345402079  0.040014780 -0.04355578
##D ##    Anomia71     0.052663484  0.430618716 -0.03999218
##D ##    Powerless71  0.043704122  0.360044434 -0.03339943
##D ##    Education   -0.074921670 -0.063969383  0.50571037
##D ##    SEI         -0.004638977 -0.003960837  0.03131242
##D 
##D    
## End(Not run)



