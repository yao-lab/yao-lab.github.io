### Name: raw.moments
### Title: Compute Raw Moments Matrix
### Aliases: raw.moments raw.moments.formula raw.moments.default cov2raw
###   print.rawmoments
### Keywords: manip

### ** Examples

data(Kmenta)
raw.moments(cbind(1, Kmenta))
raw.moments(~ Q + P + D + F + A, data=Kmenta)

Cov <- with(Kmenta, cov(cbind(Q, P, D, F, A)))
cov2raw(Cov, colMeans(Kmenta), nrow(Kmenta))



