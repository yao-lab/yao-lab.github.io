### Name: residuals.sem
### Title: Residual Covariances for a Structural Equation Model
### Aliases: residuals.sem standardized.residuals
###   standardized.residuals.sem normalized.residuals
###   normalized.residuals.sem
### Keywords: models

### ** Examples

    ## Not run: 
##D # ------------- assumes that Duncan, Haller and Portes peer-influences model
##D # -------------     has been fit and is in sem.dhp.1
##D 
##D residuals(sem.dhp.1)
##D 
##D ##                  ROccAsp        REdAsp       FOccAsp        FEdAsp
##D ##    ROccAsp  4.156103e-07 -2.896368e-07 -2.866110e-02  9.102874e-02
##D ##    REdAsp  -2.896368e-07 -1.541581e-06 -1.094841e-02 -2.379215e-02
##D ##    FOccAsp -2.866110e-02 -1.094841e-02 -3.740356e-06 -9.564103e-07
##D ##    
##D ##    . . .
##D ##    
##D ##                      FIQ       FParAsp
##D ##    ROccAsp  3.467853e-02 -3.187309e-02
##D ##    REdAsp   4.878970e-03 -4.443480e-02
##D ##    FOccAsp -7.354686e-03  2.488120e-02
##D ##    FEdAsp   1.124604e-02 -3.690078e-02
##D ##    RParAsp  2.775558e-17  5.551115e-17
##D ##    RIQ      2.220446e-16  6.938894e-17
##D ##    RSES     0.000000e+00 -1.387779e-17
##D ##    FSES     1.110223e-16 -2.775558e-17
##D ##    FIQ      4.440892e-16  1.110223e-16
##D ##    FParAsp  1.110223e-16  4.440892e-16
##D 
##D normalized.residuals(sem.dhp.1) 
##D 
##D ##                  ROccAsp        REdAsp       FOccAsp        FEdAsp
##D ##    ROccAsp  5.330519e-06 -4.455587e-06 -4.898232e-01  1.567678e+00
##D ##    REdAsp  -4.455587e-06 -1.977191e-05 -1.857670e-01 -4.071582e-01
##D ##    FOccAsp -4.898232e-01 -1.857670e-01 -4.797271e-05 -1.460881e-05
##D ##    
##D ##    . . .
##D ##    
##D ##                      FIQ       FParAsp
##D ##    ROccAsp  6.080514e-01 -5.747909e-01
##D ##    REdAsp   8.518738e-02 -8.007295e-01
##D ##    FOccAsp -1.180429e-01  4.374639e-01
##D ##    FEdAsp   1.832159e-01 -6.514685e-01
##D ##    RParAsp  5.019082e-16  1.000322e-15
##D ##    RIQ      3.818356e-15  1.252092e-15
##D ##    RSES     0.000000e+00 -2.506364e-16
##D ##    FSES     1.931472e-15 -5.029583e-16
##D ##    FIQ      5.695780e-15  1.971289e-15
##D ##    FParAsp  1.971289e-15  5.695780e-15
##D       
##D standardized.residuals(sem.dhp.1)
##D 
##D ##                  ROccAsp        REdAsp       FOccAsp        FEdAsp
##D ##    ROccAsp  4.156103e-07 -2.896368e-07 -2.866110e-02  9.102874e-02
##D ##    REdAsp  -2.896368e-07 -1.541581e-06 -1.094841e-02 -2.379215e-02
##D ##    FOccAsp -2.866110e-02 -1.094841e-02 -3.740356e-06 -9.564103e-07
##D ##    
##D ##    . . .
##D ##    
##D ##                      FIQ       FParAsp
##D ##    ROccAsp  3.467853e-02 -3.187309e-02
##D ##    REdAsp   4.878970e-03 -4.443480e-02
##D ##    FOccAsp -7.354686e-03  2.488120e-02
##D ##    FEdAsp   1.124604e-02 -3.690078e-02
##D ##    RParAsp  2.775558e-17  5.551115e-17
##D ##    RIQ      2.220446e-16  6.938894e-17
##D ##    RSES     0.000000e+00 -1.387779e-17
##D ##    FSES     1.110223e-16 -2.775558e-17
##D ##    FIQ      4.440892e-16  1.110223e-16
##D ##    FParAsp  1.110223e-16  4.440892e-16
##D     
## End(Not run)



