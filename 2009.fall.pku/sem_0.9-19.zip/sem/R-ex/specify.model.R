### Name: specify.model
### Title: Specify a Structural Equation Model
### Aliases: specify.model print.mod
### Keywords: models

### ** Examples

    ## Not run: 
##D model.dhp <- specify.model()
##D     RParAsp  -> RGenAsp, gam11,  NA
##D     RIQ      -> RGenAsp, gam12,  NA
##D     RSES     -> RGenAsp, gam13,  NA
##D     FSES     -> RGenAsp, gam14,  NA
##D     RSES     -> FGenAsp, gam23,  NA
##D     FSES     -> FGenAsp, gam24,  NA
##D     FIQ      -> FGenAsp, gam25,  NA
##D     FParAsp  -> FGenAsp, gam26,  NA
##D     FGenAsp  -> RGenAsp, beta12, NA
##D     RGenAsp  -> FGenAsp, beta21, NA
##D     RGenAsp  -> ROccAsp,  NA,     1
##D     RGenAsp  -> REdAsp,  lam21,  NA
##D     FGenAsp  -> FOccAsp,  NA,     1
##D     FGenAsp  -> FEdAsp,  lam42,  NA
##D     RGenAsp <-> RGenAsp, ps11,   NA
##D     FGenAsp <-> FGenAsp, ps22,   NA
##D     RGenAsp <-> FGenAsp, ps12,   NA
##D     ROccAsp <-> ROccAsp, theta1, NA
##D     REdAsp  <-> REdAsp,  theta2, NA
##D     FOccAsp <-> FOccAsp, theta3, NA
##D     FEdAsp  <-> FEdAsp,  theta4, NA
##D 
##D model.dhp
##D     
## End(Not run)



