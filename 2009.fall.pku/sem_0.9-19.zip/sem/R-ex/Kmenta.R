### Name: Kmenta
### Title: Partly Artificial Data on the U. S. Economy
### Aliases: Kmenta
### Keywords: datasets

### ** Examples

data(Kmenta)



