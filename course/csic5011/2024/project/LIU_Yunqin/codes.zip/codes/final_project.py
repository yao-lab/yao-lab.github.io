import pandas as pd
import numpy as np
from PIL import Image
from matplotlib import pyplot as plt
from matplotlib import offsetbox
import os
import gzip

from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression

from sklearn.model_selection import cross_val_score
from sklearn import (manifold, datasets, decomposition, ensemble,
                     discriminant_analysis, random_projection, neighbors)


def load_data():
    base = 'C:/Users/25812/OneDrive - HKUST Connect/Desktop/CSIC FinalProject/data2/'
    files = [
      'train-labels-idx1-ubyte.gz', 'train-images-idx3-ubyte.gz',
      't10k-labels-idx1-ubyte.gz', 't10k-images-idx3-ubyte.gz'
    ]
    paths = [base + f_name for f_name in files]

    with gzip.open(paths[0], 'rb') as lbpath:
        y_train = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[1], 'rb') as imgpath:
        x_train = np.frombuffer(
        imgpath.read(), np.uint8, offset=16).reshape(len(y_train), 28, 28)
    with gzip.open(paths[2], 'rb') as lbpath:
        y_test = np.frombuffer(lbpath.read(), np.uint8, offset=8)

    with gzip.open(paths[3], 'rb') as imgpath:
        x_test = np.frombuffer(
        imgpath.read(), np.uint8, offset=16).reshape(len(y_test), 28, 28)

    return (x_train, y_train), (x_test, y_test)

(x_train, y_train), (x_test, y_test) = load_data()

x_train_row = np.reshape(x_train,[np.shape(x_train)[0],np.shape(x_train)[1]*np.shape(x_train)[2]])
x_test_row = np.reshape(x_test,[np.shape(x_test)[0],np.shape(x_test)[1]*np.shape(x_test)[2]])




def show_imgs(n_rows, n_cols, x_data, y_data, class_names):
    """
    show the image
    """
    assert len(x_data) == len(y_data)
    assert n_rows * n_cols < len(x_data)
    plt.figure(figsize = (n_cols * 1.4, n_rows * 1.6))
    for row in range(n_rows):
        for col in range(n_cols):
            index = n_cols * row + col
            plt.subplot(n_rows, n_cols, index + 1)
            plt.imshow(x_data[index], cmap="binary", interpolation = "nearest")
            plt.axis('off')
            plt.title(class_names[y_data[index]])
    plt.show()

class_names = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
show_imgs(5, 10, x_train, y_train, class_names)

def plot_result(X, y, image):
    x_min, x_max = np.min(X, 0), np.max(X, 0)
    X = (X - x_min) / (x_max - x_min)

    fig, ax = plt.subplots(figsize=(8, 8), dpi=110)
    #     fig, ax = plt.subplots(111)
    color = ["#FF0000", "#FFFF00", "#00FF00", "#00FFFF", "#0000FF",
             "#FF00FF", "#FF0088", "#FF8800", "#00FF99", "#7700FF"]
    for i in range(0, 10):
        plt.scatter(X[y == i, 0], X[y == i, 1], c=color[i])

    if hasattr(offsetbox, 'AnnotationBbox'):
        shown_rows = np.array([[1., 1.]])
        for i in range(X.shape[0]):
            dist = np.sum((X[i] - shown_rows) ** 2, 1)
            if np.min(dist) < 8e-3:
                continue
            shown_rows = np.r_[shown_rows, [X[i]]]
            imagebox = offsetbox.AnnotationBbox(
                offsetbox.OffsetImage(image[i], cmap=plt.cm.gray_r), X[i])
            ax.add_artist(imagebox)
    plt.xticks([]), plt.yticks([])
    plt.legend([])
    plt.show()

RFC = RandomForestClassifier(random_state=0)
KNN = KNeighborsClassifier()
svm = SVC(random_state=0)


def isomap_embedding():
    print('ISOMAP embedding')
    isomap = manifold.Isomap(n_components = 2)
    isomap.fit(x_test_row)
    transformed_x_train = None
    transformed_x_test = isomap.transform(x_test_row)
    return transformed_x_train, transformed_x_test

transformed_x_train_isomap, transformed_x_test_isomap = isomap_embedding()
plot_result(transformed_x_test_isomap,y_test,x_test)



def tsne_embedding():
    print('Tsne embedding')
    tsne = manifold.TSNE(n_components = 2, init = 'pca', random_state = 0)
    transformed_x_train = None
    transformed_x_test = tsne.fit_transform(x_test_row)
    return transformed_x_train, transformed_x_test

transformed_x_train_tsne, transformed_x_test_tsne = tsne_embedding()
plot_result(transformed_x_test_tsne,y_test,x_test)

def lle_embedding():
    print('LLE embedding')
    lle = manifold.LocallyLinearEmbedding(n_components = 2, method = 'standard')
    transformed_x_train = None
    transformed_x_test = lle.fit_transform(x_test_row)
    return transformed_x_train, transformed_x_test

transformed_x_train_lle, transformed_x_test_lle = lle_embedding()
plot_result(transformed_x_test_lle,y_test,x_test)


def ltsa_embedding():
    print('LTSA embedding')
    ltsa = manifold.LocallyLinearEmbedding(n_components = 2, method = 'ltsa',eigen_solver = 'dense')
    ltsa.fit(x_test_row)
    transformed_x_train = None
    transformed_x_test = ltsa.transform(x_test_row)
    return transformed_x_train, transformed_x_test

transformed_x_train_ltsa, transformed_x_test_ltsa = ltsa_embedding()
plot_result(transformed_x_test_ltsa,y_test,x_test)


def Diffusion_map_embedding():
    print('Diffusion Map embedding')
    dm = manifold.SpectralEmbedding(n_components = 2, random_state = 0, eigen_solver = 'arpack')
    transformed_x_train = None
    transformed_x_test = dm.fit_transform(x_test_row)
    return transformed_x_train, transformed_x_test

transformed_x_train_dm, transformed_x_test_dm = Diffusion_map_embedding()
plot_result(transformed_x_test_dm,y_test,x_test)

def mds_embedding():
    print('MDS embedding')
    mds = manifold.MDS(n_components=2)
    transformed_x_train = None
    transformed_x_test = mds.fit_transform(x_test_row)
    return transformed_x_train, transformed_x_test

transformed_x_train_mds, transformed_x_test_mds = mds_embedding()
plot_result(transformed_x_test_mds,y_test,x_test)


scores_mds = cross_val_score(svm, transformed_x_test_mds, y_test, cv=5, scoring='accuracy')
scores_isomap = cross_val_score(svm, transformed_x_test_isomap, y_test, cv=5, scoring='accuracy')
scores_tsne = cross_val_score(svm, transformed_x_test_tsne, y_test, cv=5, scoring='accuracy')
scores_lle = cross_val_score(svm, transformed_x_test_lle, y_test, cv=5, scoring='accuracy')
scores_ltsa = cross_val_score(svm, transformed_x_test_ltsa, y_test, cv=5, scoring='accuracy')
scores_dm = cross_val_score(svm, transformed_x_test_dm, y_test, cv=5, scoring='accuracy')


scores = [scores_mds, scores_isomap, scores_tsne, scores_lle,scores_ltsa,
          scores_dm]
for score in scores:
    print(np.mean(score))




scores_mds = cross_val_score(RFC, transformed_x_test_mds, y_test, cv=5, scoring='accuracy')
scores_isomap = cross_val_score(RFC, transformed_x_test_isomap, y_test, cv=5, scoring='accuracy')
scores_tsne = cross_val_score(RFC, transformed_x_test_tsne, y_test, cv=5, scoring='accuracy')
scores_lle = cross_val_score(RFC, transformed_x_test_lle, y_test, cv=5, scoring='accuracy')
scores_ltsa = cross_val_score(RFC, transformed_x_test_ltsa, y_test, cv=5, scoring='accuracy')
scores_dm = cross_val_score(RFC, transformed_x_test_dm, y_test, cv=5, scoring='accuracy')

scores = [scores_mds, scores_isomap, scores_tsne, scores_lle,scores_ltsa,
          scores_dm]
for score in scores:
    print(np.mean(score))



scores_mds = cross_val_score(KNN, transformed_x_test_mds, y_test, cv=5, scoring='accuracy')
scores_isomap = cross_val_score(KNN, transformed_x_test_isomap, y_test, cv=5, scoring='accuracy')
scores_tsne = cross_val_score(KNN, transformed_x_test_tsne, y_test, cv=5, scoring='accuracy')
scores_lle = cross_val_score(KNN, transformed_x_test_lle, y_test, cv=5, scoring='accuracy')
scores_ltsa = cross_val_score(KNN, transformed_x_test_ltsa, y_test, cv=5, scoring='accuracy')
scores_dm = cross_val_score(KNN, transformed_x_test_dm, y_test, cv=5, scoring='accuracy')

scores = [scores_mds, scores_isomap, scores_tsne, scores_lle,scores_ltsa,
          scores_dm]
for score in scores:
    print(np.mean(score))


