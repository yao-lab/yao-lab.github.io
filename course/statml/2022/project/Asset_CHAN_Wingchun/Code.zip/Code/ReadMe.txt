Run PrepareData.R to clean and prepare the data -- Output input.Rdata
Then, OLS.R, OLS3.Rdata, PCR.R, PLS.R, GBRT.R, RF.R could be run in parallel to train the model -- Output OLSOutput.Rdata, OLS3Output.Rdata, PCROutput.Rdata, PLSOutput.Rdata, GBRTOutput.Rdata, ROutput.Rdata
Run Performance Analysis to produce PerformanceAnalysis.Rdata for plotting
Run Plot.R to produce the plot in the poster and powerpoint.