rm(list=ls())
gc()
library(rstudioapi)
setwd(dirname(getSourceEditorContext()$path))
library(readr)
library(data.table)
library(dplyr)
library(reshape2)
library(ranger)
load("input.Rdata")
# if(file.exists("RF_current.Rdata")){
#   load("RF_current.Rdata")
#   t = t + 1
#   save(t, file = "RF_current.Rdata")
# } else {
#   t = 0
#   save(t, file = "RF_current.Rdata")
# }

variable_importance = function(model,data){
  out = matrix(NA,3,length(variable_name),
               dimnames = list(c("numerator","denominator","result"),variable_name))
  for(i in 1:length(variable_name)){
    tmp_data = data
    tmp_data[,variable_name[i]] = 0
    out[,variable_name[i]] = unlist(R2_oos(model,tmp_data))
  }
  out
}

R2_oos = function(model,data){
  out = list(numerator = 
               colSums(as.matrix((data[,"RET"] - predict(model,data)$predictions)^2)),
             denominator = sum((data[,"RET"])^2))
  out$result = 1- out$numerator / out$denominator
  rbind(out)
}

RF = function(formula,data){
  print(Sys.time())
  hyperparameter = expand.grid(mtry = c(3,5,10), Depth = 1:6)

  model_list = apply(hyperparameter,1,function(x)
    ranger(formula, data  = data$training, mtry = x[1], num.trees = 300, max.depth = x[2]))
                    
  R2_oos_score_validation = sapply(model_list,
                                   function(model)
                                     R2_oos(model,as.matrix(data$validation))[,"result"])
  
  best_model = which.max(unlist(R2_oos_score_validation))
  
  R2_oos_score_testing = 
    rbind(All = R2_oos(model_list[[best_model]],
                       as.matrix(data$testing)),
          Top1000 = R2_oos(model_list[[best_model]],
                           data$testing%>%
                             find_monthly_top1000%>%
                             as.matrix),
          Bottom1000 = R2_oos(model_list[[best_model]],
                              data$testing%>%
                                find_monthly_bottom1000%>%
                                as.matrix))
  
  list(hyperparameter = hyperparameter,
       model_list = model_list,
       R2_oos_score_validation = R2_oos_score_validation,
       best_model = best_model,
       R2_oos_score_testing = R2_oos_score_testing,
       variable_importance = variable_importance(model_list[[best_model]],
                                                 as.matrix(data$testing)))
}

split_data = function(data,time){
  training = data%>%filter(yyyymm < 195703 + 1800  + time * 100)
  validation = data%>%filter((yyyymm >= 195703  + 1800 + time * 100) & yyyymm < 195703 + 1800 + 1200 + time * 100)
  testing = data%>%filter(yyyymm >= 195703  + 1800 + 1200 + time * 100)
  
  training = training%>%
    mutate_all(function(x) replace(x,is.na(x),median(x,na.rm=TRUE)))%>%
    mutate_at(variable_name,function(x) 2*(x-c(max(x)/2+min(x)/2))/(max(x)-min(x)))
  validation = validation%>%
    mutate_all(function(x) replace(x,is.na(x),median(x,na.rm=TRUE)))%>%
    mutate_at(variable_name,function(x) 2*(x-c(max(x)/2+min(x)/2))/(max(x)-min(x)))
  testing = testing%>%
    mutate_all(function(x) replace(x,is.na(x),median(x,na.rm=TRUE)))%>%
    mutate_at(variable_name,function(x) 2*(x-c(max(x)/2+min(x)/2))/(max(x)-min(x)))
  
  list(training = training,
       validation = validation,
       testing = testing)
}

find_monthly_top1000 = function(data,n = 1000){
  data%>%group_by(yyyymm)%>%top_n(n,mve0)
}

find_monthly_bottom1000 = function(data,n = -1000){
  data%>%group_by(yyyymm)%>%top_n(n,mve0)
}

RF_result = sapply(0:29,function(t) RF(reformulate(variable_name,"RET"),split_data(data,t)))
save(RF_result,file = "RFoutput.Rdata")