library(rstudioapi)
library(dplyr)
setwd(dirname(rstudioapi::getSourceEditorContext()$path))

PredictionPerformance = list()
VariableImportance = list()

load("OLSoutput.Rdata")
PredictionPerformance$OLS = OLS_result[[1]]
VariableImportance$OLS = OLS_result[[2]]
for (i in 3:length(OLS_result)){
  if(i %% 2 == 1){
    PredictionPerformance$OLS = PredictionPerformance$OLS + OLS_result[[i]]    
  } else {
    VariableImportance$OLS = VariableImportance$OLS +  OLS_result[[i]]
  }
}
PredictionPerformance$OLS[3,] = 1 - PredictionPerformance$OLS[1,] / PredictionPerformance$OLS[2,]
VariableImportance$OLS[3,] = 1 - VariableImportance$OLS[1,] / VariableImportance$OLS[2,]

load("OLS3output.Rdata")
PredictionPerformance$OLS3 = OLS_result[[4]]
VariableImportance$OLS3 = OLS_result[[5]]
for (i in 6:length(OLS_result)){
  if(i %% 5 == 4){
    PredictionPerformance$OLS3 = PredictionPerformance$OLS3 + OLS_result[[i]]    
  } else if(i %% 5 == 0) {
    VariableImportance$OLS3 = VariableImportance$OLS3 +  OLS_result[[i]]
  }
}
PredictionPerformance$OLS3[3,] = 1 - PredictionPerformance$OLS3[1,] / PredictionPerformance$OLS3[2,]
VariableImportance$OLS3[3,] = 1 - VariableImportance$OLS3[1,] / VariableImportance$OLS3[2,]

load("PCRoutput.Rdata")
PredictionPerformance$PCR = 
  unlist(PCR_result[[3]])%>%matrix(ncol = 3)%>%t%>%`dimnames<-`(dimnames(PredictionPerformance$OLS))
VariableImportance$PCR = 
  unlist(PCR_result[[4]])
for (i in 5:length(PCR_result)){
  if(i %% 4 == 3){
    PredictionPerformance$PCR = PredictionPerformance$PCR + unlist(t(PCR_result[[i]]))
  } else if(i %% 4 == 0){
    VariableImportance$PCR = VariableImportance$PCR +  unlist(PCR_result[[i]])
  }
}
PredictionPerformance$PCR[3,] = 1 - PredictionPerformance$PCR[1,] / PredictionPerformance$PCR[2,]
VariableImportance$PCR[3,] = 1 - VariableImportance$PCR[1,] / VariableImportance$PCR[2,]

load("PLSoutput.Rdata")
PredictionPerformance$PLS = 
  unlist(PLS_result[[3]])%>%matrix(ncol = 3)%>%t%>%`dimnames<-`(dimnames(PredictionPerformance$OLS))
VariableImportance$PLS = 
  unlist(PLS_result[[4]])
for (i in 5:length(PLS_result)){
  if(i %% 4 == 3){
    PredictionPerformance$PLS = PredictionPerformance$PLS + unlist(t(PLS_result[[i]]))
  } else if(i %% 4 == 0){
    VariableImportance$PLS = VariableImportance$PLS +  unlist(PLS_result[[i]])
  }
}
PredictionPerformance$PLS[3,] = 1 - PredictionPerformance$PLS[1,] / PredictionPerformance$PLS[2,]
VariableImportance$PLS[3,] = 1 - VariableImportance$PLS[1,] / VariableImportance$PLS[2,]

load("ElasticNetoutput.Rdata")
PredictionPerformance$EN = 
  unlist(EN_result[[6]])%>%matrix(ncol = 3)%>%t%>%`dimnames<-`(dimnames(PredictionPerformance$OLS))
VariableImportance$EN = 
  unlist(EN_result[[7]])
for (i in 8:length(EN_result)){
  if(i %% 7 == 6){
    PredictionPerformance$EN = PredictionPerformance$EN + unlist(t(EN_result[[i]]))
  } else if(i %% 7 == 0){
    VariableImportance$EN = VariableImportance$EN +  unlist(EN_result[[i]])
  }
}
PredictionPerformance$EN[3,] = 1 - PredictionPerformance$EN[1,] / PredictionPerformance$EN[2,]
VariableImportance$EN[3,] = 1 - VariableImportance$EN[1,] / VariableImportance$EN[2,]

load("RFoutput.Rdata")
PredictionPerformance$RF = 
  unlist(RF_result[[4]])%>%matrix(ncol = 3)%>%t%>%`dimnames<-`(dimnames(PredictionPerformance$OLS))
VariableImportance$RF = 
  unlist(RF_result[[5]])
for (i in 6:length(RF_result)){
  if(i %% 5 == 4){
    PredictionPerformance$RF = PredictionPerformance$RF + unlist(t(RF_result[[i]]))
  } else if(i %% 5 == 0){
    VariableImportance$RF = VariableImportance$RF +  unlist(RF_result[[i]])
  }
}
PredictionPerformance$RF[3,] = 1 - PredictionPerformance$RF[1,] / PredictionPerformance$RF[2,]
VariableImportance$RF[3,] = 1 - VariableImportance$RF[1,] / VariableImportance$RF[2,]


load(paste0("GBRT_0.Rdata"))
PredictionPerformance$GBRT = unlist(GBRT_result[[5]])
VariableImportance$GBRT = unlist(GBRT_result[[6]])
for(file in 1:29){
  load(paste0("GBRT_",file,".Rdata"))
  PredictionPerformance$GBRT = PredictionPerformance$GBRT + unlist(GBRT_result[[5]])
  VariableImportance$GBRT = VariableImportance$GBRT +  unlist(GBRT_result[[6]])
}
PredictionPerformance$GBRT[3,] = 1 - PredictionPerformance$GBRT[1,] / PredictionPerformance$GBRT[2,]
VariableImportance$GBRT[3,] = 1 - VariableImportance$GBRT[1,] / VariableImportance$GBRT[2,]

save(PredictionPerformance,VariableImportance,file = "PerformanceAnalysis.Rdata")
