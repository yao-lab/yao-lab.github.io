rm(list=ls())
gc()
library(rstudioapi)
setwd(dirname(getSourceEditorContext()$path))
library(readr)
library(data.table)
library(dplyr)
library(reshape2)
library(hqreg)
library(caret)
load("input.Rdata")

variable_importance = function(model,data,select_lambda){
  out = matrix(NA,3,length(variable_name),
               dimnames = list(c("numerator","denominator","result"),variable_name))
  for(i in 1:length(variable_name)){
    tmp_data = data
    tmp_data[,variable_name[i]] = 0
    out[,variable_name[i]] = unlist(R2_oos(model,tmp_data,select_lambda))
  }
  out
}

R2_oos = function(model,data,select_lambda = 1:ncol(model$beta)){

  out = 
    list(numerator = 
           colSums(as.matrix((data[,"RET"] 
                              - rep(1,nrow(data)) %*% t(model$beta[1,select_lambda]) 
                              - data[,colnames(data) != "RET"] %*% as.matrix(model$beta)[-1,select_lambda])^2)),
         denominator = sum((data[,"RET"])^2))
  out$result = 1- out$numerator / out$denominator
  rbind(out)
}

EN = function(data){
  hyperparameter = seq(0.1,0.9,by = 0.1)

  model_list = lapply(hyperparameter,function(alpha)
    hqreg_raw(as.matrix(data$training[,variable_name]),
              data$training$RET,alpha = alpha))
                    
  R2_oos_score_validation = lapply(model_list,
                                   function(model) 
                                     R2_oos(model,
                                            data = as.matrix(data$validation[1:1000,c("RET",variable_name)])
                                            )[,"result"])
  
  best_model_by_alpha = sapply(R2_oos_score_validation,function(x) which.max(x[[1]]))
  best_model_by_alpha_R2oos = sapply(R2_oos_score_validation,function(x) max(x[[1]]))
  
  best_model = which.max(best_model_by_alpha_R2oos)
  
  R2_oos_score_testing = 
    rbind(All = R2_oos(model_list[[best_model]],
                       as.matrix(data$testing[c("RET",variable_name)]),
                       best_model_by_alpha[best_model]),
          Top1000 = R2_oos(model_list[[best_model]],
                           data$testing%>%
                             find_monthly_top1000%>%
                             (function(x) x[,c("RET",variable_name)])%>%
                             as.matrix,
                           best_model_by_alpha[best_model]),
          Bottom1000 = R2_oos(model_list[[best_model]],
                              data$testing%>%
                                find_monthly_bottom1000%>%
                                (function(x) x[,c("RET",variable_name)])%>%
                                as.matrix,
                              best_model_by_alpha[best_model]))
  
  list(hyperparameter = hyperparameter,
       R2_oos_score_validation = R2_oos_score_validation,
       best_model_by_alpha = best_model_by_alpha,
       best_model_by_alpha_R2oos = best_model_by_alpha_R2oos,
       best_model = best_model,
       R2_oos_score_testing = R2_oos_score_testing,
       variable_importance = variable_importance(model_list[[best_model]],
                                                 as.matrix(data$testing[c("RET",variable_name)]),
                                                 best_model_by_alpha[best_model]))
}

split_data = function(data,time){
  print(time)
  print(Sys.time())
  training = data%>%filter(yyyymm < 195703 + 1800  + time * 100)
  validation = data%>%filter((yyyymm >= 195703  + 1800 + time * 100) & yyyymm < 195703 + 1800 + 1200 + time * 100)
  testing = data%>%filter(yyyymm >= 195703  + 1800 + 1200 + time * 100)
  
  training = training%>%
    mutate_all(function(x) replace(x,is.na(x),median(x,na.rm=TRUE)))%>%
    mutate_at(variable_name,function(x) 2*(x-c(max(x)/2+min(x)/2))/(max(x)-min(x)))
  validation = validation%>%
    mutate_all(function(x) replace(x,is.na(x),median(x,na.rm=TRUE)))%>%
    mutate_at(variable_name,function(x) 2*(x-c(max(x)/2+min(x)/2))/(max(x)-min(x)))
  testing = testing%>%
    mutate_all(function(x) replace(x,is.na(x),median(x,na.rm=TRUE)))%>%
    mutate_at(variable_name,function(x) 2*(x-c(max(x)/2+min(x)/2))/(max(x)-min(x)))
  
  list(training = training,
       validation = validation,
       testing = testing)
}

find_monthly_top1000 = function(data,n = 1000){
  data%>%group_by(yyyymm)%>%top_n(n,mve0)
}

find_monthly_bottom1000 = function(data,n = -1000){
  data%>%group_by(yyyymm)%>%top_n(n,mve0)
}

EN_result = sapply(0:29,function(t) EN(split_data(data,t)))
save(EN_result,file = "ENoutput.Rdata")