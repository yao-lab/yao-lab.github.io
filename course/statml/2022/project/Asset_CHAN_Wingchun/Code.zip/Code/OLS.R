rm(list=ls())
gc()
library(rstudioapi)
setwd(dirname(getSourceEditorContext()$path))
library(readr)
library(data.table)
library(dplyr)
library(reshape2)
library(MASS)
load("input.Rdata")

variable_importance = function(model,data){
  out = matrix(NA,3,length(variable_name),
               dimnames = list(c("numerator","denominator","result"),variable_name))
  for(i in 1:length(variable_name)){
    tmp_data = data
    tmp_data[,variable_name[i]] = 0
    out[,variable_name[i]] = R2_oos(model,tmp_data)
  }
  out
}

R2_oos = function(model,data){
  out = c(numerator = sum((data$RET - predict(model,data))^2),
          denominator = sum((data$RET)^2))
  out["result"] = 1- out["numerator"] / out["denominator"]
  out
}

OLSH = function(formula,data){
  alpha = seq(0.345,2.345,by = 0.2)
  model_list = lapply(alpha,function(alpha) rlm(formula,data$training,k = alpha))
  R2_oos_score_validation = sapply(model_list,R2_oos, data = data$validation)[3,]
  
  best_model = which.max(R2_oos_score_validation)
  
  R2_oos_score_testing = 
    cbind(All = R2_oos(model_list[[best_model]],data$testing),
          Top1000 = R2_oos(model_list[[best_model]],data$testing%>%find_monthly_top1000),
          Bottom1000 = R2_oos(model_list[[best_model]],data$testing%>%find_monthly_bottom1000))
  
  list(alpha = alpha,
       R2_oos_score_validation = R2_oos_score_validation,
       best_model = best_model,
       R2_oos_score_testing = R2_oos_score_testing,
       variable_importance = variable_importance(model_list[[best_model]],data$testing))
}

split_data = function(data,time){
  training = data%>%filter(yyyymm < 195703 + 1800  + time * 100)
  validation = data%>%filter((yyyymm >= 195703  + 1800 + time * 100) & yyyymm < 195703 + 1800 + 1200 + time * 100)
  testing = data%>%filter(yyyymm >= 195703  + 1800 + 1200 + time * 100)
  
  training = training%>%
    mutate_all(function(x) replace(x,is.na(x),median(x,na.rm=TRUE)))%>%
    mutate_at(variable_name,function(x) 2*(x-c(max(x)/2+min(x)/2))/(max(x)-min(x)))
  validation = validation%>%
    mutate_all(function(x) replace(x,is.na(x),median(x,na.rm=TRUE)))%>%
    mutate_at(variable_name,function(x) 2*(x-c(max(x)/2+min(x)/2))/(max(x)-min(x)))
  testing = testing%>%
    mutate_all(function(x) replace(x,is.na(x),median(x,na.rm=TRUE)))%>%
    mutate_at(variable_name,function(x) 2*(x-c(max(x)/2+min(x)/2))/(max(x)-min(x)))
  
  list(training = training,
       validation = validation,
       testing = testing)
}

find_monthly_top1000 = function(data,n = 1000){
  data%>%group_by(yyyymm)%>%top_n(n,mve0)
}

find_monthly_bottom1000 = function(data,n = -1000){
  data%>%group_by(yyyymm)%>%top_n(n,mve0)
}

OLS_result = sapply(0:29,function(t) OLSH(reformulate(variable_name,"RET"),split_data(data,t)))
save(OLS_result,file = "OLSoutput.Rdata")