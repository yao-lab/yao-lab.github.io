rm(list=ls())
gc()
library(rstudioapi)
setwd(dirname(getSourceEditorContext()$path))
library(readr)
library(data.table)
library(dplyr)
library(reshape2)
library(ggplot2)
load("input.Rdata")
#################### Ave Return #################### 
ave = with(data,tapply(RET,yyyymm,mean,na.rm=TRUE))
yyyymm = unique(data$yyyymm) %>% paste0("01")%>%as.Date(format="%Y%m%d")
ggplot(data.frame(yyyymm = yyyymm, ave = ave)) +
  geom_line(aes(x = yyyymm, y = ave)) + 
  labs(x ="Year", y = "Return") + 
  ggtitle("Average Stock Return from March 1957 to December 2016")
ggsave("AveReturn.png",width = 7, height = 3)           
#################### Data Spliting #################### 
training_time = function(t){
  data.frame(xstart = t,xend = t, 
             ystart = as.Date(paste0(1957,"-03-01")), 
             yend = min(as.Date(paste0(1957 + t + 18,"-03-01"))-1,as.Date("2016-12-31")),
             Type = "Training")
}

validation_time = function(t){
  data.frame(xstart = t,xend = t, 
             ystart = min(as.Date(paste0(1957 + t + 18,"-03-01")),as.Date("2016-12-31")), 
             yend = min(as.Date(paste0(1957 + t + 30,"-03-01"))-1,as.Date("2016-12-31")),
             Type = "Validation")
}

testing_time = function(t){
  data.frame(xstart = t,xend = t, 
             ystart = min(as.Date(paste0(1957 + t + 30,"-03-01"))-1,as.Date("2016-12-31")), 
             yend = as.Date("2016-12-31"),
             Type = "Testing")
}

input = rbind(
  lapply(0:29,function(t) training_time(t))%>%do.call(rbind,.),
  lapply(0:29,function(t) validation_time(t))%>%do.call(rbind,.),
  lapply(0:29,function(t) testing_time(t))%>%do.call(rbind,.)
) 
input$Type = factor(input$Type, 
                    levels = c("Training","Validation","Testing"),
                    labels = c("Training","Validation","Testing"))
ggplot(input) + 
  geom_segment(aes(y = xstart, yend = xend, x = ystart, xend = yend, group = Type, color = Type)) + 
  labs(x = "Year", y = "Replication")
ggsave("plot2.png",width = 6, height = 4)

#################### Performance Analysis #################### 
load("PerformanceAnalysis.Rdata")
PredictionPerformance = sapply(PredictionPerformance,identity,simplify = "array")[3,,]
ggplot(melt(PredictionPerformance)) +
  geom_bar(aes(fill=Var1, y=value, x=Var2),position="dodge", stat="identity")+
  scale_fill_discrete(name="Sample of \nchoice",
                      breaks=c("All", "Top1000","Bottom1000"),
                      labels=c("All", "Top 1000", "Bottom 1000")) +
  xlab("Model") + ylab("out-of-sample R square") +
  ggtitle("Performance of different models in prediction")
ggsave("R2oos.png",width = 7,height = 3)
ggsave("R2oos_PPT.png",width = 7,height = 5)

#################### Variable Importance #################### 
VariableImportance = sapply(VariableImportance[-2],identity,simplify = "array")[3,,]
apply(-VariableImportance,2,rank)%>%rowMeans%>%sort%>%data.frame(VarName = names(.),AvgRank=.)%>%
  ggplot() + coord_flip() + 
  geom_bar(aes(y=AvgRank, x=reorder(VarName,AvgRank)),stat="identity")+
  xlab("Variable") + ylab("Average Rank") +
  ggtitle("Average rank of out-of-sample R square over models")
ggsave("VI.png",width = 7,height = 3)
ggsave("VI_PPT.png",width = 7,height = 5)
