library(rstudioapi)
setwd(dirname(getSourceEditorContext()$path))
library(readr)
library(data.table)
library(dplyr)
library(reshape2)
PredictorData2021_xlsx_Monthly = 
  read_csv("PredictorData2021.xlsx - Monthly.csv") %>%
  filter((yyyymm >= 195703) & (yyyymm <= 201612))

X = data.table(
  yyyymm = PredictorData2021_xlsx_Monthly$yyyymm,
  DP = log(PredictorData2021_xlsx_Monthly$D12) - log(PredictorData2021_xlsx_Monthly$Index),
  EP = log(PredictorData2021_xlsx_Monthly$E12) - log(PredictorData2021_xlsx_Monthly$Index),
  BM = PredictorData2021_xlsx_Monthly$`b/m`,
  NTIS = PredictorData2021_xlsx_Monthly$ntis,
  TBL = PredictorData2021_xlsx_Monthly$tbl,
  TMS = PredictorData2021_xlsx_Monthly$ltr - PredictorData2021_xlsx_Monthly$tbl,
  DFY = PredictorData2021_xlsx_Monthly$BAA - PredictorData2021_xlsx_Monthly$AAA,
  SVAR = PredictorData2021_xlsx_Monthly$svar
)

data = fread("GKX_20201231.csv", header = T)%>%
  as.data.frame()%>%
  filter(DATE >= 19570301 & DATE <= 20161201)%>%
  mutate(yyyymm = DATE %/% 100)

variable_name = names(data)[names(data)%in%readLines("variable.txt")]
n_missing = apply(data, 2, function(x) sum(is.na(x))) / nrow(data)
variable_name = 
  intersect(names(n_missing)[n_missing < 0.1], variable_name)

data = merge(data[,c("permno","DATE","yyyymm","RET","mve0",variable_name)], X,by = "yyyymm")

save(data,variable_name,file = "input.Rdata")
