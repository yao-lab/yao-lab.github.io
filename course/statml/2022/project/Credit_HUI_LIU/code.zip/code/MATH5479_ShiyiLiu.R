############################################################
##MATH5470 Predict Home Credit Default Risk 
############################################################
rm(list = ls())

library(tidyverse)
library(dplyr)
library(tree)
library(partykit)
library(h2o)
library(randomForest)
library(glmnet)
library(GGally)
library(plotROC)
library(ggplot2) 
library(readr)
library(pROC)
library(caret)



# Load the data
setwd("/Users/mac/Library/CloudStorage/OneDrive-HKUSTConnect/Work/Course/22-23course/MATH5470/home-credit-default-risk/")
application_train <- read.csv("application_train.csv")
application_test <- read.csv("application_test.csv")

set.seed(10)

# exploring data & tidy data

## Manually droping unrelated variables
#training data
{
data.frame(colnames(application_train))
itmdate_train = subset(application_train, select = -c(AMT_GOODS_PRICE,ELEVATORS_MEDI,ENTRANCES_MEDI,FLOORSMAX_MEDI,FLOORSMIN_MEDI,LANDAREA_MEDI,LIVINGAPARTMENTS_MEDI,LIVINGAREA_MEDI,NONLIVINGAPARTMENTS_MEDI,
                                               NONLIVINGAREA_MEDI,TOTALAREA_MODE,NONLIVINGAREA_AVG,APARTMENTS_MODE,BASEMENTAREA_MODE,YEARS_BEGINEXPLUATATION_MODE,YEARS_BUILD_MODE,COMMONAREA_MODE,ELEVATORS_MODE,
                                               ENTRANCES_MODE,FLOORSMAX_MODE,FLOORSMIN_MODE,LANDAREA_MODE,LIVINGAPARTMENTS_MODE,LIVINGAREA_MODE,NONLIVINGAPARTMENTS_MODE,NONLIVINGAREA_MODE,APARTMENTS_MEDI,BASEMENTAREA_MEDI,
                                               YEARS_BEGINEXPLUATATION_MEDI,YEARS_BUILD_MEDI,COMMONAREA_MEDI,APARTMENTS_AVG,BASEMENTAREA_AVG,YEARS_BEGINEXPLUATATION_AVG,YEARS_BUILD_AVG,COMMONAREA_AVG,ELEVATORS_AVG,
                                               ENTRANCES_AVG,FLOORSMAX_AVG,FLOORSMIN_AVG,LANDAREA_AVG,LIVINGAPARTMENTS_AVG,LIVINGAREA_AVG,NONLIVINGAPARTMENTS_AVG,
                                               FONDKAPREMONT_MODE,HOUSETYPE_MODE,WALLSMATERIAL_MODE,EMERGENCYSTATE_MODE
))
}
#testing data
{
  data.frame(colnames(application_test))
  itmdate_test = subset(application_test, select = -c(AMT_GOODS_PRICE,ELEVATORS_MEDI,ENTRANCES_MEDI,FLOORSMAX_MEDI,FLOORSMIN_MEDI,LANDAREA_MEDI,LIVINGAPARTMENTS_MEDI,LIVINGAREA_MEDI,NONLIVINGAPARTMENTS_MEDI,
                                                                NONLIVINGAREA_MEDI,TOTALAREA_MODE,NONLIVINGAREA_AVG,APARTMENTS_MODE,BASEMENTAREA_MODE,YEARS_BEGINEXPLUATATION_MODE,YEARS_BUILD_MODE,COMMONAREA_MODE,ELEVATORS_MODE,
                                                                ENTRANCES_MODE,FLOORSMAX_MODE,FLOORSMIN_MODE,LANDAREA_MODE,LIVINGAPARTMENTS_MODE,LIVINGAREA_MODE,NONLIVINGAPARTMENTS_MODE,NONLIVINGAREA_MODE,APARTMENTS_MEDI,BASEMENTAREA_MEDI,
                                                                YEARS_BEGINEXPLUATATION_MEDI,YEARS_BUILD_MEDI,COMMONAREA_MEDI,APARTMENTS_AVG,BASEMENTAREA_AVG,YEARS_BEGINEXPLUATATION_AVG,YEARS_BUILD_AVG,COMMONAREA_AVG,ELEVATORS_AVG,
                                                                ENTRANCES_AVG,FLOORSMAX_AVG,FLOORSMIN_AVG,LANDAREA_AVG,LIVINGAPARTMENTS_AVG,LIVINGAREA_AVG,NONLIVINGAPARTMENTS_AVG,
                                                                FONDKAPREMONT_MODE,HOUSETYPE_MODE,WALLSMATERIAL_MODE,EMERGENCYSTATE_MODE
  ))
}


## Manually droping observations(NA values & observations & recoding) & transforming data
#training data
{
  
  noNA_intermediate_train <- subset(itmdate_train,AMT_ANNUITY!="NA" & 
                                  CNT_FAM_MEMBERS!="NA" & DAYS_LAST_PHONE_CHANGE!="NA" )

na_count_train <- sapply(noNA_intermediate_train, function(x) sum(length(which(is.na(x)))))
na_count_train <-  data.frame(na_count_train)
na_count_train
## Drop observations that do not have car age despite car ownership
check =ifelse(noNA_intermediate_train$FLAG_OWN_CAR=="Y" & is.na(noNA_intermediate_train$OWN_CAR_AGE),1,0)
noNA_intermediate_train = subset(noNA_intermediate_train,check == 0)


## Drop observations that do not have valid gender type
unique(noNA_intermediate_train$CODE_GENDER)
noNA_intermediate_train = subset(noNA_intermediate_train,noNA_intermediate_train$CODE_GENDER != "XNA")

## Create dummy variables for EXT_SOURCE & Social Circle & Credit Bureau
noNA_intermediate_train$EXTS1 = 1
noNA_intermediate_train$EXTS1[is.na(noNA_intermediate_train$EXT_SOURCE_1)] = 0
noNA_intermediate_train$EXTS2 = 1
noNA_intermediate_train$EXTS2[is.na(noNA_intermediate_train$EXT_SOURCE_2)] = 0
noNA_intermediate_train$EXTS3 = 1
noNA_intermediate_train$EXTS3[is.na(noNA_intermediate_train$EXT_SOURCE_3)] = 0

noNA_intermediate_train$Social = 1
noNA_intermediate_train$Social[is.na(noNA_intermediate_train$OBS_30_CNT_SOCIAL_CIRCLE)] = 0

noNA_intermediate_train$CreditInq = 1
noNA_intermediate_train$CreditInq[is.na(noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_HOUR)] = 0

## Recode categorical variables into binarical(Car ownership,gender,
#OWN_CAR_AGE,EXT_SOURCE,CREDIT BUREAU, SOCIAL CIRCLE,Name_Type_Suite,Occupation Type)

noNA_intermediate_train$CAR_OWNERSHIP = 0
noNA_intermediate_train$CAR_OWNERSHIP[noNA_intermediate_train$FLAG_OWN_CAR == "Y"] = 1
noNA_intermediate_train$FLAG_OWN_CAR = NULL

noNA_intermediate_train$REALTY_OWNERSHIP = 0
noNA_intermediate_train$REALTY_OWNERSHIP[noNA_intermediate_train$FLAG_OWN_REALTY == "Y"] = 1
noNA_intermediate_train$FLAG_OWN_REALTY = NULL

noNA_intermediate_train$Female=ifelse(noNA_intermediate_train$CODE_GENDER=="F",1,0)
noNA_intermediate_train$CODE_GENDER = NULL

noNA_intermediate_train$OWN_CAR_AGE_EDIT = noNA_intermediate_train$OWN_CAR_AGE
noNA_intermediate_train$OWN_CAR_AGE_EDIT[is.na(noNA_intermediate_train$OWN_CAR_AGE)] = 9999
noNA_intermediate_train$OWN_CAR_AGE = NULL

noNA_intermediate_train$EXT_SOURCE_1_EDIT=ifelse(is.na(noNA_intermediate_train$EXT_SOURCE_1),9999,noNA_intermediate_train$EXT_SOURCE_1)
noNA_intermediate_train$EXT_SOURCE_2_EDIT=ifelse(is.na(noNA_intermediate_train$EXT_SOURCE_2),9999,noNA_intermediate_train$EXT_SOURCE_2)
noNA_intermediate_train$EXT_SOURCE_3_EDIT=ifelse(is.na(noNA_intermediate_train$EXT_SOURCE_3),9999,noNA_intermediate_train$EXT_SOURCE_3)
noNA_intermediate_train$EXT_SOURCE_1=NULL
noNA_intermediate_train$EXT_SOURCE_2=NULL
noNA_intermediate_train$EXT_SOURCE_3=NULL

noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_DAY_EDIT=ifelse(is.na(noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_DAY),9999,noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_DAY)
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_DAY=NULL
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_HOUR_EDIT=ifelse(is.na(noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_HOUR),9999,noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_HOUR)
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_HOUR=NULL
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_WEEK_EDIT=ifelse(is.na(noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_WEEK),9999,noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_WEEK)
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_WEEK=NULL
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_MON_EDIT=ifelse(is.na(noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_MON),9999,noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_MON)
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_MON=NULL
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_QRT_EDIT=ifelse(is.na(noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_QRT),9999,noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_QRT)
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_QRT=NULL
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_YEAR_EDIT=ifelse(is.na(noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_YEAR),9999,noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_YEAR)
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_YEAR=NULL

noNA_intermediate_train$OBS_30_CNT_SOCIAL_CIRCLE_EDIT=ifelse(is.na(noNA_intermediate_train$OBS_30_CNT_SOCIAL_CIRCLE),9999,noNA_intermediate_train$OBS_30_CNT_SOCIAL_CIRCLE)
noNA_intermediate_train$OBS_30_CNT_SOCIAL_CIRCLE=NULL
noNA_intermediate_train$OBS_60_CNT_SOCIAL_CIRCLE_EDIT=ifelse(is.na(noNA_intermediate_train$OBS_60_CNT_SOCIAL_CIRCLE),9999,noNA_intermediate_train$OBS_60_CNT_SOCIAL_CIRCLE)
noNA_intermediate_train$OBS_60_CNT_SOCIAL_CIRCLE=NULL
noNA_intermediate_train$DEF_30_CNT_SOCIAL_CIRCLE_EDIT=ifelse(is.na(noNA_intermediate_train$DEF_30_CNT_SOCIAL_CIRCLE),9999,noNA_intermediate_train$DEF_30_CNT_SOCIAL_CIRCLE)
noNA_intermediate_train$DEF_30_CNT_SOCIAL_CIRCLE=NULL
noNA_intermediate_train$DEF_60_CNT_SOCIAL_CIRCLE_EDIT=ifelse(is.na(noNA_intermediate_train$DEF_60_CNT_SOCIAL_CIRCLE),9999,noNA_intermediate_train$DEF_60_CNT_SOCIAL_CIRCLE)
noNA_intermediate_train$DEF_60_CNT_SOCIAL_CIRCLE=NULL

noNA_intermediate_train$NAME_TYPE_SUITE_EDIT = noNA_intermediate_train$NAME_TYPE_SUITE
levels(noNA_intermediate_train$NAME_TYPE_SUITE_EDIT)[levels(noNA_intermediate_train$NAME_TYPE_SUITE_EDIT)==""] <- "Unknown"
noNA_intermediate_train$NAME_TYPE_SUITE = NULL

noNA_intermediate_train$OCCUPATION_TYPE_EDIT = noNA_intermediate_train$OCCUPATION_TYPE
levels(noNA_intermediate_train$OCCUPATION_TYPE_EDIT)[levels(noNA_intermediate_train$OCCUPATION_TYPE_EDIT)==""] = "Unknown"
noNA_intermediate_train$OCCUPATION_TYPE = NULL

# Check the whole dataset
na_count_train <-sapply(noNA_intermediate_train, function(x) sum(length(which(x == ""))))
na_count_train = data.frame(na_count_train)
na_count_train

# Exclude Outliers
hist(noNA_intermediate_train$AMT_INCOME_TOTAL) # There are a lot of outliers, most observations fall below 10m

## Closer examiniation shows that most observations fall below 600k so we use that as the cutoff point

noNA_intermediate_train = subset(noNA_intermediate_train,noNA_intermediate_train$AMT_INCOME_TOTAL<600000)

}

#testing data
{
  noNA_intermediate_test <- itmdate_test
  
  ## Create dummy variables for EXT_SOURCE & Social Circle & Credit Bureau
  noNA_intermediate_test$EXTS1 = 1
  noNA_intermediate_test$EXTS1[is.na(noNA_intermediate_test$EXT_SOURCE_1)] = 0
  noNA_intermediate_test$EXTS2 = 1
  noNA_intermediate_test$EXTS2[is.na(noNA_intermediate_test$EXT_SOURCE_2)] = 0
  noNA_intermediate_test$EXTS3 = 1
  noNA_intermediate_test$EXTS3[is.na(noNA_intermediate_test$EXT_SOURCE_3)] = 0
  
  noNA_intermediate_test$Social = 1
  noNA_intermediate_test$Social[is.na(noNA_intermediate_test$OBS_30_CNT_SOCIAL_CIRCLE)] = 0
  
  noNA_intermediate_test$CreditInq = 1
  noNA_intermediate_test$CreditInq[is.na(noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_HOUR)] = 0
  
  ## Recode categorical variables into binarical(Car ownership,gender,
  #OWN_CAR_AGE,EXT_SOURCE,CREDIT BUREAU, SOCIAL CIRCLE,Name_Type_Suite,
  #Occupation Type)
  noNA_intermediate_test$CAR_OWNERSHIP = 0
  noNA_intermediate_test$CAR_OWNERSHIP[noNA_intermediate_test$FLAG_OWN_CAR == "Y"] = 1
  noNA_intermediate_test$FLAG_OWN_CAR = NULL
  
  noNA_intermediate_test$REALTY_OWNERSHIP = 0
  noNA_intermediate_test$REALTY_OWNERSHIP[noNA_intermediate_test$FLAG_OWN_REALTY == "Y"] = 1
  noNA_intermediate_test$FLAG_OWN_REALTY = NULL
  
  noNA_intermediate_test$Female=ifelse(noNA_intermediate_test$CODE_GENDER=="F",1,0)
  noNA_intermediate_test$CODE_GENDER = NULL
  
  noNA_intermediate_test$OWN_CAR_AGE_EDIT = noNA_intermediate_test$OWN_CAR_AGE
  noNA_intermediate_test$OWN_CAR_AGE_EDIT[is.na(noNA_intermediate_test$OWN_CAR_AGE)] = 9999
  noNA_intermediate_test$OWN_CAR_AGE = NULL
  
  noNA_intermediate_test$EXT_SOURCE_1_EDIT=ifelse(is.na(noNA_intermediate_test$EXT_SOURCE_1),9999,noNA_intermediate_test$EXT_SOURCE_1)
  noNA_intermediate_test$EXT_SOURCE_2_EDIT=ifelse(is.na(noNA_intermediate_test$EXT_SOURCE_2),9999,noNA_intermediate_test$EXT_SOURCE_2)
  noNA_intermediate_test$EXT_SOURCE_3_EDIT=ifelse(is.na(noNA_intermediate_test$EXT_SOURCE_3),9999,noNA_intermediate_test$EXT_SOURCE_3)
  noNA_intermediate_test$EXT_SOURCE_1=NULL
  noNA_intermediate_test$EXT_SOURCE_2=NULL
  noNA_intermediate_test$EXT_SOURCE_3=NULL
  
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_DAY_EDIT=ifelse(is.na(noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_DAY),9999,noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_DAY)
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_DAY=NULL
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_HOUR_EDIT=ifelse(is.na(noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_HOUR),9999,noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_HOUR)
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_HOUR=NULL
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_WEEK_EDIT=ifelse(is.na(noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_WEEK),9999,noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_WEEK)
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_WEEK=NULL
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_MON_EDIT=ifelse(is.na(noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_MON),9999,noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_MON)
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_MON=NULL
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_QRT_EDIT=ifelse(is.na(noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_QRT),9999,noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_QRT)
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_QRT=NULL
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_YEAR_EDIT=ifelse(is.na(noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_YEAR),9999,noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_YEAR)
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_YEAR=NULL
  
  noNA_intermediate_test$OBS_30_CNT_SOCIAL_CIRCLE_EDIT=ifelse(is.na(noNA_intermediate_test$OBS_30_CNT_SOCIAL_CIRCLE),9999,noNA_intermediate_test$OBS_30_CNT_SOCIAL_CIRCLE)
  noNA_intermediate_test$OBS_30_CNT_SOCIAL_CIRCLE=NULL
  noNA_intermediate_test$OBS_60_CNT_SOCIAL_CIRCLE_EDIT=ifelse(is.na(noNA_intermediate_test$OBS_60_CNT_SOCIAL_CIRCLE),9999,noNA_intermediate_test$OBS_60_CNT_SOCIAL_CIRCLE)
  noNA_intermediate_test$OBS_60_CNT_SOCIAL_CIRCLE=NULL
  noNA_intermediate_test$DEF_30_CNT_SOCIAL_CIRCLE_EDIT=ifelse(is.na(noNA_intermediate_test$DEF_30_CNT_SOCIAL_CIRCLE),9999,noNA_intermediate_test$DEF_30_CNT_SOCIAL_CIRCLE)
  noNA_intermediate_test$DEF_30_CNT_SOCIAL_CIRCLE=NULL
  noNA_intermediate_test$DEF_60_CNT_SOCIAL_CIRCLE_EDIT=ifelse(is.na(noNA_intermediate_test$DEF_60_CNT_SOCIAL_CIRCLE),9999,noNA_intermediate_test$DEF_60_CNT_SOCIAL_CIRCLE)
  noNA_intermediate_test$DEF_60_CNT_SOCIAL_CIRCLE=NULL
  
  noNA_intermediate_test$NAME_TYPE_SUITE_EDIT = noNA_intermediate_test$NAME_TYPE_SUITE
  levels(noNA_intermediate_test$NAME_TYPE_SUITE_EDIT)[levels(noNA_intermediate_test$NAME_TYPE_SUITE_EDIT)==""] <- "Unknown"
  noNA_intermediate_test$NAME_TYPE_SUITE = NULL
  
  noNA_intermediate_test$OCCUPATION_TYPE_EDIT = noNA_intermediate_test$OCCUPATION_TYPE
  levels(noNA_intermediate_test$OCCUPATION_TYPE_EDIT)[levels(noNA_intermediate_test$OCCUPATION_TYPE_EDIT)==""] = "Unknown"
  noNA_intermediate_test$OCCUPATION_TYPE = NULL
  
  # Check the whole dataset
  na_count_test <-sapply(noNA_intermediate_test, function(x) sum(length(which(x == ""))))
  na_count_test = data.frame(na_count_test)
  
}




## Creating(Interaction Variables(fusion of car variabl), transforming the variables)
#training data
{
# create CO *CA
noNA_intermediate_train$carOwner_carAge=noNA_intermediate_train$CAR_OWNERSHIP*noNA_intermediate_train$OWN_CAR_AGE_EDIT
noNA_intermediate_train=subset(noNA_intermediate_train, select=-c(OWN_CAR_AGE_EDIT))

# Social Circles
noNA_intermediate_train$DEF30=noNA_intermediate_train$DEF_30_CNT_SOCIAL_CIRCLE_EDIT*noNA_intermediate_train$Social
noNA_intermediate_train$OBS30=noNA_intermediate_train$OBS_30_CNT_SOCIAL_CIRCLE_EDIT*noNA_intermediate_train$Social
noNA_intermediate_train$DEF60=noNA_intermediate_train$DEF_60_CNT_SOCIAL_CIRCLE_EDIT*noNA_intermediate_train$Social
noNA_intermediate_train$OBS60=noNA_intermediate_train$OBS_60_CNT_SOCIAL_CIRCLE_EDIT*noNA_intermediate_train$Social
noNA_intermediate_train$DEF_30_CNT_SOCIAL_CIRCLE_EDIT=NULL
noNA_intermediate_train$DEF_60_CNT_SOCIAL_CIRCLE_EDIT=NULL
noNA_intermediate_train$OBS_60_CNT_SOCIAL_CIRCLE_EDIT=NULL
noNA_intermediate_train$OBS_30_CNT_SOCIAL_CIRCLE_EDIT=NULL

# Credit Bureau
noNA_intermediate_train$Credit_Hour=noNA_intermediate_train$CreditInq*noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_HOUR_EDIT
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_HOUR_EDIT=NULL
noNA_intermediate_train$Credit_Day=noNA_intermediate_train$CreditInq*noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_DAY_EDIT
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_DAY_EDIT=NULL
noNA_intermediate_train$Credit_Week=noNA_intermediate_train$CreditInq*noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_WEEK_EDIT
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_WEEK_EDIT=NULL
noNA_intermediate_train$Credit_Month=noNA_intermediate_train$CreditInq*noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_MON_EDIT
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_MON_EDIT=NULL
noNA_intermediate_train$Credit_Quarter=noNA_intermediate_train$CreditInq*noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_QRT_EDIT
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_QRT_EDIT=NULL
noNA_intermediate_train$Credit_Year=noNA_intermediate_train$CreditInq*noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_YEAR_EDIT
noNA_intermediate_train$AMT_REQ_CREDIT_BUREAU_YEAR_EDIT=NULL

# External Sources
noNA_intermediate_train$External1=noNA_intermediate_train$EXTS1*noNA_intermediate_train$EXT_SOURCE_1_EDIT
noNA_intermediate_train$External2=noNA_intermediate_train$EXTS2*noNA_intermediate_train$EXT_SOURCE_2_EDIT
noNA_intermediate_train$External3=noNA_intermediate_train$EXTS3*noNA_intermediate_train$EXT_SOURCE_3_EDIT
noNA_intermediate_train$EXT_SOURCE_1_EDIT=NULL
noNA_intermediate_train$EXT_SOURCE_2_EDIT=NULL
noNA_intermediate_train$EXT_SOURCE_3_EDIT=NULL

}
#testing data
{
  # create CO *CA
  noNA_intermediate_test$carOwner_carAge=noNA_intermediate_test$CAR_OWNERSHIP*noNA_intermediate_test$OWN_CAR_AGE_EDIT
  noNA_intermediate_test=subset(noNA_intermediate_test, select=-c(OWN_CAR_AGE_EDIT))
  
  # Social Circles
  noNA_intermediate_test$DEF30=noNA_intermediate_test$DEF_30_CNT_SOCIAL_CIRCLE_EDIT*noNA_intermediate_test$Social
  noNA_intermediate_test$OBS30=noNA_intermediate_test$OBS_30_CNT_SOCIAL_CIRCLE_EDIT*noNA_intermediate_test$Social
  noNA_intermediate_test$DEF60=noNA_intermediate_test$DEF_60_CNT_SOCIAL_CIRCLE_EDIT*noNA_intermediate_test$Social
  noNA_intermediate_test$OBS60=noNA_intermediate_test$OBS_60_CNT_SOCIAL_CIRCLE_EDIT*noNA_intermediate_test$Social
  noNA_intermediate_test$DEF_30_CNT_SOCIAL_CIRCLE_EDIT=NULL
  noNA_intermediate_test$DEF_60_CNT_SOCIAL_CIRCLE_EDIT=NULL
  noNA_intermediate_test$OBS_60_CNT_SOCIAL_CIRCLE_EDIT=NULL
  noNA_intermediate_test$OBS_30_CNT_SOCIAL_CIRCLE_EDIT=NULL
  
  # Credit Bureau
  noNA_intermediate_test$Credit_Hour=noNA_intermediate_test$CreditInq*noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_HOUR_EDIT
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_HOUR_EDIT=NULL
  noNA_intermediate_test$Credit_Day=noNA_intermediate_test$CreditInq*noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_DAY_EDIT
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_DAY_EDIT=NULL
  noNA_intermediate_test$Credit_Week=noNA_intermediate_test$CreditInq*noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_WEEK_EDIT
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_WEEK_EDIT=NULL
  noNA_intermediate_test$Credit_Month=noNA_intermediate_test$CreditInq*noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_MON_EDIT
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_MON_EDIT=NULL
  noNA_intermediate_test$Credit_Quarter=noNA_intermediate_test$CreditInq*noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_QRT_EDIT
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_QRT_EDIT=NULL
  noNA_intermediate_test$Credit_Year=noNA_intermediate_test$CreditInq*noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_YEAR_EDIT
  noNA_intermediate_test$AMT_REQ_CREDIT_BUREAU_YEAR_EDIT=NULL
  
  # External Sources
  noNA_intermediate_test$External1=noNA_intermediate_test$EXTS1*noNA_intermediate_test$EXT_SOURCE_1_EDIT
  noNA_intermediate_test$External2=noNA_intermediate_test$EXTS2*noNA_intermediate_test$EXT_SOURCE_2_EDIT
  noNA_intermediate_test$External3=noNA_intermediate_test$EXTS3*noNA_intermediate_test$EXT_SOURCE_3_EDIT
  noNA_intermediate_test$EXT_SOURCE_1_EDIT=NULL
  noNA_intermediate_test$EXT_SOURCE_2_EDIT=NULL
  noNA_intermediate_test$EXT_SOURCE_3_EDIT=NULL
  
}
## Convert variables into factors 
#training data
{
# Drop ID variable
rownames(noNA_intermediate_train) <- noNA_intermediate_train$SK_ID_CURR
noNA_intermediate_train$SK_ID_CURR = NULL
noNA_intermediate_train$FLAG_MOBIL = NULL

# Transforming categorical variables to factor type
cols = c("TARGET","FLAG_EMP_PHONE","FLAG_WORK_PHONE","FLAG_CONT_MOBILE","FLAG_PHONE","FLAG_EMAIL",
         "HOUR_APPR_PROCESS_START","REG_REGION_NOT_LIVE_REGION","REG_REGION_NOT_WORK_REGION","LIVE_REGION_NOT_WORK_REGION",
         "REG_CITY_NOT_LIVE_CITY","REG_CITY_NOT_WORK_CITY","LIVE_CITY_NOT_WORK_CITY","FLAG_DOCUMENT_2",
         "FLAG_DOCUMENT_3","FLAG_DOCUMENT_4","FLAG_DOCUMENT_5","FLAG_DOCUMENT_6","FLAG_DOCUMENT_7",
         "FLAG_DOCUMENT_8","FLAG_DOCUMENT_9","FLAG_DOCUMENT_10","FLAG_DOCUMENT_11","FLAG_DOCUMENT_12",
         "FLAG_DOCUMENT_13","FLAG_DOCUMENT_14","FLAG_DOCUMENT_15","FLAG_DOCUMENT_16","FLAG_DOCUMENT_17",
         "FLAG_DOCUMENT_18","FLAG_DOCUMENT_19","FLAG_DOCUMENT_20","FLAG_DOCUMENT_21","EXTS1","EXTS2","EXTS3",
         "Social","CreditInq","CAR_OWNERSHIP","REALTY_OWNERSHIP","Female")
noNA_intermediate_train[cols] = lapply(noNA_intermediate_train[cols], factor)
}
#testing data
{
  # Drop ID variable
  rownames(noNA_intermediate_test) <- noNA_intermediate_test$SK_ID_CURR
  noNA_intermediate_test$SK_ID_CURR = NULL
  noNA_intermediate_test$FLAG_MOBIL = NULL
  
  # Transforming categorical variables to factor type
  cols = c("FLAG_EMP_PHONE","FLAG_WORK_PHONE","FLAG_CONT_MOBILE","FLAG_PHONE","FLAG_EMAIL",
           "HOUR_APPR_PROCESS_START","REG_REGION_NOT_LIVE_REGION","REG_REGION_NOT_WORK_REGION","LIVE_REGION_NOT_WORK_REGION",
           "REG_CITY_NOT_LIVE_CITY","REG_CITY_NOT_WORK_CITY","LIVE_CITY_NOT_WORK_CITY","FLAG_DOCUMENT_2",
           "FLAG_DOCUMENT_3","FLAG_DOCUMENT_4","FLAG_DOCUMENT_5","FLAG_DOCUMENT_6","FLAG_DOCUMENT_7",
           "FLAG_DOCUMENT_8","FLAG_DOCUMENT_9","FLAG_DOCUMENT_10","FLAG_DOCUMENT_11","FLAG_DOCUMENT_12",
           "FLAG_DOCUMENT_13","FLAG_DOCUMENT_14","FLAG_DOCUMENT_15","FLAG_DOCUMENT_16","FLAG_DOCUMENT_17",
           "FLAG_DOCUMENT_18","FLAG_DOCUMENT_19","FLAG_DOCUMENT_20","FLAG_DOCUMENT_21","EXTS1","EXTS2","EXTS3",
           "Social","CreditInq","CAR_OWNERSHIP","REALTY_OWNERSHIP","Female")
  noNA_intermediate_test[cols] = lapply(noNA_intermediate_test[cols], factor)
}

## Ploting for variables
{
  set.seed(10)
  app_Train <- noNA_intermediate_train
  app_Test_kaggle <- noNA_intermediate_test
  testing_index <- createDataPartition(noNA_intermediate_train$TARGET, p=0.20, list=FALSE)

  
  # Histogram of Income
  ggplot(app_Train,aes(x=AMT_INCOME_TOTAL))+
    geom_histogram(binwidth = 20000,color="darkblue", fill="lightblue") +
    geom_vline(xintercept = mean(app_Train$AMT_INCOME_TOTAL), color = 'darkred')+
    theme(axis.text.x = element_text(hjust = 1, size = 12))+
    theme(axis.text.y = element_text(hjust = 1, size = 12))+
    xlab("Income") +  
    ylab("Frequency") + 
    ggtitle("Histm of Income")
  # ATM Credit vs. ATM Annuity
  ggplot(app_Train, aes(x = AMT_CREDIT, y = AMT_ANNUITY, colour = AMT_INCOME_TOTAL)) + geom_point()
  # Loan Type vs Loan Amount
  ggplot(data=app_Train, aes(x=NAME_CONTRACT_TYPE, y=(AMT_CREDIT),group=NAME_FAMILY_STATUS,
                             fill=NAME_FAMILY_STATUS))+
    geom_bar(stat="identity")+
    scale_fill_brewer(palette = "Set2") +
    xlab("Loan Type")+
    ylab("Loan Amount")+
    ggtitle("Loan Type VS Loan Amount for Different Family Type")
  
  # Pairwise correlation matrix plot
  ggpairs(app_Train[,c(1,2,4,5)], mapping = aes(color = TARGET), legend = 1) + 
    theme(legend.position = "bottom")
  
  
  
  
  # Custom Classification Tree
  model.tree_Cust <- tree(TARGET~AMT_INCOME_TOTAL + AMT_CREDIT + DAYS_BIRTH + DAYS_EMPLOYED +
                            DAYS_REGISTRATION + DAYS_ID_PUBLISH + DAYS_LAST_PHONE_CHANGE + External1 + External2 +
                            External3 +Credit_Hour + Credit_Day + Credit_Week + Credit_Month +
                            Credit_Quarter + Credit_Year + DEF30 + OBS30+ DEF60+OBS60+
                            carOwner_carAge + FLAG_DOCUMENT_2, data=app_Train)
  
  plot(model.tree_Cust)
  text(model.tree_Cust, label="yval")
  text(model.tree_Cust,label="yprob")
  
  ## Classification Tree with PCA
  # Create the model matrix 
  Mx<- model.matrix(TARGET ~ ., data=app_Train)[,-1]
  if(length(which(colMeans(Mx) == 0))!=0){
    Mx <- Mx[,-which(colMeans(Mx) == 0)] 
  }else {Mx <- Mx}
  My = app_Train$TARGET
  
  test_Mx_subset_index <- sample(1:nrow(Mx),0.2 * nrow(Mx))
  test_Mx_subset <- Mx[test_Mx_subset_index,]
  test_My_subset <- app_Train$TARGET[test_Mx_subset_index]
  app_Logit_test_subset <- data.frame(test_Mx_subset)
  
  
  
  
  # PCA
  xdata = scale(Mx)
  pca.data <- prcomp(xdata, scale=TRUE)
  
  # First plot of top 10 components
  par(mar=c(4,4,4,4)+0.3)
  plot(pca.data,main="PCA: Variance Explained by Factors")
  mtext(side=1, "Factors",  line=1, font=2)
  
  # Compute standard deviation of each principal component
  pr_std <-pca.data$sdev
  
  # Compute variance
  pr_var <- pr_std^2
  
  # Proportion of variance explained
  prop_varex <- pr_var/sum(pr_var)
  plot(cumsum(prop_varex), xlab = "Principal Component",
       ylab = "Cumulative Proportion of Variance Explained",
       type = "b")
  
  
  # Top 30 components explain for about 40% of the variance so we will use these 30 components if the dimension
  # needs to be reduced
  
  app_Train_Tree = data.frame(app_Train,pca.data$x[,1:30])
  model.tree_PCA = tree(TARGET~.,data = app_Train_Tree[,c(1,78:107)])
  # subset data in sample for testing
  a <- sample(1:nrow(app_Train_Tree),0.2*nrow(app_Train_Tree))
  app_Train_Tree_test <- app_Train_Tree[a,c(1,78:107)]
  
  plot(model.tree_PCA)
  text(model.tree_PCA, label="yval")
  text(model.tree_PCA,label="yprob")
  
  #logistic regression
  app_Logit = data.frame(Mx)
  model.logistic_1 = glm(My~., data=app_Logit, family="binomial")
  model.logistic_2 = glm(My~., data=data.frame(app_Train[,-1]), family="binomial")
  
  summary(model.logistic_1)
  summary(model.logistic_2)
  #make prediction(LR,classification tree,classification tree with PCA) & Visualization(ROC curve) with subset in the sample
  
  #ploting using subset of training data(LR)
  predi_logi_subset = predict(model.logistic_1,newdata = app_Logit_test_subset,type = "response")
  outcome=roc(response=test_My_subset,predictor = predi_logi_subset)
  outcome
  plot.roc(outcome)
  #ploting using subset of training data(tree_PCA)
  predi_tree_pca <- predict(model.tree_PCA,type="vector",newdata = app_Train_Tree_test)[,2]
  outcome=roc(response=app_Train_Tree_test$TARGET,predictor = predi_tree_pca)
  outcome
  plot.roc(outcome)
  
  predi_logi_kaggle = predict(model.logistic_2,newdata = data.frame(app_Test_kaggle),type = "response")
  predi_logi_kaggle <- data.frame(predi_logi_kaggle)
  predi_logi_kaggle$SK_ID_CURR <- rownames(predi_logi_kaggle)
  colnames(predi_logi_kaggle)[1] <- "TARGET"
  write.csv(predi_logi_kaggle,"./Home-Credit-Default-Risk-LR.csv")
  
  
  predi_CT <- predict(model.tree_Cust,type="vector",newdata = app_Test_kaggle)[,2]
  predi_CT <- data.frame(predi_CT)
  predi_CT$SK_ID_CURR <- rownames(predi_CT)
  colnames(predi_CT)[1] <- "TARGET"
  write.csv(predi_CT,"./Home-Credit-Default-Risk-CT.csv")
  
}

##Evaluation of different models(K-fold cross-validation)(10 fold)
{
  fold <- 10
  foldid <- rep(1:fold,each=ceiling(nrow(app_Train)/fold))[sample(1:nrow(app_Train))]
  OOS <- data.frame(logistic=rep(NA,fold),tree=rep(NA,fold),
                    tree_pca=rep(NA,fold),null=rep(NA,fold)) 
  for(k in 1:fold){ 
    train <- which(foldid!=k) # train all except "K"
    model.logistic <-glm(My~., data=app_Logit,subset = train, family="binomial")
    model.tree_Cust <- tree(TARGET~AMT_INCOME_TOTAL + AMT_CREDIT + DAYS_BIRTH + DAYS_EMPLOYED +
                              DAYS_REGISTRATION + DAYS_ID_PUBLISH + DAYS_LAST_PHONE_CHANGE + External1 + External2 +
                              External3 +Credit_Hour + Credit_Day + Credit_Week + Credit_Month +
                              Credit_Quarter + Credit_Year + DEF30 + OBS30+ DEF60+OBS60+
                              carOwner_carAge + FLAG_DOCUMENT_2, data=app_Train,subset = train) 
    model.tree_PCA = tree(TARGET~.,data = app_Train_Tree[,c(1,78:107)],subset = train)
    model.null = glm(TARGET~1, data=app_Train, subset=train,family="binomial")
    ## get predictions: type=response so we have probabilities
    pred.logistic <- predict(model.logistic, newdata=app_Logit[-train,], type="response")
    pred.tree <- predict(model.tree_Cust, newdata=app_Train[-train,], type="vector")
    pred.tree <- pred.tree[,2]
    pred.tree.pca <- predict(model.tree_PCA, newdata=app_Train_Tree[-train,], type="vector")
    pred.tree.pca <- pred.tree.pca[,2]
    pred.null <- predict(model.null, newdata=app_Train[-train,], type="response")
    
    ## calculate & log R squared
    # Logistics
    OOS$logistic[k] <- R2(y=My[-train], pred=pred.logistic, family="binomial")
    OOS$logistic[k]
    # Tree
    OOS$tree[k] <- R2(y=app_Train$TARGET[-train], pred=pred.tree, family="binomial")
    OOS$tree[k]
    # PCA Tree
    OOS$tree_pca[k] <- R2(y=app_Train_Tree$TARGET[-train], pred=pred.tree.pca, family="binomial")
    OOS$tree_pca[k]
    #Null
    OOS$null[k] <- R2(y=app_Train$TARGET[-train], pred=pred.null, family="binomial")
    OOS$null[k]
    #Null Model guess
    sum(app_Train$TARGET[train] == 1)/length(train)
  }
}  



