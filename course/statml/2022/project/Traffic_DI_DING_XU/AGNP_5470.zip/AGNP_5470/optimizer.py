import torch.nn.functional as F


def loss_function3(preds, labels, norm, pos_weight):
    return norm * F.binary_cross_entropy_with_logits(preds, labels, pos_weight=pos_weight)
