import numpy as np


def to_categorical(y, num_classes=None, dtype='float32'):
    y = np.array(y, dtype='int')
    input_shape = y.shape
    if input_shape and input_shape[-1] == 1 and len(input_shape) > 1:
        input_shape = tuple(input_shape[:-1])
    y = y.ravel()
    if not num_classes:
        num_classes = np.max(y) + 1
    n = y.shape[0]
    categorical = np.zeros((n, num_classes), dtype=dtype)
    categorical[np.arange(n), y] = 1
    output_shape = input_shape + (num_classes,)
    categorical = np.reshape(categorical, output_shape)
    return categorical


data = np.genfromtxt('node_feature.csv', delimiter=',', skip_header=True)
sub_datas = []
for i in range(data.shape[1]):
    if i == 0 or i == 4 or i == 5:
        sub_data = (data[:, i] * 10).flatten()
    else:
        sub_data = (data[:, i]).flatten()
    sub_data = to_categorical(sub_data)
    sub_datas.append(sub_data)
sub_datas = np.concatenate(sub_datas, axis=1)
np.savetxt('node_feature_processed.csv', sub_datas, fmt='%d', delimiter=',')
