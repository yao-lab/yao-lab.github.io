import torch
import torch.nn as nn
import torch.nn.functional as F
from layers import GraphConvolution, MLP, Attention


class InnerProductDecoder(nn.Module):
    """Decoder for using inner product for prediction."""

    def __init__(self, dropout, act=torch.sigmoid):
        super(InnerProductDecoder, self).__init__()
        self.dropout = dropout
        self.act = act

    def forward(self, z):
        z = F.dropout(z, self.dropout, training=self.training)
        adj = self.act(torch.mm(z, z.t()))
        return adj


class GNP_Encoder(nn.Module):
    def __init__(self, input_dim, hidden_dim1, z_dim, dropout, hidden_dim2=128):
        super(GNP_Encoder, self).__init__()
        self.gc1 = GraphConvolution(input_dim, hidden_dim1, dropout, act=F.relu)
        self.gc2 = GraphConvolution(hidden_dim1, hidden_dim2, dropout, act=lambda x: x)
        self.MLP = MLP(hidden_dim2, [128, 128, 128])
        self.attention = Attention(128, attention_type='multihead', attention_layers=2, rep='identity')
        self.penultimate_layer = nn.Linear(128, 128)
        self.mean_layer = nn.Linear(128, z_dim)
        self.std_layer = nn.Linear(128, z_dim)

    def aggregation(self, mu, logvar):
        std = torch.exp(logvar)
        z_logvar = torch.log(torch.mean(std))
        z_mu = torch.mean(mu)
        return z_mu, z_logvar

    def forward(self, x, adj):
        hidden1 = self.gc1(x, adj)
        hidden2 = self.gc2(hidden1, adj)
        hidden3 = self.MLP(hidden2)
        # hidden_s_i = hidden3
        hidden3 = hidden3.unsqueeze(0)
        hidden_s_i = self.attention(hidden3, hidden3, hidden3)
        hidden_z = torch.relu(self.penultimate_layer(hidden_s_i))
        mu = self.mean_layer(hidden_z)
        # mu (b, 1, latent_dim)
        log_sigma = self.std_layer(hidden_z)
        mu, log_sigma = self.aggregation(mu, log_sigma)
        return mu, log_sigma


class GNP_Decoder(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, dropout, init_func=None):
        super(GNP_Decoder, self).__init__()
        self.l1_size = hidden_dim

        # Two layer of fully connected NNs
        self.l1 = nn.Linear(input_dim, self.l1_size)
        self.l2 = nn.Linear(self.l1_size, output_dim)

        if init_func is not None:
            init_func(self.l1.weight)
            init_func(self.l2.weight)

        self.a = torch.nn.Sigmoid()
        self.reset_parameters()

    def reset_parameters(self):
        # Glorot initialization
        torch.nn.init.xavier_uniform_(self.l1.weight)
        torch.nn.init.xavier_uniform_(self.l2.weight)

    def forward(self, x_pred, z):
        """x_pred: No. of data points, by x_dim
        z: No. of samples, by z_dim
        """
        zs_reshaped = z.unsqueeze(-1).expand(z.shape[0], z.shape[1], x_pred.shape[0]).transpose(1, 2)
        xpred_reshaped = x_pred.unsqueeze(0).expand(z.shape[0], x_pred.shape[0], x_pred.shape[1])

        xz = torch.cat([xpred_reshaped, zs_reshaped], dim=2)
        return self.l2(self.a(self.l1(xz))).squeeze(-1).transpose(0, 1), 0.005
