import argparse
import hashlib
import json
from pathlib import Path
import pandas as pd
import numpy as np
import os.path as op
import time
import torch
from torch import nn
import matplotlib.pyplot as plt
from tqdm import tqdm


# constants
# the two below are given by https://dachxiu.chicagobooth.edu/download/img_demo.html
IMAGE_WIDTH = {5: 15, 20: 60, 60: 180}
IMAGE_HEIGHT = {5: 32, 20: 64, 60: 96}

# these below are all from the paper
YEAR_START = 1993
YEAR_END = 2019    # inclusive
YEAR_SPLIT = 2000  # 1993-1999 for training/validation, 2000-2019 for testing


class OHLC20DaysDataset(torch.utils.data.Dataset):
    def __init__(self, data_root, days_of_ret, year):
        images_path = op.join(data_root, f'20d_month_has_vb_[20]_ma_{year}_images.dat')
        images = np.memmap(images_path, dtype=np.uint8, mode='r')
        images = images.reshape((-1, 1, IMAGE_HEIGHT[20], IMAGE_WIDTH[20]))

        labels_path = op.join(data_root, f'20d_month_has_vb_[20]_ma_{year}_labels_w_delay.feather')
        labels_df = pd.read_feather(labels_path)
        labels = labels_df[f'Ret_{days_of_ret}d']

        missing = labels.isna()
        images = images[~missing]
        labels = labels[~missing]
        print(f'year {year}: {sum(missing)} data with missing label ignored')

        self.images = torch.tensor(images, dtype=torch.float)
        self.labels = torch.tensor(labels > 0, dtype=torch.long)
        
    def __getitem__(self, index):
        return self.images[index], self.labels[index]
    
    def __len__(self):
        return self.images.size(0)
    

class CNN20Days(nn.Module):
    INPUT_SHAPE = (1, 64, 60)
    def __init__(self, args):
        super(CNN20Days, self).__init__()
        self.layers = args.layers

        padding = [(args.filter_size[i] // 2) * args.dilation[i] for i in range(2)]
        block = nn.Sequential(
            nn.Conv2d(in_channels=self.INPUT_SHAPE[0], out_channels=args.filters, kernel_size=args.filter_size,
                    stride=args.stride, dilation=args.dilation, padding=padding),
            nn.BatchNorm2d(args.filters) if not args.disable_bn else nn.Identity(),
            nn.LeakyReLU(0.01) if args.activation == 'lrelu' else nn.ReLU(),
            nn.MaxPool2d(kernel_size=args.max_pool_size),
        )
        self.add_module('block1', block)

        padding = [(args.filter_size[i] // 2) for i in range(2)]
        in_channels = args.filters
        out_channels = 128
        for l in range(1, args.layers):
            block = nn.Sequential(
                nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=args.filter_size,
                        padding=padding),
                nn.BatchNorm2d(out_channels) if not args.disable_bn else nn.Identity(),
                nn.LeakyReLU(0.01) if args.activation == 'lrelu' else nn.ReLU(),
                nn.MaxPool2d(kernel_size=args.max_pool_size, ceil_mode=True),
            )
            self.add_module(f'block{l+1}', block)
            in_channels = out_channels
            out_channels *= 2
        
        self.dropout = nn.Dropout(p=args.dropout)
        featmap_h = ((self.INPUT_SHAPE[1]-1) // args.stride[0] + 1) // args.max_pool_size[0]
        featmap_w = ((self.INPUT_SHAPE[2]-1) // args.stride[1] + 1) // args.max_pool_size[1]
        print(featmap_h, featmap_w)
        for l in range(1, args.layers):
            if featmap_h % 2:
                featmap_h += 1
            if featmap_w % 2:
                featmap_w += 1
            featmap_h //= args.max_pool_size[0]
            featmap_w //= args.max_pool_size[1]
        print(out_channels // 2, featmap_h, featmap_w)
        self.fc = nn.Linear((out_channels // 2) * featmap_h * featmap_w, 2)

        if not args.disable_xavier:
            self.init_weights()

    def init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.xavier_uniform_(m.weight)
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                m.bias.data.fill_(0.)

    def forward(self, x):
        for l in range(self.layers):
            module = self.get_submodule(f'block{l+1}')
            x = module(x)
        x = self.dropout(x.flatten(1))
        x = self.fc(x)
        return x
    

class EarlyStopping:
    """Early stops the training if validation loss doesn't improve after a given patience."""
    def __init__(self, patience=7, verbose=False, delta=0, path='checkpoint.pt', trace_func=print):
        """
        Args:
            patience (int): How long to wait after last time validation loss improved.
                            Default: 7
            verbose (bool): If True, prints a message for each validation loss improvement. 
                            Default: False
            delta (float): Minimum change in the monitored quantity to qualify as an improvement.
                            Default: 0
            path (str): Path for the checkpoint to be saved to.
                            Default: 'checkpoint.pt'
            trace_func (function): trace print function.
                            Default: print            
        """
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta
        self.path = path
        self.trace_func = trace_func

    def __call__(self, val_loss, model):
        score = -val_loss
        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
        elif score < self.best_score + self.delta:
            self.counter += 1
            self.trace_func(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model)
            self.counter = 0

    def save_checkpoint(self, val_loss, model):
        '''Saves model when validation loss decrease.'''
        if self.val_loss_min != np.Inf:
            if self.verbose:
                self.trace_func(f'Validation loss decreased by {self.val_loss_min-val_loss:e}.  Saving model ...')
            torch.save(model.state_dict(), self.path)
        self.val_loss_min = val_loss


class AverageMeter:
    def __init__(self):
        self.n = 0
        self.s = 0

    def update(self, n, m):
        self.n += n
        self.s += m * n

    @property
    def average(self):
        return self.s / self.n


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_root', type=str, required=True)
    parser.add_argument('--days_of_ret', type=int, choices=(5, 20, 60), required=True)
    parser.add_argument('--output_root', type=str, default='outputs')
    # default hyperparameters following the original paper
    parser.add_argument('--valid_portion', type=float, default=0.3)
    parser.add_argument('--batch_size', type=int, default=128)
    parser.add_argument('--lr', type=float, default=1e-5)
    parser.add_argument('--patience', type=int, default=2)
    # ablation study (sensitivity analysis)
    parser.add_argument('--filters', type=int, default=64)
    parser.add_argument('--layers', type=int, default=3)
    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--disable_bn', action='store_true')
    parser.add_argument('--disable_xavier', action='store_true')
    parser.add_argument('--activation', type=str, choices=('relu', 'lrelu'), default='lrelu')
    parser.add_argument('--max_pool_size', type=int, nargs='+', default=(2, 1))
    parser.add_argument('--filter_size', type=int, nargs='+', default=(5, 3))
    parser.add_argument('--dilation', type=int, nargs='+', default=(2, 1))
    parser.add_argument('--stride', type=int, nargs='+', default=(3, 1))
    # other arguments
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--max_epochs', type=int, default=50)
    parser.add_argument('--num_workers', type=int, default=0)

    args = parser.parse_args()
    args_str = json.dumps(vars(args), sort_keys=True)
    args_hash = hashlib.md5(args_str.encode('utf-8')).hexdigest()
    output_dir = Path(args.output_root, args_hash)
    output_dir.mkdir(parents=True, exist_ok=True)
    with output_dir.joinpath('args.json').open('w') as f:
        json.dump(vars(args), f, sort_keys=True)

    # set random seeds for reproducibility
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    # load and split data
    datasets = []

    for year in range(YEAR_START, YEAR_END+1):
        dataset = OHLC20DaysDataset(args.data_root, args.days_of_ret, year)
        datasets.append(dataset)

    # divide sample into two parts
    # the first seven years as the training/validation set, and the rest as the test set
    train_and_valid_data = torch.utils.data.ConcatDataset(datasets[:YEAR_SPLIT-YEAR_START]) 
    test_data = torch.utils.data.ConcatDataset(datasets[YEAR_SPLIT-YEAR_START:])

    # split train_and_valid_data into training and validation data 
    num_train_and_valid = len(train_and_valid_data)
    indices = list(range(num_train_and_valid))
    np.random.shuffle(indices)
    split = round(args.valid_portion * num_train_and_valid)
    train_idx, valid_idx = indices[split:], indices[:split]

    # define samplers for obtaining training and validation data separately
    train_sampler = torch.utils.data.SubsetRandomSampler(train_idx)
    valid_sampler = torch.utils.data.SubsetRandomSampler(valid_idx)

    # define dataloaders for train, validation, and test data
    train_loader = torch.utils.data.DataLoader(train_and_valid_data,
                                            batch_size=args.batch_size,
                                            sampler=train_sampler,
                                            num_workers=args.num_workers,
                                            drop_last=True)

    valid_loader = torch.utils.data.DataLoader(train_and_valid_data,
                                            batch_size=args.batch_size,
                                            sampler=valid_sampler,
                                            num_workers=args.num_workers)

    test_loader = torch.utils.data.DataLoader(test_data,
                                            batch_size=args.batch_size,
                                            num_workers=args.num_workers)

    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = CNN20Days(args)
    print(model)
    total_num_training_parameters = 0
    for _, param in model.named_parameters():
        if param.requires_grad:
            total_num_training_parameters += np.product(param.size())
    print(f'#total params: {total_num_training_parameters}')
    model = model.to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    since = time.time()
    checkpoint_path = str(output_dir.joinpath('checkpoint.pt'))
    early_stopping = EarlyStopping(patience=args.patience, verbose=True, path=checkpoint_path)
    train_loss_stats = []
    valid_loss_stats = []

    def train_epoch():
        train_loss = AverageMeter()
        model.train()  # set the model in training mode
        for i, (data, target) in tqdm(enumerate(train_loader), desc=f'  Training progress',
                                      total=len(train_loader)):
            data = data.to(device)
            target = target.to(device)

            output = model(data)
            loss = criterion(output, target)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            train_loss.update(data.size(0), loss.item())
            train_loss_stats.append((epoch + i / len(train_loader), loss.item()))
        return train_loss

    def eval():
        valid_loss = AverageMeter()
        model.eval()  # set the model in evaluation mode
        for data, target in tqdm(valid_loader, desc=f'Validation progress'):
            data = data.to(device)
            target = target.to(device)

            with torch.no_grad():
                output = model(data)
                loss = criterion(output, target)

            valid_loss.update(data.size(0), loss.item())
        valid_loss_stats.append((epoch + 1, valid_loss.average))
        return valid_loss

    print('### Initial validation')
    epoch = -1
    valid_loss = eval()
    print(f'Validation loss: {valid_loss.average:.3e}')
    early_stopping(valid_loss.average, model)

    print('### Training started')
    for epoch in range(args.max_epochs):
        print(f'### Epoch {epoch+1:2d}/{args.max_epochs}')
        train_loss = train_epoch()
        valid_loss = eval()

        print(f'  Training loss: {train_loss.average:.3e}')
        print(f'Validation loss: {valid_loss.average:.3e}')
        
        # early_stopping needs the validation loss to check if it has decresed, 
        # and if it has, it will make a checkpoint of the current model
        early_stopping(valid_loss.average, model)
        if early_stopping.early_stop:
            print("Early stopping")
            break
        
    # load the last checkpoint with the best model
    model.load_state_dict(torch.load(checkpoint_path))
    
    # report the time on training
    time_elapsed = time.time() - since
    print(f'Training complete in {time_elapsed // 60:.0f}m {time_elapsed % 60:.0f}s')

    # plot loss curves
    fig = plt.figure()
    x, y = zip(*train_loss_stats)
    plt.plot(x[::100], y[::100], label='Training Loss')
    plt.plot(*zip(*valid_loss_stats), label='Validation Loss')
    plt.xlabel('epochs')
    plt.ylabel('loss')
    plt.yscale('log')
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    fig.savefig(str(output_dir.joinpath('loss_curves.pdf')), bbox_inches='tight')