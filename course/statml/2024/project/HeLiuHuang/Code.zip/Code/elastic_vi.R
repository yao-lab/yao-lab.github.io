rm(list=ls())
root = "/home/huangruizhao/GithubRepos/Empirical-Asset-Pricing-XDC"
setwd(root)
source('config.R')

load('./elastic_output/30.RData')
calendar.m <- unique(full.predictor[, 'yyyymm'])
timeline.m <- TimelineGenerator(calendar.m, train.wd=18, val.wd=12, test.wd=1, refit.freq=1)

train_begin <- timeline.m[30, ]$train_begin
train_end <- timeline.m[30, ]$train_end
X.train <- full.predictor[order(yyyymm, permno) & yyyymm >= train_begin & yyyymm <= train_end, !c("yyyymm", "permno"), with = FALSE]
Y.train <- RETs[order(yyyymm, permno) & yyyymm >= train_begin & yyyymm <= train_end, !c("yyyymm", "permno"), with = FALSE]$RET

all.pred <- predict(elastic.fit, newx = data.matrix(X.train), type = "response", s = lambda.opt)
all.oos.R2 <- oos_R2(y.GT = Y.train, y.pred = all.pred)

var.names <- colnames(X.train)[1:102]
mod.oos.R2 <- mclapply(var.names, function(var){
    print(var)
    args <- list(var = var, model = elastic.fit, X = copy(X.train), Y = Y.train, lambda = lambda.opt)
    do.call("elastic_vi", args)
    }, mc.cores = 15)
mod.oos.R2 <- unlist(mod.oos.R2)

reduce.oos.R2 <- all.oos.R2 - mod.oos.R2
indices <- order(reduce.oos.R2, decreasing = TRUE)
a = tibble(var = var.names[indices], vi = reduce.oos.R2[indices])
write.csv(a, file='elastic_vi.csv', row.names=FALSE)
