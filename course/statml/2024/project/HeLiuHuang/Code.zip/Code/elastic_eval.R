rm(list=ls())
root = "/home/huangruizhao/GithubRepos/Empirical-Asset-Pricing-XDC"
setwd(root)
source('config.R')

calendar.m <- unique(full.predictor[, 'yyyymm'])
timeline.m <- TimelineGenerator(calendar.m, train.wd=18, val.wd=12, test.wd=1, refit.freq=1)

test.all <- NULL
lambda.val <- c()
for(i in seq_len(nrow(timeline.m))) {
  print(i)
  load(paste0("./elastic_output/", i, ".RData"))
  test.all <- rbind(test.all, test.table)
  lambda.val <- c(lambda.val, lambda.opt)
}

all <- merge(test.all, RETs, by = c('yyyymm', 'permno', 'RET'))
top <- all[, .SD[order(-mve0, na.last = NA)][1:1000], by = yyyymm]
bottom <- all[, .SD[order(mve0, na.last = NA)][1:1000], by = yyyymm]  # Bottom 1000

all.oos.R2 <- oos_R2(y.GT = all$RET, y.pred = all$elastic)
top.oos.R2 <- oos_R2(y.GT = top$RET, y.pred = top$elastic)
bottom.oos.R2 <- oos_R2(y.GT = bottom$RET, y.pred = bottom$elastic)
res <- tibble(method = 'elastic', all = all.oos.R2, top = top.oos.R2, bottom = bottom.oos.R2)
save(res, file='elastic_res.RData')



