rm(list=ls())
root = "/home/huangruizhao/GithubRepos/Empirical-Asset-Pricing-XDC"
setwd(root)
source('config.R')

calendar.m <- unique(full.predictor[, 'yyyymm'])
timeline.m <- TimelineGenerator(calendar.m, train.wd=18, val.wd=12, test.wd=1, refit.freq=1)

test.all <- NULL
n.trees.val <- c()
for(i in seq_len(nrow(timeline.m))) {
  print(i)

  train_begin <- timeline.m[i, ]$train_begin
  train_end <- timeline.m[i, ]$train_end
  val_begin <- timeline.m[i, ]$val_begin
  val_end <- timeline.m[i, ]$val_end
  test_begin <- timeline.m[i, ]$test_begin
  test_end <- timeline.m[i, ]$test_end

  load(paste0("./GBRT_models/", i, ".RData"))
  
  n.trees = seq(from = 10, to = 500, by = 10) #no of trees-a vector of 100 values
  X.val <- full.predictor[order(yyyymm, permno) & yyyymm >= val_begin & yyyymm <= val_end, !c("yyyymm", "permno"), with = FALSE]
  GBRT.val.pred <- predict(GBRT.fit, X.val, n.trees = n.trees)
  rm(X.val)
  Y.val <- RETs[order(yyyymm, permno) & yyyymm >= val_begin & yyyymm <= val_end, !c("yyyymm", "permno"), with = FALSE]$RET
  GBRT.oos.R2 <- apply(GBRT.val.pred, 2, function(x) oos_R2(Y.val, x))
  n.trees.opt <- n.trees[which.max(GBRT.oos.R2)]
  rm(GBRT.val.pred, Y.val)
  
  X.test <- full.predictor[order(yyyymm, permno) & yyyymm >= test_begin & yyyymm <= test_end, !c("yyyymm", "permno"), with = FALSE]
  # Y.test <- RETs[order(yyyymm, permno) & yyyymm >= test_begin & yyyymm <= test_end, !c("yyyymm", "permno"), with = FALSE]$RET
  test.table <- RETs[order(yyyymm, permno) & yyyymm >= test_begin & yyyymm <= test_end]
  test.table[ , GBRT := predict(GBRT.fit, X.test, n.trees = n.trees.opt)]
  rm(X.test)
  
  test.all <- rbind(test.all, test.table)
  n.trees.val <- c(n.trees.val, n.trees.opt)
  rm(test.table)
}

save(test.all, n.trees.val, file='GRBT_output.RData')

all <- test.all
top <- all[, .SD[order(-mve0, na.last = NA)][1:1000], by = yyyymm]
bottom <- all[, .SD[order(mve0, na.last = NA)][1:1000], by = yyyymm]  # Bottom 1000

all.oos.R2 <- oos_R2(y.GT = all$RET, y.pred = all$GBRT)
top.oos.R2 <- oos_R2(y.GT = top$RET, y.pred = top$GBRT)
bottom.oos.R2 <- oos_R2(y.GT = bottom$RET, y.pred = bottom$GBRT)
res <- tibble(method = 'GBRT', all = all.oos.R2, top = top.oos.R2, bottom = bottom.oos.R2)
save(res, file='GRBT_res.RData')
