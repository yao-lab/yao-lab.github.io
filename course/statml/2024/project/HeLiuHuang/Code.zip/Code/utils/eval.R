oos_R2 <- function(y.GT, y.pred){
  return(1 - (sum((y.GT - y.pred)^2) / sum(y.GT^2)))
}

GBRT_vi <- function(var, model, X, Y, n.trees) {
  X[[var]] <- 0  
  mod.pred <- predict(GBRT.fit, X, n.trees = n.trees)
  return(oos_R2(y.GT = Y, y.pred = mod.pred))
}

elastic_vi <- function(var, model, X, Y, lambda) {
  X[[var]] <- 0  
  mod.pred <- predict(model, newx = data.matrix(X), type = "response", s = lambda)
  return(oos_R2(y.GT = Y, y.pred = mod.pred))
}
