# ------- stock data ------- #
stock.dt <- setDT(fread(stock.file))
stock.dt[, `:=` (yyyymm = DATE %/% 100)]
setcolorder(stock.dt, c("yyyymm", names(stock.dt)[!names(stock.dt) %in% c("yyyymm")]))
stock.dt <- stock.dt[yyyymm >= 195703 & yyyymm <= 201612]


# ------- macro data ------- #
macro.dt <- setDT(read_excel(macro.file))
macro.dt[, names(macro.dt) := lapply(.SD, function(x) {
  if (is.character(x)) {
    as.numeric(as.character(x))
  } else {
    x
  }
}), .SDcols = names(macro.dt)]
macro.dt <- macro.dt[yyyymm >= 195703 & yyyymm <= 201612]
macro.dt[, `:=` (IndexDiv = Index + D12,
                 dp = log(D12) - log(Index),
                 ep_macro = log(E12) - log(Index),
                 tms = as.numeric(ltr) - as.numeric(tbl),
                 dfy = as.numeric(BAA) - as.numeric(AAA))]
setnames(macro.dt, 'b/m', 'bm_macro')


# ------- join data ------- #
char.names <- setdiff(colnames(stock.dt), c("yyyymm", "permno", "DATE", "RET", "prc", "SHROUT", "sic2", "mve0"))
macro.names <- c('dp', 'ep_macro', 'bm_macro', 'ntis', 'tbl', 'svar', 'tms', 'dfy')
join.dt <- merge(stock.dt, macro.dt, by = "yyyymm", all.x = TRUE)
join.dt <- na.omit(join.dt, cols = "sic2")
rm(stock.dt, macro.dt)


# ------- dummy and return data ------- #
dummy <- join.dt[, .(yyyymm, permno, sic2)]
RETs <- join.dt[, .(yyyymm, permno, RET, mve0)]


# ------- characteristic, macro and dummy predictors ------- #
char.predictor <- join.dt[, .SD, .SDcols = c("yyyymm", "permno", char.names)]
macro.predictor <- unique(join.dt[, .SD, .SDcols = c("yyyymm", macro.names)])
char.predictor <- CsRankStd(char.predictor, group_cols = "yyyymm", permno_col = 'permno')
dummy.predictor <- DummyVars(dummy, 'sic2')
rm(join.dt)


# ------- cross predictors ------- #
join.predictor <- merge(char.predictor, macro.predictor, by = "yyyymm", all.x = TRUE)
# join.predictor <- GroupwiseKroneckerParallel(join.predictor[1:1000000, ], group_cols=c('yyyymm', 'permno'),
#                                              spec_cols=colnames(char.predictor)[-c(1:2)], batch_size=2000, num_cores = 60)

group_cols <- c('yyyymm', 'permno')
spec_cols <- colnames(char.predictor)[-c(1:2)]
batch_size <- 2000
batch_indices <- cut(seq(nrow(join.predictor)),
                     breaks = seq(1, nrow(join.predictor) + 1, by = batch_size), 
                     include.lowest = TRUE,
                     right = FALSE, 
                     labels = FALSE) 

if (any(is.na(batch_indices))) {
    batch_indices[is.na(batch_indices)] <- max(batch_indices, na.rm = TRUE)
}
batches <- split(join.predictor, batch_indices)
if (sum(sapply(batches, nrow)) != nrow(join.predictor)){
  stop('Error when spliting data into batches.')
}
cl <- makeCluster(60)
parallel::clusterExport(cl, list("GroupwiseKronecker", "group_cols", "spec_cols"))
parallel::clusterEvalQ(cl, library(data.table))
tryCatch({
  results <- pblapply(batches, function(batch) {
    GroupwiseKronecker(batch, group_cols, spec_cols)
  }, cl = cl)
  parallel::stopCluster(cl)
  cross.predictor <- rbindlist(results, use.names = TRUE, fill = TRUE)
}, error = function(e) {
    parallel::stopCluster(cl)
    stop("Error when parallel processing: ", e$message)
})


# ------- full predictors ------- #
# full.predictor <- merge(join.predictor, dummy.predictor, by = c("yyyymm", 'permno'))
full.predictor <- merge(cross.predictor, dummy.predictor, by = c("yyyymm", 'permno'))


# ------- save data ------- #
write_parquet(full.predictor, predictor.file)
write_parquet(RETs, rets.file)



