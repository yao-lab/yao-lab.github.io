DummyVars <- function(dt, dummy_col) {
  if (!inherits(dt, "data.table")) {
    setDT(dt)
  }
  if (!dummy_col %in% names(dt)) {
    stop("Specified column does not exist in the data.table.")
  }
  if (is.numeric(dt[[dummy_col]])) {
    dt[[dummy_col]] <- as.factor(dt[[dummy_col]])
  }
  dummy_vars <- as.data.table(model.matrix(~ get(dummy_col) - 1, data=dt))
  setnames(dummy_vars, paste("dummy", seq_len(ncol(dummy_vars)), sep = ""))
  dummy_dt <- cbind(dt, dummy_vars)
  dummy_dt[, (dummy_col) := NULL]
  return(copy(dummy_dt))
}


CsRankStd <- function(dt, group_cols, permno_col, na_method = "impute") {
  if (!inherits(dt, "data.table")) {
    setDT(dt)
  }
  # Check if input columns exist in the data.table
  if (!all(group_cols %in% names(dt))) {
    stop("One or more group columns do not exist in the data.table.")
  }

  # Set the key for the data.table for efficient grouping
  setkeyv(dt, group_cols)

  # Define columns to process, excluding group and permno columns
  process_cols <- setdiff(names(dt), c(group_cols, permno_col))
  permno <- dt[, ..permno_col]
  
  # Apply normalization based on the chosen NA method
  normalized_data <- dt[, lapply(.SD, function(x) {
    if (na_method == "omit") {
      if (sum(!is.na(x)) > 1) {
        # Keep NA values in place, adjust the rank computation to not include NAs in the rank calculation
        ranks <- rank(x, ties.method = "average", na.last = "keep")
        return((ranks - 1) / (sum(!is.na(x)) - 1) * 2 - 1)
      } else {
        return(rep(NA_real_, length(x)))  # Return NA for all if only one or zero non-NA values
      }
    } else if (na_method == "impute") {
      if (all(is.na(x))) {
        return(rep(0, length(x)))  # Assign a default value of 0 to all items if all are NA
      } else {
        # Imputing NAs with median
        if (any(is.na(x))) {
          x[is.na(x)] <- median(x, na.rm = TRUE)  # Replace NA with median
        }
        if (length(x) > 1) {
          ranks <- rank(x, ties.method = "average")
          return((ranks - 1) / (length(x) - 1) * 2 - 1)
        } else {
          return(0)  # Return 0 if only one value
        }
      }
    } else {
      stop("Invalid NA method specified. Choose either 'omit' or 'impute'.")
    }
  }), .SDcols = process_cols, by = group_cols]

  return(cbind(permno, normalized_data))
}


GroupwiseKronecker <- function(dt, group_cols, spec_cols) {
  # if (!inherits(dt, "data.table")) {
  #   setDT(dt)
  # }
  # # Check if input columns exist in the data.table
  # if (!all(c(group_cols, spec_cols) %in% names(dt))) {
  #   stop("One or more group columns do not exist in the data.table.")
  # }
  # setkeyv(dt, group_cols)

  # Calculate other columns that are not group or spec columns
  other_cols <- setdiff(names(dt), c(group_cols, spec_cols))

  # Define a function to compute the Kronecker product and reshape
  compute_kronecker <- function(sub_dt, spec_cols, other_cols) {
    spec_data <- as.matrix(sub_dt[, ..spec_cols])
    other_data <- as.matrix(sub_dt[, ..other_cols])
    kronecker_res <- kronecker(spec_data, other_data)
    
    # Generate new column names
    new_col_names <- outer(spec_cols, other_cols, FUN = function(x, y) paste0(x, "*", y))
    
    # Convert the Kronecker result to a data.table and set column names
    kronecker_dt <- as.data.table(kronecker_res)
    setnames(kronecker_dt, colnames(kronecker_dt), as.vector(new_col_names))
    
    # Return the result with original spec columns included
    cbind(sub_dt[, ..spec_cols, with = FALSE], kronecker_dt)
  }

  # Apply function to each group
  results <- dt[, compute_kronecker(.SD, spec_cols, other_cols), by = mget(group_cols), .SDcols = c(spec_cols, other_cols)]
  
  return(results)
}


# TODO the parallel wrap in function does not work robustly, but works perfect outside, need to fix it
GroupwiseKroneckerParallel <- function(dt, group_cols, spec_cols, batch_size = NULL, num_cores = 4) {
  if (!inherits(dt, "data.table")) {
    data.table::dt <- setDT(dt)
  }
  if (!all(c(group_cols, spec_cols) %in% names(dt))) {
    stop("One or more group columns do not exist in the data.table.")
  }
  data.table::setkeyv(dt, group_cols)
  batch_indices <- cut(seq(nrow(dt)),
                       breaks = seq(1, nrow(dt) + 1, by = batch_size), 
                       include.lowest = TRUE,
                       right = FALSE, 
                       labels = FALSE) 

  if (any(is.na(batch_indices))) {
      batch_indices[is.na(batch_indices)] <- max(batch_indices, na.rm = TRUE)
  }
  batches <- split(dt, batch_indices)
  if (sum(sapply(batches, nrow)) != nrow(dt)){
    stop('Error when spliting data into batches.')
  }

  # Define global variables
  .GlobalEnv$group_cols <- group_cols
  .GlobalEnv$spec_cols <- spec_cols

  cl <- makeCluster(num_cores)
  parallel::clusterExport(cl, list("GroupwiseKronecker", "group_cols", "spec_cols"))
  parallel::clusterEvalQ(cl, library(data.table))
  
  tryCatch({
    results <- pblapply(batches, function(batch) {
      GroupwiseKronecker(batch, group_cols, spec_cols)
    }, cl = cl)
    parallel::stopCluster(cl)
  }, error = function(e) {
      parallel::stopCluster(cl)
      stop("Error when parallel processing: ", e$message)
  })
  return(data.table::rbindlist(results))
}


TimelineGenerator <- function(calendar.m, train.wd, val.wd, test.wd, refit.freq){
# Define the function to generate a timeline for data partitioning into training, validation, and testing periods.
# It adjusts the timeline each year based on refitting frequency.
#
# Args:
#   @param calendar.m: A data.table with a single column 'yyyymm' representing monthly dates.
#   @param train.wd: Training window duration in years.
#   @param val.wd: Validation window duration in years.
#   @param test.wd: Testing window duration in years.
#   @param refit.freq: Frequency in years to refit or update the model.
#
# Returns:
#   @return A data.table with calculated start and end yyyymm for training, validation, and testing periods.

  # Convert the duration and frequency from years to months for detailed calculations.
  train.wd <- train.wd * 12
  val.wd <- val.wd * 12
  test.wd <- test.wd * 12
  refit.freq <- refit.freq * 12

  # Initialize the timeline using the unique yyyymm from the input calendar.
  timeline <- unique(calendar.m[, .(yyyymm)])
  start.date <- min(calendar.m$yyyymm)
  
  # Calculate the end of training, beginning and end of validation, and beginning and end of testing windows using shifts.
  timeline[, train_begin := start.date]
  timeline[, train_end := shift(yyyymm, type = "lead", n = train.wd - 1)] 
  timeline[, val_begin := shift(train_end, type = "lead", n = 1)]
  timeline[, val_end := shift(val_begin, type = "lead", n = val.wd - 1)] 
  timeline[, test_begin := shift(val_end, type = "lead", n = 1)]
  timeline[, test_end := shift(test_begin, type = "lead", n = test.wd - 1)] 
  timeline[, yyyymm := NULL]

  # Remove rows with NA values that occur due to shifts beyond the data range.
  timeline <- na.omit(timeline, by='test_end')

  # Select rows according to the refitting frequency.
  timeline <- timeline[(seq(1, .N, refit.freq)), ]

  # Add a new row if the maximum date in the timeline is less than the maximum date in the calendar.
  if (max(timeline$test_end) < max(calendar.m$yyyymm)) {
    new_row <- timeline[nrow(timeline), .(train_begin, train_end, val_begin, val_end, test_begin, test_end)] 
    new_row[, `:=` (train_begin = start.date,
                    train_end = train_end + 100*refit.freq/12,
                    val_begin = val_begin + 100*refit.freq/12,
                    val_end = val_end + 100*refit.freq/12,
                    test_begin = test_begin + 100*refit.freq/12,
                    test_end = max(calendar.m$yyyymm))]
    timeline <- rbind(timeline, new_row)
  }
  return(timeline)
}
