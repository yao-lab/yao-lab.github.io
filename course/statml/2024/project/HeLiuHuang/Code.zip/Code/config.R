library(readxl)
library(tidyverse)
library(data.table)
library(lubridate)
library(glmnet)
library(pbapply)
library(MASS)
library(gbm)
library(arrow)
library(parallel)

data.dir <- '/mnt/ExtDiskC/ruizhao/Empirical-AP-ML-Data'
macro.file <- file.path(data.dir, 'PredictorData2023.xlsx')
stock.file <- file.path(data.dir, 'GKX_20201231.csv')
predictor.file <- file.path(data.dir, 'predictor_v2.parquet')
rets.file <- file.path(data.dir, 'rets.parquet')
source('./utils/DataHandler.R')
source('./utils/eval.R')
if (file.exists(predictor.file) & file.exists(rets.file)){
    full.predictor <- read_parquet(predictor.file)
    RETs <- read_parquet(rets.file)
}else{
    source('./utils/DataLoader.R')
}
