rm(list=ls())
root = "/home/huangruizhao/GithubRepos/Empirical-Asset-Pricing-XDC"
setwd(root)
source('config.R')

calendar.m <- unique(RETs[, 'yyyymm'])
timeline.m <- TimelineGenerator(calendar.m, train.wd=18, val.wd=12, test.wd=1, refit.freq=1)

for(i in seq_len(nrow(timeline.m))) {
  print(i)

  train_begin <- timeline.m[i, ]$train_begin
  train_end <- timeline.m[i, ]$train_end
  val_begin <- timeline.m[i, ]$val_begin
  val_end <- timeline.m[i, ]$val_end
  test_begin <- timeline.m[i, ]$test_begin
  test_end <- timeline.m[i, ]$test_end
  
#   load(file.path(data.dir, predictor.file))

  X.train <- data.matrix(full.predictor[order(yyyymm, permno) & yyyymm >= train_begin & yyyymm <= train_end, !c("yyyymm", "permno"), with = FALSE])
  Y.train <- RETs[order(yyyymm, permno) & yyyymm >= train_begin & yyyymm <= train_end, !c("yyyymm", "permno"), with = FALSE]$RET
  # if (i == nrow(timeline.m)){
  #   rm(full.predictor)
  # }
#   rm(full.predictor, RETs)

  # gradient boosting regression trees
  GBRT.fit = gbm.fit(x = X.train, y = Y.train,
                   distribution = "gaussian",
                   n.trees = 500, shrinkage = 0.01,
                   interaction.depth = 1, keep.data = FALSE)
  rm(X.train, Y.train)
  save(timeline.m, i, GBRT.fit, file=paste0("GBRT_models/", i, ".RData"))

  # n.trees = seq(from = 10, to = 100, by = 10) #no of trees-a vector of 100 values
  # X.val <- full.predictor[order(yyyymm, permno) & yyyymm >= val_begin & yyyymm <= val_end, !c("yyyymm", "permno"), with = FALSE]
  # GBRT.val.pred <- predict(GBRT.fit, X.val, n.trees = n.trees)
  # rm(X.val)
  # Y.val <- RETs[order(yyyymm, permno) & yyyymm >= val_begin & yyyymm <= val_end, !c("yyyymm", "permno"), with = FALSE]$RET
  # GBRT.oos.R2 <- apply(GBRT.val.pred, 2, function(x) oos_R2(Y.val, x))
  # n.trees.opt <- n.trees[which.max(GBRT.oos.R2)]
  # rm(GBRT.val.pred, Y.val)
  #
  # X.test <- full.predictor[order(yyyymm, permno) & yyyymm >= test_begin & yyyymm <= test_end, !c("yyyymm", "permno"), with = FALSE]
  # # Y.test <- RETs[order(yyyymm, permno) & yyyymm >= test_begin & yyyymm <= test_end, !c("yyyymm", "permno"), with = FALSE]$RET
  # test.table <- RETs[order(yyyymm, permno) & yyyymm >= test_begin & yyyymm <= test_end]
  # test.table[ , GBRT := predict(GBRT.fit, X.test, n.trees = n.trees.opt)]
  # rm(X.test)
  #
  # save(timeline.m, i, test.table, GBRT.fit, n.trees.opt, file=paste0("GBRT_output/", i, ".RData"))
  # rm(test.table, GBRT.fit)
}


for(i in seq_len(nrow(timeline.m))){
    print(i)

    train_begin <- timeline.m[i, ]$train_begin
    train_end <- timeline.m[i, ]$train_end
    val_begin <- timeline.m[i, ]$val_begin
    val_end <- timeline.m[i, ]$val_end
    test_begin <- timeline.m[i, ]$test_begin
    test_end <- timeline.m[i, ]$test_end

    X.train <- data.matrix(full.predictor[order(yyyymm, permno) & yyyymm >= train_begin & yyyymm <= train_end, !c("yyyymm", "permno"), with = FALSE])
    Y.train <- RETs[order(yyyymm, permno) & yyyymm >= train_begin & yyyymm <= train_end, !c("yyyymm", "permno"), with = FALSE]$RET

    # elastic net
    elastic.fit <- glmnet(X.train, Y.train, alpha = 0.5, lambda.max = 0.1, lambda.min.ratio = 0.001, standardize=FALSE, nlambda = 30)
    rm(X.train, Y.train)

    X.val <- data.matrix(full.predictor[order(yyyymm, permno) & yyyymm >= val_begin & yyyymm <= val_end, !c("yyyymm", "permno"), with = FALSE])
    elastic.val.pred <- predict(elastic.fit, newx = X.val, type = "response", s = elastic.fit$lambda)
    rm(X.val)
    Y.val <- RETs[order(yyyymm, permno) & yyyymm >= val_begin & yyyymm <= val_end, !c("yyyymm", "permno"), with = FALSE]$RET
    elastic.oos.R2 <- apply(elastic.val.pred, 2, function(x) oos_R2(Y.val, x))
    rm(elastic.val.pred, Y.val)
    lambda.opt <- elastic.fit$lambda[which.max(elastic.oos.R2)]

    X.test <- data.matrix(full.predictor[order(yyyymm, permno) & yyyymm >= test_begin & yyyymm <= test_end, !c("yyyymm", "permno"), with = FALSE])
    # Y.test <- RETs[order(yyyymm, permno) & yyyymm >= test_begin & yyyymm <= test_end, !c("yyyymm", "permno"), with = FALSE]$RET

    test.table <- RETs[order(yyyymm, permno) & yyyymm >= test_begin & yyyymm <= test_end]
    test.table[ , elastic := predict(elastic.fit, newx = X.test, type = "response", s = lambda.opt)]
    rm(X.test)

    save(timeline.m, i, test.table, elastic.fit, lambda.opt, file=paste0("elastic_output/", i, ".RData"))
    rm(test.table, elastic.fit)
}
