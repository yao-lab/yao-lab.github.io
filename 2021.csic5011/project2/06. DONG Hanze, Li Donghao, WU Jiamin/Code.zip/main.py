# %%
import matplotlib.pyplot as plt
import numpy as np

def _visual_(X, label, method=None, t=1):
    x_min, x_max = np.min(X, 0), np.max(X, 0)
    X = (X - x_min) / (x_max - x_min)
    y=label
    #plt.figure()
    plt.figure(figsize=(8, 9), dpi=80)
    ax = plt.subplot(111)
    for i in range(X.shape[0]):
        plt.scatter(X[i, 0], X[i, 1],
                 color=plt.cm.Set1(y[i] / 10.))
    plt.xticks([]), plt.yticks([])
    
    if method is not None:
        plt.title(method)
        plt.title("%s (%.2g sec)" % (method, t))
        plt.savefig('%s.png' % (method))
    plt.show()

# %%
from sklearn.model_selection import cross_val_score
from sklearn import svm
def cv_score(X,y):
    clf = svm.SVC(kernel='linear', C=1, random_state=42)
    scores = np.array(cross_val_score(clf, X, y, cv=5)).mean()
    print("linear",scores)
    clf = svm.SVC(kernel='rbf', C=1, random_state=42)
    scores = np.array(cross_val_score(clf, X, y, cv=5)).mean()
    print("rbf",scores)
# %%
# load data
import torch
import torchvision 
from torchvision import datasets, transforms
test_loader = torch.utils.data.DataLoader(
    datasets.FashionMNIST('./fashionmnist_data/', train=False, download=True,transform=transforms.Compose([
        transforms.Resize(32),
        transforms.ToTensor(),
        transforms.Normalize((0.0,), (1.0,))
    ])),
    batch_size=4000, shuffle=False)
images=[]
labels=[]


for i,l in test_loader:
    images.append(i)
    labels.append(l)
    break
images=torch.cat(images)
labels=torch.cat(labels)
images.shape

from time import time
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import offsetbox
from sklearn import (manifold, datasets, decomposition, ensemble,
                     discriminant_analysis, random_projection, neighbors)
# print(__doc__)

# digits = datasets.load_digits(n_class=6)
X = images.reshape(images.shape[0],-1)
y = labels.numpy()
n_samples, n_features = X.shape
n_neighbors = 30
Add_noise=True
if Add_noise:
    X+=torch.randn_like(X)*0.0
# %%
torchvision.utils.save_image(torchvision.utils.make_grid(X[0:100].reshape(100,1,32,32),normalize=True ,nrow=10) ,fp="noise_data.png" )
X=X.numpy()


# %%
# ((X[0:20]).reshape(20,32,32)).shape
# %%


def plot_embedding(X, title=None):
    
    x_min, x_max = np.min(X, 0), np.max(X, 0)
    X = (X - x_min) / (x_max - x_min)
    labels=['T-shirt/top' , 'Trouser', 'Pullover','Dress','Coat' ,'Sandal','Shirt', 'Sneaker', 'Bag' ,'Ankle boot' ]
    plt.figure(figsize=(9,9))
    ax = plt.subplot(111)
    for i in range(10):
        index_set=y[0:X.shape[0]]==i
        plt.scatter(X[index_set, 0], X[index_set, 1],alpha=0.65,label=labels[i],s=10)#,color=plt.cm.Set1(i)
    plt.xticks([]), plt.yticks([])
    if title is not None:
        plt.title(title)
    # if "SNE" in title:
    plt.legend( loc='upper right') 
    # plt.legend("")
    plt.savefig("figures/{}.pdf".format(title),bbox_inches='tight',pad_inches=0.0)
    plt.show()
    print(title)
    cv_score(X,y[0:X.shape[0]])


# %%
# ----------------------------------------------------------------------
# Random 2D projection using a random unitary matrix
print("Computing random projection")
rp = random_projection.SparseRandomProjection(n_components=2, random_state=42)
t0 = time()
X_projected = rp.fit_transform(X)
plot_embedding(X_projected, "Random Projection (time %.2fs)" %
               (time() - t0))

# %%
# ----------------------------------------------------------------------
# Projection on to the first 2 principal components

print("Computing PCA projection")
t0 = time()
X_pca = decomposition.TruncatedSVD(n_components=2).fit_transform(X)
plot_embedding(X_pca,
               "PCA (time %.2fs)" %
               (time() - t0))
# %%

# ----------------------------------------------------------------------
# Projection on to the first 2 linear discriminant components

print("Computing Linear Discriminant Analysis projection")
X2 = X.copy()
X2.flat[::X.shape[1] + 1] += 0.01  # Make X invertible
t0 = time()
X_lda = discriminant_analysis.LinearDiscriminantAnalysis(n_components=2
                                                         ).fit_transform(X2, y)
plot_embedding(X_lda,
               "LDA (time %.2fs)" %
               (time() - t0))

# %%
# ----------------------------------------------------------------------
# Isomap projection of the digits dataset
# print("Computing Isomap projection")
# t0 = time()
# X_iso = manifold.Isomap(n_neighbors=n_neighbors, n_components=2
#                         ).fit_transform(X)
# print("Done.")
# plot_embedding(X_iso,
#                "Isomap projection of the digits (time %.2fs)" %
#                (time() - t0))
for n_neighbors in [5,10,30,100]:
    t0 = time()
    X_iso = manifold.Isomap(n_neighbors=n_neighbors, n_components=2).fit_transform(X)
    # print("Done. Reconstruction error: %g" % clf.reconstruction_error_)
    plot_embedding(X_iso,
                "ISOMAP with k={} (time {:.2f}s)" .format( n_neighbors,time() - t0) )
# %%
# ----------------------------------------------------------------------
# Locally linear embedding of the digits dataset
# print("Computing LLE embedding")
# clf = manifold.LocallyLinearEmbedding(n_neighbors=n_neighbors, n_components=2,
#                                       method='standard')
# t0 = time()
# X_lle = clf.fit_transform(X)
# print("Done. Reconstruction error: %g" % clf.reconstruction_error_)
# plot_embedding(X_lle,
#                "Locally Linear Embedding of the digits (time %.2fs)" %
#                (time() - t0))
print("Computing LLE embedding")
for n_neighbors in [5,10,30,100]:
    clf = manifold.LocallyLinearEmbedding(n_neighbors=n_neighbors, n_components=2,
                                        method='standard')
    t0 = time()
    X_mlle = clf.fit_transform(X)
    print("Done. Reconstruction error: %g" % clf.reconstruction_error_)
    plot_embedding(X_mlle,
                "LLE with k={} (time {:.2f}s)" .format( n_neighbors,time() - t0) )
# %%
# ----------------------------------------------------------------------
# Modified Locally linear embedding of the digits dataset
print("Computing modified LLE embedding")
for n_neighbors in [5,10,30,100]:
    clf = manifold.LocallyLinearEmbedding(n_neighbors=n_neighbors, n_components=2,
                                        method='modified')
    t0 = time()
    X_mlle = clf.fit_transform(X)
    print("Done. Reconstruction error: %g" % clf.reconstruction_error_)
    plot_embedding(X_mlle,
                "MLLE with k={} (time {:.2f}s)" .format( n_neighbors,time() - t0) )

# %%
# ----------------------------------------------------------------------
# HLLE embedding of the digits dataset
# print("Computing Hessian LLE embedding")
# clf = manifold.LocallyLinearEmbedding(n_neighbors=100, n_components=2,
#                                       method='hessian')
# t0 = time()
# X_hlle = clf.fit_transform(X)
# print("Done. Reconstruction error: %g" % clf.reconstruction_error_)
# plot_embedding(X_hlle,
#                "Hessian Locally Linear Embedding of the digits (time %.2fs)" %
#                (time() - t0))

# %%
# ----------------------------------------------------------------------
# LTSA embedding of the digits dataset
# print("Computing LTSA embedding")
# clf = manifold.LocallyLinearEmbedding(n_neighbors=100, n_components=2,
#                                       method='ltsa')
# t0 = time()
# X_ltsa = clf.fit_transform(X)
# print("Done. Reconstruction error: %g" % clf.reconstruction_error_)
# plot_embedding(X_ltsa,
#                "Local Tangent Space Alignment of the digits (time %.2fs)" %
#                (time() - t0))
# %%
# ----------------------------------------------------------------------
# MDS  embedding of the digits dataset
print("Computing MDS embedding")
clf = manifold.MDS(n_components=2, n_init=1, max_iter=100)
t0 = time()
X_mds = clf.fit_transform(X)
print("Done. Stress: %f" % clf.stress_)
plot_embedding(X_mds,
               "MDS embedding of the digits (time %.2fs)" %
               (time() - t0))
# %%
# ----------------------------------------------------------------------
# Random Trees embedding of the digits dataset
# print("Computing Totally Random Trees embedding")
# hasher = ensemble.RandomTreesEmbedding(n_estimators=200, random_state=0,
#                                        max_depth=5)
# t0 = time()
# X_transformed = hasher.fit_transform(X)
# pca = decomposition.TruncatedSVD(n_components=2)
# X_reduced = pca.fit_transform(X_transformed)

# plot_embedding(X_reduced,
#                "Random forest embedding of the digits (time %.2fs)" %
#                (time() - t0))
# %%
# ----------------------------------------------------------------------
# Spectral embedding of the digits dataset
# print("Computing Spectral embedding")
# embedder = manifold.SpectralEmbedding(n_components=2, random_state=0,
#                                       eigen_solver="arpack")
# t0 = time()
# X_se = embedder.fit_transform(X)

# plot_embedding(X_se,
#                "Spectral embedding of the digits (time %.2fs)" %
#                (time() - t0))
# %%
# ----------------------------------------------------------------------
# t-SNE embedding of the digits dataset
print("Computing t-SNE embedding")
tsne = manifold.TSNE(n_components=2, perplexity=10.0, init='pca', random_state=0)
t0 = time()
X_tsne = tsne.fit_transform(X)

plot_embedding(X_tsne,
               "t-SNE (time %.2fs)" %
               (time() - t0))
# %%
# ----------------------------------------------------------------------
# # NCA projection of the digits dataset
# print("Computing NCA projection")
# nca = neighbors.NeighborhoodComponentsAnalysis(init='random',
#                                                n_components=2, random_state=0)
# t0 = time()
# X_nca = nca.fit_transform(X, y)

# plot_embedding(X_nca,
#                "NCA embedding of the digits (time %.2fs)" %
#                (time() - t0))

# plt.show()
# %%

# %%
# state_dict=torch.load("fmnist_2.hidden")
# X = state_dict[0].numpy()
# y = state_dict[1].numpy()
# plot_embedding(X,
#                "VAE")
# %%
import umap
print("Computing t-SNE embedding")
# tsne = manifold.TSNE(n_components=2, perplexity=10.0, init='pca', random_state=0)
t0 = time()
umap_X = umap.UMAP(n_neighbors=5, min_dist=0.1).fit_transform(X)

plot_embedding(umap_X,
               "UMAP (time %.2fs)" %
               (time() - t0))

# %%


import umap
print("Computing t-SNE embedding")
# tsne = manifold.TSNE(n_components=2, perplexity=10.0, init='pca', random_state=0)
t0 = time()
densmap_X = umap.UMAP(densmap=True, random_state=42,n_neighbors=5, min_dist=0.1).fit_transform(X)

plot_embedding(densmap_X,
               "DENSEMAP (time %.2fs)" %
               (time() - t0))
# %%

# %%

# %%
