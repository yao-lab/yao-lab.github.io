%% MP
if strcmp(invOP,'MP')
    N = linspace(0,1,10);
    RegPar = N;
    chi2D = zeros(M^2, length(RegPar));
    chi2D0 = zeros(M^2, length(RegPar));
    figure()
    hfig = figure;
    pos = get(hfig,'position');
    set(hfig,'position',pos.*[.5 1 2 1]);
    
    CovM = A'*A;    
    c = length(A(1,:))/length(A(:,1));
    lambda_lower = (1 - sqrt(c))^2;
    lambda_upper = (1 + sqrt(c))^2;
    
    d = diag(diag(CovM));
    sample_corr = (d^(-1/2)) * CovM * (d^(-1/2));
    
    [V1, E] = eig(sample_corr); % C = V*E*V'
    E = diag(E);
    eigenvalues = E;
    inside_bounds = eigenvalues( eigenvalues >= lambda_lower & eigenvalues <= lambda_upper);
    clipped_value = mean(inside_bounds);
    clipped_evs = eigenvalues;
    for j = 1:length(eigenvalues)
        if eigenvalues(j) <= lambda_upper
            clipped_evs(j) = clipped_value;
        end
    end
    sample_corr_clipped = V1 * diag(clipped_evs) * V1';
    
    % Corresponding covariance matrix
    CovM_clipped = (d^(1/2)) * sample_corr_clipped * (d^(1/2));
    
    for ii=1:length(RegPar)
        chi= (CovM_clipped)\A'*data; % Ridge
        chi2D0(:,ii) = chi;
        chi = (chi-mean(chi(:)))./std(chi(:));
        chi2D(:,ii) = chi;
        %% plot
        subplot(4,round(length(RegPar)/4),ii) ;
        epr = 1+real(reshape(chi2D0(:,ii), M,M));
        clims = [0.5 1.5];
        imagesc(tx,ty,(epr));
        colormap hot
        view([0 -90])
        axis equal
        str = compose("%d",ii);
        s = strcat('\lambda_{',str, '}');
        % %     titles = {''}; str
        title(s, 'fontsize',10)
    end
end







%       [V1, E] = eig(CovM);
    d = diag(diag(CovM));
    sample_corr = (d^(-1/2)) * CovM * (d^(-1/2));
    
    [V1, E] = eig(sample_corr); % C = V*E*V'
    E = diag(E);
    eigenvalues = E;
    inside_bounds = eigenvalues( eigenvalues >= lambda_lower & eigenvalues <= lambda_upper);
    clipped_value = mean(inside_bounds);
    clipped_evs = eigenvalues;
    for j = 1:length(eigenvalues)
        if eigenvalues(j) <= lambda_upper
            clipped_evs(j) = clipped_value;
        end
    end
    sample_corr_clipped = V1 * diag(clipped_evs) * V1';
    
    % Corresponding covariance matrix
    CovM_clipped = (d^(1/2)) * sample_corr_clipped * (d^(1/2));


