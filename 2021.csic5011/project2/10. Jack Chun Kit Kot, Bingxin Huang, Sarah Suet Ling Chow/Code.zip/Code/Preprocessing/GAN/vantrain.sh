python training_gan.py --batch_size 2 --checkpoint_dir DCGAN/checkpoint --sample_dir DCGAN/sample  --noise_size 100 --use_tensorboard false --log_dir DCGAN/logs\
                      --num_epochs 50