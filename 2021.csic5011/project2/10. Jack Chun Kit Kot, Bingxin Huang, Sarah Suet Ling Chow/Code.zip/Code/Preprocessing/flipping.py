import cv2
import os


path1 = 'dataset(Flipped)/train/triglomerulus/'
path2 = 'dataset(Flipped)/train/flippedtriglomerulus/'
k = 1
ori2 = 1

folder_unmatch = os.listdir(path1)

if not os.path.exists(path2):
    os.makedirs(path2)

counting = 0
for file in folder_unmatch:
    filename = os.fsdecode(file)
    print(filename)
    img = cv2.imread(path1 + filename)
    count = 0
    cv2.imwrite(path2 + str(counting)+ '_original.jpg', img)
    flipHorizontal = cv2.flip(img, 1)
    cv2.imwrite(path2 + str(counting)+ '_flipped'  + '.jpg',flipHorizontal)
    count = 0
    counting = counting + 1