from torch.utils.data import Dataset, dataset
from torch.utils.data.sampler import SequentialSampler
from torchvision import transforms as transforms
from PIL import Image
import torch
import os
import random
import glob
from torch.utils import data

from torchvision.datasets.folder import ImageFolder

def get_loader(root, image_size = 256, batch_size = 2,
                mode = 'train', num_worksers =1):
    transform = []
    transform.append(transforms.Resize(int(image_size*1.12), Image.BICUBIC))
    transform.append(transforms.RandomCrop(image_size)) 
    transform.append(transforms.RandomHorizontalFlip())
    transform.append(transforms.ToTensor())
    transform.append(transforms.Normalize(mean=(0.5,0.5,0.5), std=(0.5,0.5,0.5)))
    transform = transforms.Compose(transform)

    dataset = ImageFolder(root, transform)
    if mode == 'train':
        data_loader = data.DataLoader(dataset = dataset, batch_size = batch_size, shuffle = True, num_workers=num_worksers,drop_last=True)
    if mode == 'test':
        data_loader = data.DataLoader(dataset = dataset, batch_size = batch_size, shuffle = False, num_workers=num_worksers,drop_last=False)

    return data_loader