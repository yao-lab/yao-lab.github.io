# -*- coding: utf-8 -*-
"""
created on Sat May 15 21:10:11 2021

@author: BX
"""

from time import time
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter
from sklearn import manifold
from scipy.io import loadmat    # to load matlab data
import seaborn as sns
import pandas as pd

#Data proposessing
X = loadmat("/Users/bhuangao/Desktop/cs/gloPCAnew.mat")   #Load data
Y = X['gloPCA']
print(Y.shape)
Y = np.reshape(Y,(65536, 821))
Y = Y.T
Y = np.float64(Y) 

n_points = 821
n_neighbors = 10
n_components = 2
fig = plt.figure(figsize=(15, 8))
plt.suptitle("Manifold Learning with %i points, %i neighbors"
             % (821, n_neighbors), fontsize=14)

label1 = np.repeat(1,209)
label4 = np.repeat(2,209)
label3 = np.repeat(3,211)
label2 = np.repeat(4,191)
l1 = np.expand_dims(label1, axis=1)
l2 = np.expand_dims(label2, axis=1)
l3 = np.expand_dims(label3, axis=1)
l4 = np.expand_dims(label4, axis=1)

label = np.row_stack((l1,l2,l3,l4))


###############################################################################
#MDS
t0 = time()
mds = manifold.MDS(n_components, max_iter=2000, n_init=1)
Y2 = mds.fit_transform(Y)
t1 = time()
print("MDS: %.2g sec" % (t1 - t0))
ax = fig.add_subplot(142)
plt.scatter(Y2[:, 0], Y2[:, 1], cmap=plt.cm.Spectral)
plt.title("MDS (%.2g sec)" % (t1 - t0))
ax.xaxis.set_major_formatter(NullFormatter())
ax.yaxis.set_major_formatter(NullFormatter())
plt.axis('tight')

# plot beautiful maps
Y1D = np.column_stack((Y2,label))
Y1D = pd.DataFrame({'first':Y1D[:, 0],'second':Y1D[:, 1],'Category':Y1D[:, 2]})
g =sns.scatterplot(x="first", y="second",
              hue="Category",
              palette=['red','orange','green','blue'], legend=['full'],
              data=Y1D)

###############################################################################
#Isomap
t0 = time()
Y3 = manifold.Isomap(n_neighbors, n_components).fit_transform(Y)
t1 = time()
print("Isomap: %.2g sec" % (t1 - t0))
ax = fig.add_subplot(143)
plt.scatter(Y3[:, 0], Y3[:, 1], cmap=plt.cm.Spectral)
plt.title("Isomap (%.2g sec)" % (t1 - t0))
ax.xaxis.set_major_formatter(NullFormatter())
ax.yaxis.set_major_formatter(NullFormatter())
plt.axis('tight')

# plot beautiful maps
Y3D = np.column_stack((Y3,label))
Y3D = pd.DataFrame({'first':Y3D[:, 0],'second':Y3D[:, 1],'Category':Y3D[:, 2]})
g =sns.scatterplot(x="first", y="second",
              hue="Category",
              palette=['red','orange','green','blue'], legend=['full'],
              data=Y3D)


###############################################################################
# LLE
t0 = time()
Y4 = manifold.LocallyLinearEmbedding(n_neighbors, n_components,
                                    eigen_solver='auto',
                                    method='standard').fit_transform(Y)
t1 = time()
print("%s: %.2g sec" % ('standard', t1 - t0))
ax = fig.add_subplot(144)
plt.scatter(Y4[:, 0], Y4[:, 1], cmap=plt.cm.Spectral)
plt.title("%s (%.2g sec)" % ('LLE', t1 - t0))
ax.xaxis.set_major_formatter(NullFormatter())
ax.yaxis.set_major_formatter(NullFormatter())
plt.axis('tight')

# plot beautiful maps
Y4D = np.column_stack((Y4,label))
Y4D = pd.DataFrame({'first':Y4D[:, 0],'second':Y4D[:, 1],'Category':Y4D[:, 2]})
g =sns.scatterplot(x="first", y="second",
              hue="Category",
              palette=['red','orange','green','blue'], legend=['full'],
              data=Y4D)


"""
code reference: 'Order the faces by Diffusion Map, ISOMAP and LLE, Kang Lei, 2019'

"""