import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torch.autograd import Variable
import torchvision
from PIL import Image
import torch
import torch.nn as nn
import torch.optim as optim
from model import AlexNet,  LeNet
from dataloader import get_loader
import matplotlib.pyplot as plt
from torchvision import datasets
import numpy as np

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
net = AlexNet()
#net = LeNet()
net.to(device)
dataname = ["Original",'Flipped','GAN','PCA','PCA + GAN']
criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(net.parameters(), lr=0.0001, momentum=0.9)
datasetpath = ["dataset(Original)/train","dataset(Flipped)/train", "dataset(withGAN)/train","dataset(PCA)/train","dataset(PCAGAN)/train"]
testdatasetpath = ["dataset(Original)/test","dataset(Flipped)/test", "dataset(withGAN)/test","dataset(PCA)/test","dataset(PCAGAN)/test"]
curvyx = [2,4,6,8,10]
accuracy = []

for k in range(len(datasetpath)):
    traina_loader = get_loader(datasetpath[k], image_size = 256, batch_size = 1)
    test_loader = get_loader(testdatasetpath[k], image_size = 256, batch_size = 1)
    net = AlexNet()
    net.to(device)
    optimizer = optim.SGD(net.parameters(), lr=0.0001, momentum=0.9)
    for epoch in range(10):  # loop over the dataset multiple times
        #print(epoch)

        running_loss = 0.0
        for i, data in enumerate(traina_loader, 0):
            # get the inputs; data is a list of [inputs, labels]
            inputs, labels = data[0].to(device), data[1].to(device)

            # zero the parameter gradients
            optimizer.zero_grad()

            # forward + backward + optimize
            outputs = net(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            # print statistics
            running_loss += loss.item()
            if i % 100 == 0:    # print every 100 mini-batches
                #print('[%d, %5d] loss: %.3f' %
                    #(epoch + 1, i + 1, running_loss / 100))
                running_loss = 0.0

        curvyy = []
        if (epoch+1)%2 == 0:    

            #print('Finished Training')
            PATH = 'checkpoint/model.pth'
            dataiter = iter(test_loader)
            #images, labels = dataiter.next()
            #print('GroundTruth: ', labels)
            torch.save(net.state_dict(), PATH)
            net2 = AlexNet()
            #net = LeNet()
            net2.load_state_dict(torch.load(PATH))

            correctcounter = 0
            wrongcounter = 0
            number = 1
            for i in range(80):
                inputs2, labels2 = dataiter.next()
                outputs = net2(inputs2)
                #print(outputs)
                _, predicted = torch.max(outputs, 1)
                if predicted == labels2:
                    correctcounter = correctcounter + 1
                    #print('GroundTruth: ', labels, 'Predicted: ', predicted, 'accuracy: ',correctcounter, 'number: ', number, 'True:' , labels)
                else:
                    wrongcounter = wrongcounter + 1
                    #print('GroundTruth: ', labels, 'Predicted: ', predicted, 'accuracy: ',correctcounter, 'number: ', number, 'False' , labels)
                number = number + 1
            accuracyx = correctcounter/80
            print(dataname[k], str(epoch+1), str(correctcounter/80))
            accuracy.append(accuracyx)

f1 = plt.figure() 
ax1 = f1.add_subplot()
x1 = []
y1 = []
count = 0
count2 = 0
for i in range(len(accuracy)):
    if i == 0 or i % 5 != 0:
        x1.append(curvyx[count])
        y1.append(accuracy[i])
        count = count + 1
    if i != 0 and i % 5 == 0:
        x1.append(curvyx[count])
        y1.append(accuracy[i])
        if count2 <= 4:
            ax1.plot(x1,y1,"+-",label = ("{}".format(dataname[count2])))
            plt.xlabel('Epoch')
            plt.ylabel('Accuracy')
            plt.yticks(np.arange(0, 1.1, 0.05))
            plt.ylim([0,1])
            plt.title('The Curve of Accuracy Versus Epochs by Different Datasets')
            plt.legend(bbox_to_anchor=(1.0, 0), loc=4, borderaxespad=0.)
            x1 = []
            y1 = []
            count = 0
            count2 += 1

f1.savefig('Accuracy.png')
print("plot graph acc vs epoch and acc vs neuronum")

