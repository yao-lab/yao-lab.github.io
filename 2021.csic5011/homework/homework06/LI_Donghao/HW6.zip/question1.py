# %%
import numpy as np
import matplotlib.pyplot as plt
import scipy.io as sio
face=sio.loadmat("face.mat")
face["id"]=face["id"].reshape(-1)
# %%
face['Y'].shape
# %%
plt.figure(figsize=(16,16))
for i in range(33):
    print(i,int(face['id'][i]) )
    plt.subplot(5,7,int(face['id'][i]) )
    plt.imshow(face['Y'][:,:,i])

plt.show()

# %%

# %%
