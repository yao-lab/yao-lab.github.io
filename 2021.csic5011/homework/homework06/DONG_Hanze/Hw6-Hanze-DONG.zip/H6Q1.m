clear
load face.mat
addpath dijkstra
X = double(reshape(Y,[112*92,33])');
D = pdist(X);

X2 = mdscale(squareform(D),2);

plot(X2(:,1),X2(:,2),'o');



iso = isomapII(squareform(D), 'k', 2);


X2_lle = lle(X,5,2)';
plot(X2_lle(:,1),X2_lle(:,2),'o');
