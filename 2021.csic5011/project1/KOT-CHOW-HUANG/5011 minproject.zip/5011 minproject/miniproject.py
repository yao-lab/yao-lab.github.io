import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.decomposition import SparsePCA 
from sklearn.manifold import MDS
from sklearn.manifold import Isomap
from sklearn.manifold import LocallyLinearEmbedding
from sklearn.preprocessing import StandardScaler

parameters = [1,2,3,4,5]
def plotting2Dgraph(finalDF,title):
    parameters = [1,2,3,4,5]
    figure = plt.figure()
    ax = figure.add_subplot()
    ax.set_xlabel('Principal Component 1', fontsize = 15)
    ax.set_ylabel('Principal Component 2', fontsize = 15)
    ax.set_title(title,fontsize = 15)
    for parameter in parameters:
        indicesToKeep = finalDF['range'] == parameter
        ax.scatter(finalDF.loc[indicesToKeep, 'principal component 1']
               , finalDF.loc[indicesToKeep, 'principal component 2'])
    ax.legend(parameters)
    ax.grid()
    figure.savefig( title + '.png')

crime = pd.read_csv('crime_jack.csv') #loading the preprocessed data
crime_matrix = crime.iloc[:,7:19].values #obtain all data from the 13 selected parameters
crime_matrix = StandardScaler().fit_transform(crime_matrix)

 #range of total crime number


# visualizing the 2D projection
# PCA
pca = PCA(n_components=2)
principalComponents = pca.fit_transform(crime_matrix)
principalDf = pd.DataFrame(data = principalComponents, columns = ['principal component 1', 'principal component 2'])
finalDf = pd.concat([principalDf, crime['range']], axis = 1)
print(finalDf)
plotting2Dgraph(finalDf,'PCA 2 Components Result')

#spca
spca = SparsePCA(n_components=2,random_state=0)
sprincipalComponents = spca.fit_transform(crime_matrix)
sprincipalDf = pd.DataFrame(data = sprincipalComponents, columns = ['principal component 1', 'principal component 2'])
finalDf = pd.concat([sprincipalDf, crime['range']], axis = 1)
print(finalDf)
plotting2Dgraph(finalDf, 'SparePCA 2 Components Result')

#mds
mds = MDS(n_components=2)
MprincipalComponents = mds.fit_transform(crime_matrix)
MprincipalDf = pd.DataFrame(data = MprincipalComponents, columns = ['principal component 1', 'principal component 2'])
finalDf = pd.concat([MprincipalDf, crime['range']], axis = 1)
print(finalDf)
plotting2Dgraph(finalDf, 'MDS 2 Components Result')

#lle
lle = LocallyLinearEmbedding(n_components=2)
LprincipalComponents = lle.fit_transform(crime_matrix)
LprincipalDf = pd.DataFrame(data = LprincipalComponents, columns = ['principal component 1', 'principal component 2'])
finalDf = pd.concat([LprincipalDf, crime['range']], axis = 1)
print(finalDf)
plotting2Dgraph(finalDf,'LLE 2 Components Result')

#isomap
Isp = Isomap(n_components=2)
iprincipalComponents = Isp.fit_transform(crime_matrix)
iprincipalDf = pd.DataFrame(data = iprincipalComponents, columns = ['principal component 1', 'principal component 2'])
finalDf = pd.concat([iprincipalDf, crime['range']], axis = 1)
print(finalDf)
plotting2Dgraph(finalDf,'ISOMAP 2 Components Result')

#pca 3d
pca = PCA(n_components=3)
principalComponents = pca.fit_transform(crime_matrix)
principalDf = pd.DataFrame(data = principalComponents, columns = ['principal component 1', 'principal component 2','principal component 3'])
finalDf = pd.concat([principalDf, crime['range']], axis = 1)
print(finalDf)
fig = plt.figure()
ax = plt.axes(projection='3d')
ax.set_xlabel('Principal Component 1', fontsize = 10)
ax.set_ylabel('Principal Component 2', fontsize = 10)
ax.set_zlabel('Principal Component 3',fontsize = 10)
ax.set_title('PCA 3 Components Result', fontsize = 20)
parameters=[1,2,3,4,5]
for parameter in parameters:
    indicesToKeep = finalDf['range'] == parameter
    ax.scatter(finalDf.loc[indicesToKeep, 'principal component 1']
               , finalDf.loc[indicesToKeep, 'principal component 2'],
               finalDf.loc[indicesToKeep, 'principal component 3'])
ax.legend(parameters)
ax.grid()
fig.savefig('pca3d.png')

#isomp 3d
Isp = Isomap(n_components=3)
iprincipalComponents = Isp.fit_transform(crime_matrix)
iprincipalDf = pd.DataFrame(data = iprincipalComponents, columns = ['principal component 1', 'principal component 2', 'principal component 3'])
finalDf = pd.concat([iprincipalDf, crime['range']], axis = 1)
print(finalDf)
fig6 = plt.figure()
ax = plt.axes(projection='3d')
ax.set_xlabel('Principal Component 1', fontsize = 10)
ax.set_ylabel('Principal Component 2', fontsize = 10)
ax.set_zlabel('Principal Component 3',fontsize = 10)
ax.set_title('ISOMP 3 Components Result', fontsize = 20)
parameters=[1,2,3,4,5]
for parameter in parameters:
    indicesToKeep = finalDf['range'] == parameter
    ax.scatter(finalDf.loc[indicesToKeep, 'principal component 1']
               , finalDf.loc[indicesToKeep, 'principal component 2'],
               finalDf.loc[indicesToKeep, 'principal component 3'])
ax.legend(parameters)
ax.grid()
fig6.savefig('isomap3d.png')

#lle 3d
lle = LocallyLinearEmbedding(n_components=3)
LprincipalComponents = lle.fit_transform(crime_matrix)
LprincipalDf = pd.DataFrame(data = LprincipalComponents, columns = ['principal component 1', 'principal component 2','principal component 3'])
finalDf = pd.concat([LprincipalDf, crime['range']], axis = 1)
print(finalDf)
fig5 = plt.figure()
ax = plt.axes(projection='3d')
ax.set_xlabel('Principal Component 1', fontsize = 10)
ax.set_ylabel('Principal Component 2', fontsize = 10)
ax.set_zlabel('Principal Component 3',fontsize = 10)
ax.set_title('LLE 3 Components Result', fontsize = 20)
parameters=[1,2,3,4,5]
for parameter in parameters:
    indicesToKeep = finalDf['range'] == parameter
    ax.scatter(finalDf.loc[indicesToKeep, 'principal component 1']
               , finalDf.loc[indicesToKeep, 'principal component 2'],
               finalDf.loc[indicesToKeep, 'principal component 3'])
ax.legend(parameters)
fig5.savefig('LLE3d.png')

#spca 3d
spca = SparsePCA(n_components=3)
principalComponents = spca.fit_transform(crime_matrix)
principalDf = pd.DataFrame(data = principalComponents, columns = ['principal component 1', 'principal component 2','principal component 3'])
finalDf = pd.concat([principalDf, crime['range']], axis = 1)
print(finalDf)
fig = plt.figure()
ax = plt.axes(projection='3d')
ax.set_xlabel('Principal Component 1', fontsize = 10)
ax.set_ylabel('Principal Component 2', fontsize = 10)
ax.set_zlabel('Principal Component 3',fontsize = 10)
ax.set_title('SparePCA 3 Components Result', fontsize = 20)
parameters=[1,2,3,4,5]
for parameter in parameters:
    indicesToKeep = finalDf['range'] == parameter
    ax.scatter(finalDf.loc[indicesToKeep, 'principal component 1']
               , finalDf.loc[indicesToKeep, 'principal component 2'],
               finalDf.loc[indicesToKeep, 'principal component 3'])
ax.legend(parameters)
ax.grid()
fig.savefig('spca3d.png')

#mds 3d
mpca = MDS(n_components=3)
principalComponents = mpca.fit_transform(crime_matrix)
principalDf = pd.DataFrame(data = principalComponents, columns = ['principal component 1', 'principal component 2','principal component 3'])
finalDf = pd.concat([principalDf, crime['range']], axis = 1)
print(finalDf)
fig = plt.figure()
ax = plt.axes(projection='3d')
ax.set_xlabel('Principal Component 1', fontsize = 10)
ax.set_ylabel('Principal Component 2', fontsize = 10)
ax.set_zlabel('Principal Component 3',fontsize = 10)
ax.set_title('MDS 3 Components Result', fontsize = 20)
parameters=[1,2,3,4,5]
for parameter in parameters:
    indicesToKeep = finalDf['range'] == parameter
    ax.scatter(finalDf.loc[indicesToKeep, 'principal component 1']
               , finalDf.loc[indicesToKeep, 'principal component 2'],
               finalDf.loc[indicesToKeep, 'principal component 3'])
ax.legend(parameters)
ax.grid()
fig.savefig('mds3d.png')