
Data File "Measurement_Vector.mat" is measurement vector y in equation (4), (5) and (12) in project report.

Data File "Model_Matrix_A.mat" is Model Matrix A in equation (4), (5) and (12) in project report.

Data File "Data_Matrix_X.mat" is Data Matrix X in equation (6). It is used to generate Figure 3 in project report.

The python code "subspacecode.py" is for processing  "Data_Matrix_X.mat".

ForwMoM.m and InverseMoM.m are physics based forward and inverse simulations for electromagnetic scattering. 
Please email to adubey@connect.ust.hk if interested in more detailed theory of physics based simulations (Method of Moments) used for generating the underlying model. 