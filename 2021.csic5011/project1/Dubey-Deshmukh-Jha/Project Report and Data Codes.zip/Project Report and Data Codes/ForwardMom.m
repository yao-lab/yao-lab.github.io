%% Description
%{
Description: Simulates Forward 2D MoM case without conjugate gradient approach. 
Also includes directivity and transmit power. Program is benchmarked with SOM 
code of Prof Xudong where Inc, total and scat fields are all exactly matched 
as both codes uses Hankel func of first kind. Code is also benchmarked with
Eigenexpansion code where only magnitude and real part of Inc, total and
scat fields exactly matches. The imaginary parts are conjugate of each
other.
- Tx and Rx at same location and singular field is made zero
%}
%%
clear;
close all;
tic
freq = 2.4e9; % change
lambda = 3e8/freq;              % the wavelength in the air
k0 = 2*pi/lambda;               % the wave number in the air
imp = 120*pi;
Pt = 19.5; % dBm
geom = 'square';
NodeMode=1; NaNremove=1;
nl = 0; % noise level || eg: when noise level is 10%, nl = 0.1.
%% Method of Moment
%% Parameters (keep unchanged for both forward problem and inverse problem)
size_DOI = 0.5; % change          % size of DOI
epsono_r_c =1.1;                 % the constant relative permittivity of the object
Ns = 20;                        % number of receiving antennas
Ni = Ns;                        % number of TX
M = 100;      % change          % the square containing the object has a dimension of MxM
Ant_dir =0;
Ct=1; Cr=1;
NumRes = M*lambda/(sqrt(epsono_r_c)*size_DOI);
ant = 3;
% xm=linspace(0,3,Ns/4+1); % Node x positions
% ym=linspace(0,3,Ns/4+1); % Node y positions
xm=linspace(-1.5,1.5,Ns/4+1); % Node x positions
ym=linspace(-1.5,1.5,Ns/4+1); % Node y positions
%% Node Geometry
if strcmp(geom,'square')
XYRx = [[xm(1,:)', repmat(ym(1),[1,length(xm)])'];...
    [repmat(xm(1,end), [1,length(ym)-1])', ym(1,2:end)']; ...
    [flip(xm(1,1:end-1))', repmat(ym(1,end),[1,length(xm)-1])'];...
    [repmat(xm(1,1), [1,length(ym)-2])', flip(ym(1,2:end-1))']];
XYTx = [[xm(1,:)', repmat(ym(1),[1,length(xm)])'];...
    [repmat(xm(1,end), [1,length(ym)-1])', ym(1,2:end)']; ...
    [flip(xm(1,1:end-1))', repmat(ym(1,end),[1,length(xm)-1])'];...
    [repmat(xm(1,1), [1,length(ym)-2])', flip(ym(1,2:end-1))']];
X=XYRx(:,1)';Y=XYRx(:,2)';% Location of Rxs
X_tx=XYTx(:,1)';Y_tx=XYTx(:,2)';% Location of Txs
end
Rx_pos = [X(:), Y(:)];
Tx_pos = [X_tx(:), Y_tx(:)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Assign reference theta to all links 
TxRx_ref_theta = Tx_pos;
TxRx_ref_theta(:,3) = zeros(length(Tx_pos(:,1)),1);
for ii = 1:length(Tx_pos(:,1))
    node_ii = Tx_pos(ii,:);
    if node_ii(1,1)==min(xm) || node_ii(1,1)==max(xm) %verticle edges of DOI
        TxRx_ref_theta(ii,3) = 0;
    end
    if node_ii(1,2)==min(ym) || node_ii(1,2)==max(ym)
        TxRx_ref_theta(ii,3) = 90;
    end
    if (node_ii(1,1)==node_ii(1,2)) || (node_ii(1,1)==min(xm)&& node_ii(1,2)==min(ym)) || (node_ii(1,1)==min(xm)&& node_ii(1,2)==max(ym))|| (node_ii(1,1)==max(xm)&& node_ii(1,2)==min(ym))
            % || (node_ii(1,1)+node_ii(1,2))==max(ym)) 
        TxRx_ref_theta(ii,3) = 45;
    end
end
%% Positions of the cells
d = (size_DOI)/M;   % change     %the nearest distance of two cell centers
tx = d/2:d:size_DOI-d/2;
ty = size_DOI-d/2:-d:d/2;
[x,y] = meshgrid(tx,ty);  % change                % M x M
cellrad = (sqrt(d^2/pi)*2)/2; % change                     % diameter of cells
%% Relative permittivity of each cell
% hsideX = 0.0875; hsideY = 0.1075;
hsideX = 0.1; hsideY = 0.15;
% centerX = 0.3; centerY = 0.3;
centerX = 0.25; centerY = 0.25;
epsono_r = ones(M,M);%ones(M,M);  % change
% load('3_1.mat','scatterer');
% scatterer(scatterer>1)=epsono_r_c;
% epsono_r = scatterer;
% epsono_r((x-centerX).^2+(y-centerX).^2<=(hsideY)^2) = epsono_r_c;
epsono_r((x-centerX).^2+(y-centerX).^2<=(hsideY)^2 & ...
    (x-centerX).^2+(y-centerX).^2>=(hsideY/1.5)^2) = epsono_r_c;
% epsono_r(((x-(+hsideX))<=centerX & (x-(-hsideX))>=centerX & ...
%     (y-(+hsideY))<=centerY & (y-(-hsideY))>=centerY)) = epsono_r_c;
%%
objInd = find((epsono_r-1)); NoobjInd = find((epsono_r-1)==0);
if (length(objInd)+length(NoobjInd))~= length(epsono_r(:))
   error('Cannot calculate with given values')
end
Z=zeros(length(objInd),length(objInd));  %[r, c]=ind2sub([m1,n1],objInd);
xObj = x(objInd); yObj = y(objInd);
for inc = 1:length(objInd) % first incident point in object
    xinc = x(objInd(inc)); yinc = y(objInd(inc)); %[r1,c1] = ind2sub([m1,n1],objInd(inc));    
    R=sqrt((xinc-xObj).^2 + (yinc-yObj).^2); %rhodd means distance from a unit dipole to another
    Z1 = -imp*pi*cellrad/2*besselj(1,k0*cellrad)*besselh(0,1,k0*R);
    Z1(inc) = -imp*pi*cellrad/2*besselh(1,1,k0*cellrad)-1i*imp*epsono_r(objInd(inc))/(k0*(epsono_r(objInd(inc))-1));
    Z(inc,:) = Z1.'; %Z1'
end
clear xinc yinc Z1 R yObj xObj
%% Definition of the Direct Waves (from TX to RX)
[xt_d, xr_d] = meshgrid(X_tx, X);
[yt_d, yr_d] = meshgrid(Y_tx, Y);
dist_tx_rx = sqrt((xt_d-xr_d).^2 + (yt_d-yr_d).^2);
E_d =   (1i/4)*besselh(0,1,k0*dist_tx_rx);  % Ns x Ni
% E_d =   exp(1i*k0*dist_tx_rx)./(4*pi*dist_tx_rx);  % Ns x Ni % Note that nth column is nth Tx and for each Tx, rows are Rx
if Ant_dir==1
    Ref_theta_Tx_Rn = repmat(TxRx_ref_theta(:,3)',Ns,1);    
    Ref_theta_Rx = repmat(TxRx_ref_theta(:,3),1,Ni);

    Theta_Tx_Rx = round(abs(abs(atand((yt_d-yr_d)./(xt_d-xr_d)))-Ref_theta_Tx_Rn));
    Theta_Rx_Tx = round(abs(abs(atand((yt_d-yr_d)./(xt_d-xr_d)))-Ref_theta_Rx));

    Theta_Tx_Rx(isnan(Theta_Tx_Rx))=0;
    Theta_Rx_Tx(isnan(Theta_Rx_Tx))=0;

    load ('Antenna_gain_phi0.mat')
%     Antenna_gain_phi0_lin = Antenna_gain_phi0(:,ant);
%     Antenna_gain_phi0_lin(Antenna_gain_phi0_lin<=0.3088)=0.2088;%min(Antenna_gain_phi0_lin);
% %     Antenna_gain_phi0_lin(Antenna_gain_phi0_lin>=4.611)=10;
%     Antenna_gain_phi0(:,ant)=Antenna_gain_phi0_lin;     
%     
    
    G_Tx_Rx=zeros(size(Theta_Tx_Rx));
    G_Rx_Tx=zeros(size(Theta_Tx_Rx));
    for i = 1:max(Ni,Ns)
        G_Tx_Rx(:,i) = Antenna_gain_phi0(Theta_Tx_Rx(:,i)+1,ant);
        G_Rx_Tx(:,i) = Antenna_gain_phi0(Theta_Rx_Tx(:,i)+1,ant);   
    end 
    E_d = E_d.*sqrt(imp*((1e-3)*10^(Pt/10))*4*k0*Ct);    
%     E_d = E_d.*sqrt(imp*((1e-3)*10^(Pt/10))*2*Ct*k0./dist_tx_rx);
    
    load ('E:\OneDrive - HKUST Connect\PhD Research\Wave Scattering Model\zTemporary_Desktop\Anechoic Chamber - Lappy - Copy - LOS\RTI codes\March 2021\Full Empty\mode_matrix.mat','mode_matrix')%%empty_mode_matrix(:);
    E_d_exp = sqrt(imp*((1e-3)*10.^(mode_matrix/10))*4*pi/(lambda^2));
    Tx_Rx_G_prod_exp = E_d_exp./abs(E_d);
    Tx_Rx_G_prod_sim = sqrt(G_Tx_Rx).*sqrt(G_Rx_Tx);    
    E_d = E_d.*Tx_Rx_G_prod_exp;
    
%     E_d = E_d.*sqrt(G_Tx_Rx).*sqrt(G_Rx_Tx)*Cr;
    
end

clear xt_d xp_d yt_d yp_d dist_tx_rx G_Rx_Tx G_Tx_Rx Theta_Tx_Rx Theta_Rx_Tx
%% Definition of the Incident Waves (from TX to domain of interest)
[xt, xp] = meshgrid(X_tx, x(:));
[yt, yp] = meshgrid(Y_tx, y(:));
dist_tx_pix = sqrt((xt-xp).^2 + (yt-yp).^2);
E_inc =   (1i/4)*besselh(0,1,k0*dist_tx_pix);  % M^2 x Ni for cylindrical wave
% E_inc = exp(1i*k0*dist_tx_pix)./(4*pi*dist_tx_pix);  % M^2 x Ni for cylindrical wave
% % % % % % % % % % % % % % % 
if Ant_dir==1
    Ref_theta_Tx_Rn = repmat(TxRx_ref_theta(:,3)',M^2,1);
    Theta_Tx_Rn = round(abs(abs(atand((yt-yp)./(xt-xp)))-Ref_theta_Tx_Rn));
    G_Tx_Rn=zeros(size(Theta_Tx_Rn));
    for i = 1:M^2
       G_Tx_Rn(i,:) = Antenna_gain_phi0(Theta_Tx_Rn(i,:)+1,ant);
    end       
%     E_inc=E_inc.*sqrt(imp*((1e-3)*10^(Pt/10))*2*Ct*k0./dist_tx_pix);
    E_inc=E_inc.*sqrt(imp*((1e-3)*10^(Pt/10))*4*k0*Ct);    
    E_inc = E_inc.*sqrt(G_Tx_Rn);
end
clear xt yt xp yp dist_tx_pix Theta_Tx_Rn Ref_theta_Tx_Rn G_Tx_Rn
%% Using conjugate-gradient method
E_inc_obj = -E_inc(objInd,:);
Etot_rn=E_inc;
% Z=gpuArray(Z);
% E_inc_obj=gpuArray(E_inc_obj);
J1=Z\(E_inc_obj);
% J1=gather(J1);
timee = toc;
J = zeros(M^2,Ni);
for ii=1:length(objInd)
    J(objInd(ii),:) = J1(ii,:);
    Etot_rn(objInd(ii),:) = 1i*imp*(J1(ii,:)./((epsono_r(objInd(ii))-1)*k0));    
end
% eprr = repmat((epsono_r(:)-1),1,Ni);
% Etot_rn2 = J./(eprr);
clear Z J1
%% Generate Scattered E field
[xr, xpr] = meshgrid(X, x(:));
[yr, ypr] = meshgrid(Y, y(:));
dist_rx_pix = sqrt((xr-xpr).^2 + (yr-ypr).^2);
ZZ = -imp*pi*cellrad/2*besselj(1,k0*cellrad)*besselh(0,1,k0*dist_rx_pix'); % Ns x M^2
% eprr = repmat((epsono_r(:)-1),1,Ni);
% E_s1 = (k0^2)*((1i*pi*cellrad/(2*k0))*...
%     besselj(1,k0*cellrad)*...
%     besselh(0,1,k0*dist_rx_pix'))*(eprr.*Etot_rn);
if Ant_dir==1
    Ref_theta_Rx_Rn = repmat(TxRx_ref_theta(:,3)',M^2,1);
    Theta_Rx_Rn = round(abs(abs(atand((yr-ypr)./(xr-xpr)))-Ref_theta_Rx_Rn));
    G_Rx_Rn=zeros(size(Theta_Rx_Rn));
    for i = 1:M^2
        G_Rx_Rn(i,:) = Antenna_gain_phi0(Theta_Rx_Rn(i,:)+1,ant);
    end
    ZZ=ZZ.*sqrt(G_Rx_Rn)'*Cr;
end
E_s = ZZ*J; % Ns x Ni
clear dist_rx_pix xr J yr xpr ypr G_Rx_Rn Theta_Rx_Rn ZZ
%%
if NodeMode==0 % nodes are not transreceivers
TxRxpairs=[];
for iii=1:length(Tx_pos(:,1))
    for jjj=1:length(Rx_pos(:,1))
        TxRxpairs= [TxRxpairs; iii,jjj];
    end
end
end
if NodeMode==1
TxRxpairs=[];
for iii=1:length(Tx_pos(:,1))
    for jjj=1:length(Rx_pos(:,1))
        if iii~=jjj
        TxRxpairs= [TxRxpairs; iii,jjj];
        end
    end
end
end
TxRxpairs=TxRxpairs';
%% Remove NaN
E_ds = E_d + E_s; % Ns x Ni; total field at RX = direct wave + scattered wave
E_ds1 = E_ds;
E_d1 = E_d;
if NodeMode==1
    if NaNremove ==1    
    E_d(logical(eye(size(E_d)))) = []; % Or A = A(~eye(size(A)))
    E_d = reshape(E_d, Ns-1,Ni); 
    E_ds(logical(eye(size(E_ds)))) = []; % Or A = A(~eye(size(A)))
    E_ds = reshape(E_ds, Ns-1,Ni); 

    E_s(logical(eye(size(E_s)))) = []; % Or A = A(~eye(size(A)))
    E_s = reshape(E_s, Ns-1,Ni);     
    end
    if NaNremove==0
    E_d(logical(eye(size(E_d)))) = 0; % Or A = A(~eye(size(A)))
    E_d = reshape(E_d, Ns,Ni); 
    E_ds(logical(eye(size(E_ds)))) = 0; % Or A = A(~eye(size(A)))
    E_ds = reshape(E_ds, Ns,Ni); 
    end    
end
TxRx1=Rx_pos;
%% Noise??
% rand_real = randn(Ns,Ni);
% rand_imag = randn(Ns,Ni);
% % E_Gaussian = 2/sqrt(2) *sqrt(1/Ns/Ni)*norm(E_s,'fro') *nl*(rand_real +1i*rand_imag);
% % E_s = E_s + E_Gaussian;
% E_Gaussian = 1/sqrt(2) *sqrt(1/Ns/Ni)*norm(E_ds,'fro') *nl*(rand_real +1i*rand_imag);
% E_ds = E_ds + E_Gaussian;   % Ns x Ni; total field at RX = direct wave + scattered wave
F_ds = abs(E_ds);           % Ns x Ni; amplitude of total field at RX
%% Save data
Pinc = ((abs(E_d)).^2)*(lambda*lambda)/(4*pi*imp);
Pinc = 10*log10(Pinc/1e-3);
Ptot = ((abs(E_ds)).^2)*(lambda*lambda)/(4*pi*imp);
Ptot = 10*log10(Ptot/1e-3);

Pinc1 = ((abs(E_d1)).^2)*(lambda*lambda)/(4*pi*imp);
Pinc1 = 10*log10(Pinc1/1e-3);
Ptot1 = ((abs(E_ds1)).^2)*(lambda*lambda)/(4*pi*imp);
Ptot1 = 10*log10(Ptot1/1e-3);
% E_dsInv = sqrt((10.^(Ptot/10))*(1e-3)*4*pi*imp/lambda^2);  
% E_dsInv(E_dsInv<1e-15)=0;

TxRx1=Tx_pos;
save ('TxRxpairs.mat','TxRxpairs')
save ('size_DOI.mat','size_DOI')
save ('Pinc.mat','Pinc')
save ('Ptot.mat','Ptot')
save ('TxRx1.mat','TxRx1')
save ('xm.mat','xm')
save ('ym.mat','ym')
save ('Ni.mat','Ni')
save ('E_d.mat','E_d')
save ('E_ds1.mat','E_ds1')
save ('E_s.mat','E_s')
%% plot
figure(7); 
imagesc(tx,ty,(epsono_r)); hold on;
set(gca,'YDir','normal');
% set(gcf,'color','w');
colormap(jet);
xlim([min(xm) max(xm)])
ylim([min(ym) max(ym)])
set(gca,'FontSize',15)
% axis equal
xticks([min(xm):0.6:max(xm)])
yticks([min(xm):0.6:max(xm)])
% colormap(gray);
xlabel('meters') 
ylabel('meters') 
colorbar;
scatter(X', Y', 100,'o','filled'); 
labels = num2str([1:length(TxRx1(:,1))]'); {'label 1','label 2','label 3'};
text(TxRx1(:,1),TxRx1(:,2),labels,'FontSize',14,'VerticalAlignment','top','HorizontalAlignment','left', 'Color','red')

% scatter(X_tx', Y_tx', 60,'o','filled'); 
grid on;
% rectangle('Position',[0.5-0.2 0.5-0.2 0.4 0.4],'Curvature',[1,1],...
%     'EdgeColor','r','LineWidth',3,'LineStyle','--'); 
hold off;
% figure(8)
%%
grids = M;
%% 
figure(2)
plot(1:Ns-1, F_ds(:,Ni), 'b', 1:Ns-1, abs(E_d(:,Ni)), 'r',...
    1:Ns-1, abs(E_s(:,Ni)), 'k')
legend('Total','Inc','Scattered')
figure(3)
plot(1:Ns-1, real(E_ds(:,Ni)), 'b', 1:Ns-1, real(E_d(:,Ni)), 'r',...
    1:Ns-1, real(E_s(:,Ni)), 'k')
legend('Total real','Inc real','Scattered real')
figure(4)
plot(1:Ns-1, imag(E_ds(:,Ni)), 'b', 1:Ns-1, imag(E_d(:,Ni)), 'r',...
    1:Ns-1, imag(E_s(:,Ni)), 'k')
legend('Total imag','Inc imag','Scattered imag')

figure(5)
plot(1:Ns-1, Ptot(:,Ni))
% clearvars -except Pt F_ds_exp Cr Ct Antenna_gain_phi0 TxRx_ref_theta Ant_dir hsideX hsideY centerY centerX grids loopss NodeMode R_tx R_obs freq lambda k0 imp size_DOI Ni Ns theta phi R_obs X Y epsono_r_c E_s J X_tx Y_tx E_d E_ds F_ds;
% clearvars -except Pt hsideX hsideY centerY centerX grids loopss NodeMode R_tx R_obs freq lambda k0 imp size_DOI Ni Ns theta phi R_obs X Y epsono_r_c E_s J X_tx Y_tx E_d E_ds F_ds;