clear; close all; clc; 
tic
%% Load data saved from forward MoM code
load ('TxRxpairs.mat','TxRxpairs')
Nodes=TxRxpairs; % Just rename it to be short
clear TxRxpairs
load ('TxRx1.mat','TxRx1')  % Load Node location coordinates
TxRx = TxRx1; 
load ('size_DOI.mat','size_DOI')  % Load DOI size
load ('Ni.mat','Ni');  % Load number of nodes
Ns=Ni; 
load('E_d.mat','E_d')  % Load incident field values from Forw code
load('E_ds1.mat','E_ds1')  % Load total field values from Forw code
load ('Pinc.mat','Pinc') % Load incident power values from Forw code
load ('Ptot.mat','Ptot') % Load total field values from Forw code
RoomLength = size_DOI; 
RoomWidth = size_DOI;
%% Constants
Imp = 120*pi;   % Intrensic Impedance
freq = 2.4e9;   % Frequency
lambda = 3e8/freq; 
k0 = 2*pi/lambda; 
clear opts   % Ignore it, it is for TV library
%% Paramters
gridXres = 0.01;  % Resolution of grid (Should be poorer than Forward problem)
gridYres = gridXres; 
SemiMin = 12*gridXres/2;
RegPar=10000;  %for Ridge or Lasso
invOP = 'ridge';
Method ='PRytov';  % LOS Rytov Born PRytov  (PRytov is phaseless Rytov)
Nlambda = 40;
%%
tx = gridXres/2:gridXres:RoomLength-gridXres/2;%0:gridXres:2;%1:gridYres:2;%
ty = RoomWidth-gridYres/2:-gridYres:gridYres/2;
[x,y] = meshgrid(tx,ty);
M =length(tx);
%% Constants                                                                    % Correction factor                                                     % Free Space permittivity
Gridarea = gridXres*gridYres;  
Gridvol = Gridarea*gridYres;                                              % Area of one grid
cellrad = (sqrt(gridXres^2/pi)*2)/2; % radius of cells
%% Definition of the Direct Waves (from TX to RX)
[xt_d, xr_d] = meshgrid(TxRx(:,1), TxRx(:,1));
[yt_d, yr_d] = meshgrid(TxRx(:,2), TxRx(:,2));
distTxRx = sqrt((xt_d-xr_d).^2 + (yt_d-yr_d).^2);
E_d =   (1i/4)*besselh(0,1,k0*distTxRx);  % Ns x Ni
% E_d =   exp(1i*k0*dist_tx_rx)./(4*pi*dist_tx_rx);  % Ns x Ni % Note that nth column is nth Tx and for each Tx, rows are Rx
% E_d(logical(eye(size(E_d)))) = []; % 
% E_d = reshape(E_d, Ni-1, Ni); 
clear xt_d xp_d yt_d yp_d
%% Definition of the Incident Waves (from TX to domain of interest)
[xt, xp] = meshgrid(TxRx(:,1), x(:));
[yt, yp] = meshgrid(TxRx(:,2), y(:));
distTxRn = sqrt((xt-xp).^2 + (yt-yp).^2);
E_inc =   (1i/4)*besselh(0,1,k0*distTxRn);  % M^2 x Ni for cylindrical wave
% E_inc = exp(1i*k0*dist_tx_pix)./(4*pi*dist_tx_pix);  % M^2 x Ni for cylindrical wave
clear xt yt xp yp
%% Calculate integral of greens function
[xr, xpr] = meshgrid(TxRx(:,1), x(:));
[yr, ypr] = meshgrid(TxRx(:,2), y(:));
distRxRn = sqrt((xr-xpr).^2 + (yr-ypr).^2); distRxRn=distRxRn';
Zryt = (1i*pi*cellrad/(2*k0))*besselj(1,k0*cellrad)*besselh(0,1,k0*distRxRn); %Ns x M^2 Integral of greens fubtion
clear xr yr xpr ypr
%% Implement Born, Rytov, PRytov, LOS

if strcmp(Method,'Born')
%     data = (E_ds1-E_d).';
%     data(logical(eye(size(data)))) = []; 
%     data = data';  
    A = zeros(length(Nodes(1,:)), M^2);
    for i = 1:length(Nodes(1,:))    
    A(i,:) = (k0^2)*( Zryt(Nodes(2,i),:) ...
        .*(E_inc(:,Nodes(1,i))).');  % Only transpose no conjugateee
    end
    E_d(logical(eye(size(E_d)))) = []; % Or A = A(~eye(size(A)))
    E_ds1(logical(eye(size(E_ds1)))) = [];    
    data= (E_ds1'-E_d');%log((E_ds1.')./(E_d.'));    
end
if strcmp(Method,'Rytov')

%     data1(logical(eye(size(data1)))) = []; 
%     data1 = data1';    
    A = zeros(length(Nodes(1,:)), M^2);
    for i = 1:length(Nodes(1,:))   
    A(i,:) = (k0^2)*( Zryt(Nodes(2,i),:) ...
        .*(E_inc(:,Nodes(1,i))).' ...
        ./(E_d(Nodes(2,i), Nodes(1,i))) );
    end
    E_d(logical(eye(size(E_d)))) = []; % Or A = A(~eye(size(A)))
    E_ds1(logical(eye(size(E_ds1)))) = [];    
    data= log((E_ds1.')./(E_d.'));
end
if strcmp(Method,'PRytov')
    data=(Ptot(:)-Pinc(:))/(10*log10(exp(2)));
    A = zeros(length(Nodes(1,:)), M^2);
    for i = 1:length(Nodes(1,:))   
        A(i,:) = real((k0^2)*( Zryt(Nodes(2,i),:) ...
        .*(E_inc(:,Nodes(1,i))).' ...
        ./(E_d(Nodes(2,i), Nodes(1,i))) ));
    end
end
if strcmp(Method,'LOS')
    data=(Ptot(:)-Pinc(:))/(10*log10(exp(-2)));    
    A= zeros(length(Nodes(1,:)), M^2);
    for i = 1:length(Nodes(1,:))   
        Thresh = 2*sqrt((distTxRx(Nodes(2,i), Nodes(1,i))^2)/4 + SemiMin^2);    
        foc_sum = distRxRn(Nodes(2,i),:)+distTxRn(:,Nodes(1,i))';
        foc_sum(foc_sum > Thresh) = 0;
        foc_sum(foc_sum ~= 0) = 1;        
        A(i,:) = foc_sum;%./sqrt((distTxRx(Nodes(2,i), Nodes(1,i))));
    end
end

clear Zryt TxRxpairs
% E_d = reshape(E_d, Ns-1,Ni); 
%% Optimize
p=RoomWidth/gridYres; % = M
q=RoomLength/gridXres; % = M
if strcmp(invOP,'lsq')
    A1 = A-mean(A,2);
    PO = A1'*A1/380; POL = diag(diag(PO)); PO=PO - diag(diag(PO));  
    P = mean(PO(:)); PO = 1-eye(size(PO));
    PO = P.*PO;  PO = PO+diag(diag(POL));
    chi =  (A1'*A1 + 0.05*PO)\A'*data;
%     chi =  (A'*A + diag(diag(A'*A)))\A'*data;
%     chi =  (A'*A + diag(diag(A'*A)))\A'*data;
    
    chi =reshape(chi, M, M); 
  figure(50)
    imagesc(tx,ty,(chi+1)); 
    colormap hot
    view([0 -90])
    colorbar
    ax = gca;
    ax.FontSize = 14;
    ax.XTick = [0:0.5:3];
    ax.YTick = [0:0.5:3]; 
end
%% Lasso
if strcmp(invOP,'lasso')
      N = linspace(-10,(log10(norm( A'*data, 'inf' ))),Nlambda);
%       N = linspace(-10,10,Nlambda);      
RegPar = 10.^N;
      chi2D = zeros(M^2, length(RegPar));
      chi2D0 = zeros(M^2, length(RegPar));  
      
      hfig = figure;
        pos = get(hfig,'position');
        set(hfig,'position',pos.*[.5 1 2 1]); 
   for ii=1:length(RegPar)
        chi= lasso(A, data, RegPar(ii), 1, 1.8);
%         (A'*A + RegPar(ii)*eye(M^2))\A'*data; % Ridge
%         chi = chi+0.1.*rand(size(chi));
%         chi(chi<0.1)=1;
        chi2D0(:,ii) = chi;
%         chi = chi./max(chi(:))-mean(chi(:));
        chi=((chi)-mean(chi(:)))./max(chi(:));
%         chi = chi./max(chi(:));
%         chi=(chi)./max(chi(:));
%         chi=chi-mean(chi(:));
        chi2D(:,ii) = chi;
   %% plot  
%    if mod(ii,2)==0
   subplot(4,round(length(RegPar)/4),ii) ;    
%     chi = ;
    epr = 1+real(reshape(chi2D(:,ii), M,M));
%     figure(ii)
    clims = [0.5 1.5];
    imagesc(tx,ty,(epr)); 
    colormap hot
    view([0 -90])
    axis equal
%     colorbar
%     ax = gca;
%     ax.FontSize = 14;
    ax.XTick = [0:0.5:3];
    ax.YTick = [0:0.5:3]; 
%    end
   end      
end

%% Ridge
if strcmp(invOP,'ridge')
   N = linspace(-40,20,Nlambda);
   RegPar = 10.^N;
   chi2D = zeros(M^2, length(RegPar));
   chi2D0 = zeros(M^2, length(RegPar));   
   figure()
        hfig = figure;
        pos = get(hfig,'position');
        set(hfig,'position',pos.*[.5 1 2 1]); 
   for ii=1:length(RegPar)
        chi= (A'*A + RegPar(ii)*eye(M^2))\A'*data; % Ridge
    datafit(ii) = norm(data-A*chi, 2);
    regterm(ii) = norm(chi,2);
% chi = chi+0.1.*rand(size(chi));
%         chi(chi<0.1)=1;
        chi2D0(:,ii) = chi;
%         chi = (chi-mean(chi(:)))./max(chi(:));
%         chi=(chi)-mean(chi(:));
%         chi = chi./max(chi(:));
        chi=(chi)./max(chi(:))-mean(chi(:));
        chi2D(:,ii) = chi;
   %% plot  
%    if mod(ii,2)==0
   subplot(4,round(length(RegPar)/4),ii) ;    
%     chi = ;
    epr = 1+real(reshape(chi2D0(:,ii), M,M));
%     figure(ii)
    clims = [0.5 1.5];
    imagesc(tx,ty,(epr)); 
    colormap hot
    view([0 -90])
    axis equal
    str = compose("%d",ii);
    s = strcat('\lambda_{',str, '}');
% %     titles = {''}; str
    title(s, 'fontsize',10)
%     title('x^*(\lambda_)')
%     colorbar
%     h=colorbar;
%     set(h, 'Position', [.8314 .11 .0581 .8150])
%     ax = gca;
%     ax.FontSize = 14;
%     ax.XTick = [0:0.5:3];
%     ax.YTick = [0:0.5:3]; 
%    end
   end
end   

%% L-curve
figure(7)
plot(datafit, regterm)
labels = num2str([1:length(datafit)]'); {'label 1','label 2','label 3'};
text(datafit,regterm,...
    labels,'FontSize',14,'VerticalAlignment','top','HorizontalAlignment','left', 'Color','red')
xlabel('residual (||y-Ax||^2)')
ylabel('regularized term (||x||^2)')
%% Subspace Selection   
%    chi2D = (chi2D-mean(chi2D,2));%./std(chi2D,0,2);
   Sigma = (chi2D*chi2D')/length(N);%cov(chi2D.');%
%     coeff = pca(chi2D.')
   [V,D] = eig(Sigma); 
%    [Vmax Vmax_1]= SPCA(Sigma, 0.1);
   Vmax = V(:, M^2);
%    Vmax1 = (Vmax-mean(Vmax(:)))./max(Vmax(:));
   corr = sum(Vmax.*chi2D0);
   [val, ind]=max(corr);
    

eigval = diag(D);
%% PLOT
Vmax = reshape(Vmax, M,M) ;
    eprmax = 1+real(Vmax);
best_lam = 1+ real(reshape(chi2D0(:,ind), M,M)) ;
    
    figure(50)
    imagesc(tx,ty,(eprmax)); 
    colormap hot
    view([0 -90])
    colorbar
    ax = gca;
    ax.FontSize = 14;
%     ax.XTick = [0:0.5:3];
%     ax.YTick = [0:0.5:3]; 
    
    figure(51)
    imagesc(tx,ty,1+reshape(best_lam, M,M)); 
    colormap hot
    view([0 -90])
    colorbar
    ax = gca;
    ax.FontSize = 14;
%     ax.XTick = [0:0.5:3];
%     ax.YTick = [0:0.5:3]; 
%%
timeElapsed = toc