%find important characters
%%%%%%%%%%%%%%%%%%%%%%%%%%
keychar350=[];keychar_index=[];
for i=1:319
    if sum(data_319_475(i,:))>8
        keychar_index=[keychar_index,i];
        keychar350(end+1,:)=data_319_350(i,:);
    end
end

%how to find the real index in original excel?
%keychar_index->people_index->excel's index minus one

%construct the dissimilarity matrix here
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sim_mat=[];
for i=1:58
    for j=1:58
        a=keychar350(i,:);b=keychar350(j,:);
        sim_mat(i,j)=similarity(a,b,350);
    end
end
sim=[];
for i=1:58
    for j=1:58
        sim(i,j)=58*sim_mat(i,j)/(sqrt(sim_mat(i,i)*sim_mat(j,j)));
    end
end
dissim=58*ones(58,58)-sim;
% dissim=475*ones(58,58)-sim_mat;
[res,stress1]=mdscale(dissim,2);
name={'贾赦JiaShe', '贾政JiaZheng', '贾珍JiaZhen', '贾琏JiaLian', '贾宝玉JiaBaoyu', '贾环JiaHuan', '贾元春JiaYuanchun', '贾迎春JiaYingchun', '贾探春JiaTanchun', '贾惜春JiaXichun', '贾蓉JiaRong',...
'贾兰JiaLan', '贾蔷JiaQiang', '贾芸JiaYun', '贾巧姐JiaQiaojie', '史太君ShiTaijun', '史湘云ShiXiangyun', '王夫人WangFuren', '王仁WangRen', '王熙凤WangXifeng', '薛姨妈XueYima', '薛蟠XuePan', '薛蝌XueKe', '薛宝钗XueBaochai',...
'薛宝琴XueBaoqin', '林黛玉LinDaiyu', '邢夫人XingFuren', '尤氏YouShi', '李纨LiWan', '秦氏QinShi', '香菱Xiangling', '妙玉Miaoyu', '赵姨娘ZhaoYiniang', '刘姥姥LiuLaolao', '袭人Xiren', '晴雯Qingwen', '麝月Sheyue',...
'秋纹Qiuwen', '紫鹃Zijuan', '雪雁Xueyan', '鸳鸯Yuanyang', '琥珀Hupo', '莺儿Yinger', '平儿Pinger', '小红Xiaohong', '彩云Caiyun', '茗烟Mingyan', '李贵LiGui', '芳官Fangguan', '贾雨村JiaYucun', '周瑞家的ZhouRuiJiaDe',...
'秦钟QinZhong', '赖大LaiDa', '林之孝LinZhixiao', '林之孝家的LinZhixiaoJiaDe', '邢岫烟XingXiuyan', '李婶娘LiShenniang', '尤二姐YouErjie'};
plot(-1*res(:,1),-1*res(:,2),'o','LineWidth',2);
gname(name);



%similarity function
function sim=similarity(a,b,length)
    sim=0;
    for ii=1:length
        if (a(ii)==1 && b(ii)==1)
%         if (a(ii)==b(ii))
            sim=sim+1;
        end
    end
end