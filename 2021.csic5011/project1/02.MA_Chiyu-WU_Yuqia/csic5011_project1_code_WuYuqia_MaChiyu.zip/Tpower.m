function [xopt] = Tpower(x0, A, k)

max_iter = 5000;

x = x0;

n = length(x0);

for i = 1:max_iter
    
    xt = A * x;
    
    xt = xt/norm(xt);
    
    [~, I] = sort(-abs(xt));
    
    I = I(1:k); 
    
    xk = zeros(n, 1);
    
    xk(I) = xt(I); 
        
    xk = xk/norm(xk);
    
    if norm(x- xk) < 1.0e-6
        
        xopt = xk;
        
        return;
    end
    
    x = xk;
end