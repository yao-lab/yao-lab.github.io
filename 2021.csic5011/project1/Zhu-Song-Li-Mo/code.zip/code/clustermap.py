import pandas as pd

pinfo = pd.read_csv('./ceph_hgdp_minor_code_XNA.sampleInformation.csv', index_col=0)[['region']]

colors = '"#FF5D49" "#D09800" "#00BB00" "#00CE8F" "#00C4FF" "#AB77FF" "#FF00F3"'.split(' ')
j = 0
for i in sorted(pinfo['region'].unique()):
    color_dict[i] = colors[j].split('"')[1]
    j+=1
    
pinfo['region'] = pinfo['region'].map(color_dict)

snp = pd.read_csv('./ceph_hgdp_minor_code_XNA.betterAnnotated.csv', index_col=0).drop(columns=['chr','pos'])
snp = pd.get_dummies(snp.T, columns=snp.index)

import seaborn as sns

top_std_snps = snp.std().sort_values()[-5000:]

snp[top_std_snps.index].to_csv('./ceph_hgdp_minor_code_XNA.betterAnnotated.top.csv')

sns.clustermap(snp[top_std_snps.index], row_colors=pinfo[['region']], \
               cmap='gray', cbar_pos=(1, 0.23, .01, .3))