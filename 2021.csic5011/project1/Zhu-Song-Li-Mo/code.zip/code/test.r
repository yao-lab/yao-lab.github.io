
setwd("/Users/songdong/Dropbox/Dropbox/CSIC5011/SongD")
library(ggplot2)
library(DESeq2)
library(stringr)
library("pheatmap")
library("RColorBrewer")
library(fgsea)
library(ComplexHeatmap)
library(circlize)
library("SC3")

gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 150)[1:n]
}

#raw data preprocessing

counts1 <- read.csv("../../ceph_hgdp_minor_code_XNA.betterAnnotated.csv", sep=",", head=T, row.names = "snp")
nrow(counts1)
ncol(counts1)

counts <- na.omit(counts1)


## Create an object for storing names of samples and condition of the samples ##(Tumor/normal)

Name <- as.character(colnames(counts)[3:1045])
x.term <- as.character(trimws(Name, which = c("both", "left", "right"), whitespace = "[ \t\r\n]"))
Sample_features <- read.delim("../ceph_hgdp_minor_code_XNA.sampleInformation.csv",sep = ",",header = T)

samples <- data.frame(Sample_features)
rownames(samples) <- Sample_features$ID

all(rownames(samples) %in% colnames(counts))

rawMatrix <- counts[,3:1045]






## create DESeq2 object
#dds=DESeqDataSetFromMatrix(countData = counts[,3:1045],colData = samples,design = ~ region)
#nrow(dds)
#vsd <- vst(dds, blind = FALSE)
#head(assay(vsd), 3)
#expMatrix <- assay(vsd)
#library(preprocessCore)
#expMatrix_new <- normalize.quantiles(expMatrix, copy = TRUE)
#colnames(expMatrix_new) <- colnames(expMatrix)
#rownames(expMatrix_new) <- rownames(expMatrix)


#PCA
library(genefilter)
library(ggrepel)

expMatrix <- rawMatrix 
rv <- rowVars(expMatrix)
ntop <- 500
select <- order(rv, decreasing = TRUE)[seq_len(min(ntop,  length(rv)))]
pca <- prcomp(t(expMatrix[select, ]))

pca <- prcomp(t(expMatrix))
percentVar <- pca$sdev^2/sum(pca$sdev^2)
intgroup <- c("Gender","region","Geographic.area","Geographic.origin")
if (!all(intgroup %in% colnames(samples))) {
  stop("the argument 'intgroup' should specify columns of colData(dds)")
}
intgroup.df <- as.data.frame(samples[, intgroup, drop = FALSE])
group <- if (length(intgroup) > 1){ factor(apply(intgroup.df, 1, paste, collapse = " : ")) }else{ samples[[intgroup]]}

d <- data.frame(pca$x,intgroup.df)


myPCA <- ggplot()+theme_classic()
myPCA <- myPCA + geom_point(data = d, aes(x =PC1, y = PC2, shape = Gender, fill = region),alpha=0.6,width=0.2,size = 2.6) + 
 # geom_text(data=d,aes(x=PC1,y=PC2,label = as.factor(rownames(d))),color="black",size=2.5 )+
  xlab(paste0("PC1: ", round(percentVar[1] * 100), "% variance")) + scale_shape_manual(values=c(21,22,24),guide = guide_legend(override.aes=list(size=3.5)))+
  scale_fill_manual(values = gg_color_hue(7),guide = guide_legend(override.aes=list(shape=21,size=3.5)))+
  ylab(paste0("PC2: ", round(percentVar[2] * 100), "% variance")) + coord_fixed() 
myPCA <- myPCA + theme(panel.background=element_rect(fill='transparent',color='black'),plot.margin=unit(c(2,1,0.5,1),'lines'),plot.title=element_text(size=24,vjust=0.5,hjust=0.5,face='bold.italic'),
                       text=element_text(size=14,face='bold'),legend.key.width=unit(0.6,'cm'),legend.key.height=unit(0.6,'cm'),legend.position='right',
                       legend.margin=margin(t=0.1,r=0.1,b=0,l=0.1,unit='cm'),legend.text=element_text(size=14,face='bold.italic'),axis.text.y=element_text(size=14,face='bold',color='black'),
                       axis.text.x=element_text(size=14,face='bold',color='black'),axis.title.x=element_text(size=16,face='plain',color='black'),axis.title.y=element_text(size=16,hjust=0.5,vjust=2,face='plain',color='black'))
myPCA
figure_1<-rbind(ggplotGrob(myPCA ),size="first")
ggsave(file="figure2_1_PCA.pdf", plot=figure_1,bg = 'white', width = 24, height = 22, units = 'cm', dpi = 600)
write.table(d,"PCA.txt")
########


###t-sne
library(Rtsne)
expMatrix <- t(rawMatrix)

tsne <- Rtsne(expMatrix[!duplicated(expMatrix),])

intgroup <- c("Gender","region","Geographic.area","Geographic.origin")
intgroup.df <- as.data.frame(samples[, intgroup, drop = FALSE])
d <- data.frame(tSNE1 = tsne$Y[,1],
                tSNE2 = tsne$Y[,2],intgroup.df)

myTSNE <- ggplot()+theme_classic()
myTSNE <- myTSNE + geom_point(data = d, aes(x =tSNE1, y = tSNE2, shape = Gender, fill = region),alpha=0.6,width=0.2,size = 2.6) + 
  # geom_text(data=d,aes(x=PC1,y=PC2,label = as.factor(rownames(d))),color="black",size=2.5 )+
  xlab(paste0("tSNE1")) + scale_shape_manual(values=c(21,22,24),guide = guide_legend(override.aes=list(size=3.5)))+
  scale_fill_manual(values = gg_color_hue(7),guide = guide_legend(override.aes=list(shape=21,size=3.5)))+
  ylab(paste0("tSNE2")) + coord_fixed() 
myTSNE <- myTSNE + theme(panel.background=element_rect(fill='transparent',color='black'),plot.margin=unit(c(2,1,0.5,1),'lines'),plot.title=element_text(size=24,vjust=0.5,hjust=0.5,face='bold.italic'),
                       text=element_text(size=14,face='bold'),legend.key.width=unit(0.6,'cm'),legend.key.height=unit(0.6,'cm'),legend.position='right',
                       legend.margin=margin(t=0.1,r=0.1,b=0,l=0.1,unit='cm'),legend.text=element_text(size=14,face='bold.italic'),axis.text.y=element_text(size=14,face='bold',color='black'),
                       axis.text.x=element_text(size=14,face='bold',color='black'),axis.title.x=element_text(size=16,face='plain',color='black'),axis.title.y=element_text(size=16,hjust=0.5,vjust=2,face='plain',color='black'))
myTSNE
figure_2<-rbind(ggplotGrob(myTSNE ),size="first")
ggsave(file="figure2_2_TSNE.pdf", plot=figure_2,bg = 'white', width = 24, height = 22, units = 'cm', dpi = 600)

write.table(d,"tSNE.txt")

###UMAP
library(umap)
umap <- umap(expMatrix[!duplicated(expMatrix),])

df <- data.frame(UMAP1 = umap$layout[,1],
                 UMAP2 = umap$layout[,2],
                 intgroup.df)

myUMAP <- ggplot()+theme_classic()
myUMAP <- myUMAP + geom_point(data = df, aes(x =UMAP1, y = UMAP2, shape = Gender, fill = region),alpha=0.6,width=0.2,size = 2.6) + 
  # geom_text(data=d,aes(x=PC1,y=PC2,label = as.factor(rownames(d))),color="black",size=2.5 )+
  xlab(paste0("UMAP1")) + scale_shape_manual(values=c(21,22,24),guide = guide_legend(override.aes=list(size=3.5)))+
  scale_fill_manual(values = gg_color_hue(7),guide = guide_legend(override.aes=list(shape=21,size=3.5)))+
  ylab(paste0("UMAP2")) + coord_fixed() 
myUMAP <- myUMAP + theme(panel.background=element_rect(fill='transparent',color='black'),plot.margin=unit(c(2,1,0.5,1),'lines'),plot.title=element_text(size=24,vjust=0.5,hjust=0.5,face='bold.italic'),
                         text=element_text(size=14,face='bold'),legend.key.width=unit(0.6,'cm'),legend.key.height=unit(0.6,'cm'),legend.position='right',
                         legend.margin=margin(t=0.1,r=0.1,b=0,l=0.1,unit='cm'),legend.text=element_text(size=14,face='bold.italic'),axis.text.y=element_text(size=14,face='bold',color='black'),
                         axis.text.x=element_text(size=14,face='bold',color='black'),axis.title.x=element_text(size=16,face='plain',color='black'),axis.title.y=element_text(size=16,hjust=0.5,vjust=2,face='plain',color='black'))
myUMAP
figure_3<-rbind(ggplotGrob(myUMAP ),size="first")
ggsave(file="figure2_3_UMAP.pdf", plot=figure_3,bg = 'white', width = 24, height = 22, units = 'cm', dpi = 600)

write.table(df,"UMAP.txt")

#NMF
xxx <- read.table("../zhu/NMF.csv",sep = ",",header = T,row.names = "X")

dff <- data.frame(NMF1=t(xxx), intgroup.df)

myNMF <- ggplot()+theme_classic()
myNMF <- myNMF + geom_point(data = dff, aes(x =NMF1.1, y = NMF1.2, shape = Gender, fill = region),alpha=0.6,width=0.2,size = 2.6) + 
  # geom_text(data=d,aes(x=PC1,y=PC2,label = as.factor(rownames(d))),color="black",size=2.5 )+
  xlab(paste0("V1")) + scale_shape_manual(values=c(21,22,24),guide = guide_legend(override.aes=list(size=3.5)))+
  scale_fill_manual(values = gg_color_hue(7),guide = guide_legend(override.aes=list(shape=21,size=3.5)))+
  ylab(paste0("V2")) #+ coord_fixed() 
myNMF <- myNMF + theme(panel.background=element_rect(fill='transparent',color='black'),plot.margin=unit(c(2,1,0.5,1),'lines'),plot.title=element_text(size=24,vjust=0.5,hjust=0.5,face='bold.italic'),
                         text=element_text(size=14,face='bold'),legend.key.width=unit(0.6,'cm'),legend.key.height=unit(0.6,'cm'),legend.position='right',
                         legend.margin=margin(t=0.1,r=0.1,b=0,l=0.1,unit='cm'),legend.text=element_text(size=14,face='bold.italic'),axis.text.y=element_text(size=14,face='bold',color='black'),
                         axis.text.x=element_text(size=14,face='bold',color='black'),axis.title.x=element_text(size=16,face='plain',color='black'),axis.title.y=element_text(size=16,hjust=0.5,vjust=2,face='plain',color='black'))
myNMF
figure_4<-rbind(ggplotGrob(myNMF ),size="first")
ggsave(file="figure2_4_NMF.pdf", plot=figure_4,bg = 'white', width = 24, height = 18, units = 'cm', dpi = 600)


#MDS
sampleDists <- dist(t(rawMatrix))
mds <- cmdscale(sampleDists)

dfff <- data.frame(MDS1= mds[,1],MDS2=mds[,2], intgroup.df)

myMDS <- ggplot()+theme_classic()
myMDS <- myMDS + geom_point(data = dfff, aes(x =MDS1, y = MDS2, shape = Gender, colorl = region),alpha=0.6,width=0.2,size = 1.5) + 
  # geom_text(data=d,aes(x=PC1,y=PC2,label = as.factor(rownames(d))),color="black",size=2.5 )+
  xlab(paste0("MDS1")) + scale_shape_manual(values=c(ownames(d))),color="black",size=3.5 )+
  xlab(paste0("V1")) + scale_shape_manual(values=c(19,15,24),guide = guide_legend(override.aes=list(size=3.5)))+
  scale_color_manual(values = gg_color_hue(7),guide = guide_legend(override.aes=list(shape=15,size=3.5)))+
  ylab(paste0("MDS2")) #+ coord_fixed() 
myMDS <- myMDS + theme(panel.background=element_rect(fill='transparent',color='black'),plot.margin=unit(c(2,1,0.5,1),'lines'),plot.title=element_text(size=24,vjust=0.5,hjust=0.5,face='bold.italic'),
                         text=element_text(size=14,face='bold'),legend.key.width=unit(0.6,'cm'),legend.key.height=unit(0.6,'cm'),legend.position='right',
                         legend.margin=margin(t=0.1,r=0.1,b=0,l=0.1,unit='cm'),legend.text=element_text(size=14,face='bold.italic'),axis.text.y=element_text(size=14,face='bold',color='black'),
                         axis.text.x=element_text(size=14,face='bold',color='black'),axis.title.x=element_text(size=16,face='plain',color='black'),axis.title.y=element_text(size=16,hjust=0.5,vjust=2,face='plain',color='black'))
myMDS
figure_3<-rbind(ggplotGrob(myMDS ),size="first")
ggsave(file="figure2_5_MDS.pdf", plot=figure_3,bg = 'white', width = 24, height = 18, units = 'cm', dpi = 600)

write.table(dfff,"MDS.txt")


##random projection
xxx <- read.table("../jligm/random.projection.csv",sep = ",",header = T,row.names = "ID")

dffff <- data.frame(V1= xxx[,1],V2=xxx[,2], intgroup.df)

myRP <- ggplot()+theme_classic()
myRP <- myRP + geom_point(data = dffff, aes(x =V1, y = V2, shape = Gender, color = region),alpha=0.6,width=0.2,size = 1.5) + 
  # geom_text(data=d,aes(x=PC1,y=PC2,label = as.factor(rownames(d))),color="black",size=2.5 )+
  xlab(paste0("V1")) + scale_shape_manual(values=c(19,15,24),guide = guide_legend(override.aes=list(size=3.5)))+
  scale_color_manual(values = gg_color_hue(7),guide = guide_legend(override.aes=list(shape=15,size=3.5)))+
  ylab(paste0("V2")) #+ coord_fixed() 
myRP <- myRP + theme(panel.background=element_rect(fill='transparent',color='black'),plot.margin=unit(c(2,1,0.5,1),'lines'),plot.title=element_text(size=24,vjust=0.5,hjust=0.5,face='bold.italic'),
                       text=element_text(size=14,face='bold'),legend.key.width=unit(0.6,'cm'),legend.key.height=unit(0.6,'cm'),legend.position='right',
                       legend.margin=margin(t=0.1,r=0.1,b=0,l=0.1,unit='cm'),legend.text=element_text(size=14,face='bold.italic'),axis.text.y=element_text(size=14,face='bold',color='black'),
                       axis.text.x=element_text(size=14,face='bold',color='black'),axis.title.x=element_text(size=16,face='plain',color='black'),axis.title.y=element_text(size=16,hjust=0.5,vjust=2,face='plain',color='black'))
myRP
figure_6<-rbind(ggplotGrob(myRP ),size="first")
ggsave(file="figure2_6_RP.pdf", plot=figure_6,bg = 'white', width = 24, height = 18, units = 'cm', dpi = 600)



