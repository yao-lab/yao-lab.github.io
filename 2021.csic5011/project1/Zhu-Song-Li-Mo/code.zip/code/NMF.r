library(NMF)
snp = read.csv('~/Documents/Course/CSIC5011/Project1/ceph_hgdp_minor_code_XNA.betterAnnotated.top.csv', row.names = 'X')

pdf('~/Documents/Course/CSIC5011/Project1/ceph_hgdp_minor_code_XNA.betterAnnotated.top.NMF.pdf')

res<-nmf(t(snp), rank=2, nrun=200, .options='v', seed='nndsvd')
c_result = silhouette(res)
c2_result = silhouette(t(res))
write.csv(c2_result, '~/Documents/Course/CSIC5011/Project1/ceph_hgdp_minor_code_XNA.betterAnnotated.top.NMF.snpcluster.2.csv')
write.csv(c_result, '~/Documents/Course/CSIC5011/Project1/ceph_hgdp_minor_code_XNA.betterAnnotated.top.NMF.cluster.2.csv')
write.csv(res@fit@W, '~/Documents/Course/CSIC5011/Project1/ceph_hgdp_minor_code_XNA.betterAnnotated.top.NMF.W.2.csv')
write.csv(res@fit@H, '~/Documents/Course/CSIC5011/Project1/ceph_hgdp_minor_code_XNA.betterAnnotated.top.NMF.H.2.csv')
consensusmap(res, tracks = c("consensus:","silhouette:"))
