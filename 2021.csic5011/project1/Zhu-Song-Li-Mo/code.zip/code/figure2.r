
setwd("/Users/songdong/Dropbox/Dropbox/CSIC5011/SongD")
library(ggplot2)
library(DESeq2)
library(stringr)
library("pheatmap")
library("RColorBrewer")
library(fgsea)
library(ComplexHeatmap)
library(circlize)
library("SC3")

gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 150)[1:n]
}

#raw data preprocessing

Name <- as.character(colnames(counts)[3:1045])
x.term <- as.character(trimws(Name, which = c("both", "left", "right"), whitespace = "[ \t\r\n]"))
Sample_features <- read.delim("../ceph_hgdp_minor_code_XNA.sampleInformation.csv",sep = ",",header = T)

samples <- data.frame(Sample_features)
rownames(samples) <- Sample_features$ID

intgroup <- c("Gender","region","Geographic.area","Geographic.origin")
intgroup.df <- as.data.frame(samples[, intgroup, drop = FALSE])


d <- read.table("./tSNE.txt",sep = " ",header = T)



myTSNE <- ggplot()+theme_classic()
myTSNE <- myTSNE + geom_point(data = d, aes(x =tSNE1, y = tSNE2, shape = Gender, color = region),alpha=0.6,size = 1.5) + 
  # geom_text(data=d,aes(x=PC1,y=PC2,label = as.factor(rownames(d))),color="black",size=2.5 )+
  xlab(paste0("tSNE1")) + scale_shape_manual(values=c(19,15,24),guide = guide_legend(override.aes=list(size=3.5)))+
  scale_color_manual(values = gg_color_hue(7),guide = guide_legend(override.aes=list(shape=15,size=3.5)))+
  ylab(paste0("tSNE2")) + ggtitle("t-SNE")
myTSNE <- myTSNE + theme(panel.background=element_rect(fill='transparent',color='black'),plot.margin=unit(c(1,1,0.5,1),'lines'),plot.title=element_text(size=24,vjust=0.5,hjust=0.5,face='bold'),
                       text=element_text(size=14,face='bold'),legend.key.width=unit(0.6,'cm'),legend.key.height=unit(0.6,'cm'),legend.position='none',
                       legend.margin=margin(t=0.1,r=0.1,b=0,l=0.1,unit='cm'),legend.text=element_text(size=14,face='bold.italic'),axis.text.y=element_text(size=14,face='bold',color='black'),
                       axis.text.x=element_text(size=14,face='bold',color='black'),axis.title.x=element_text(size=16,face='plain',color='black'),axis.title.y=element_text(size=16,hjust=0.5,vjust=2,face='plain',color='black'))
myTSNE
figure_1<-rbind(ggplotGrob(myTSNE ),size="first")
ggsave(file="figure2_2_TSNE.pdf", plot=figure_1,bg = 'white', width = 24, height = 18, units = 'cm', dpi = 600)


###UMAP

df  <- read.table("./UMAP.txt",sep = " ",header = T)


myUMAP <- ggplot()+theme_classic()
myUMAP <- myUMAP + geom_point(data = df, aes(x =UMAP1, y = UMAP2, shape = Gender, color = region),alpha=0.6,width=0.2,size = 1.5) + 
  # geom_text(data=d,aes(x=PC1,y=PC2,label = as.factor(rownames(d))),color="black",size=2.5 )+
  xlab(paste0("UMAP1")) + scale_shape_manual(values=c(19,15,24),guide = guide_legend(override.aes=list(size=3.5)))+
  scale_color_manual(values = gg_color_hue(7),guide = guide_legend(override.aes=list(shape=15,size=3.5)))+
  ylab(paste0("UMAP2")) + ggtitle("UMAP")
myUMAP <- myUMAP + theme(panel.background=element_rect(fill='transparent',color='black'),plot.margin=unit(c(1,1,0.5,1),'lines'),plot.title=element_text(size=24,vjust=0.5,hjust=0.5,face='bold'),
                         text=element_text(size=14,face='bold'),legend.key.width=unit(0.6,'cm'),legend.key.height=unit(0.6,'cm'),legend.position='none',
                         legend.margin=margin(t=0.1,r=0.1,b=0,l=0.1,unit='cm'),legend.text=element_text(size=14,face='bold.italic'),axis.text.y=element_text(size=14,face='bold',color='black'),
                         axis.text.x=element_text(size=14,face='bold',color='black'),axis.title.x=element_text(size=16,face='plain',color='black'),axis.title.y=element_text(size=16,hjust=0.5,vjust=2,face='plain',color='black'))
myUMAP
figure_3<-rbind(ggplotGrob(myUMAP ),size="first")
ggsave(file="figure2_3_UMAP.pdf", plot=figure_3,bg = 'white', width = 24, height = 18, units = 'cm', dpi = 600)

#NMF
xxx <- read.table("../zhu/NMF.csv",sep = ",",header = T,row.names = "X")

dff <- data.frame(NMF1=t(xxx), intgroup.df)

myNMF <- ggplot()+theme_classic()
myNMF <- myNMF + geom_point(data = dff, aes(x =NMF1.1, y = NMF1.2, shape = Gender, color = region),alpha=0.6,width=0.2,size = 1.5) + 
  # geom_text(data=d,aes(x=PC1,y=PC2,label = as.factor(rownames(d))),color="black",size=2.5 )+
  xlab(paste0("NMF1")) + scale_shape_manual(values=c(19,15,24),guide = guide_legend(override.aes=list(size=3.5)))+
  scale_color_manual(values = gg_color_hue(7),guide = guide_legend(override.aes=list(shape=15,size=3.5)))+
  ylab(paste0("NMF2"))+ ggtitle("NMF")
myNMF <- myNMF + theme(panel.background=element_rect(fill='transparent',color='black'),plot.margin=unit(c(1,1,0.5,1),'lines'),plot.title=element_text(size=24,vjust=0.5,hjust=0.5,face='bold'),
                         text=element_text(size=14,face='bold'),legend.key.width=unit(0.6,'cm'),legend.key.height=unit(0.6,'cm'),legend.position='none',
                         legend.margin=margin(t=0.1,r=0.1,b=0,l=0.1,unit='cm'),legend.text=element_text(size=14,face='bold.italic'),axis.text.y=element_text(size=14,face='bold',color='black'),
                         axis.text.x=element_text(size=14,face='bold',color='black'),axis.title.x=element_text(size=16,face='plain',color='black'),axis.title.y=element_text(size=16,hjust=0.5,vjust=2,face='plain',color='black'))
myNMF
figure_4<-rbind(ggplotGrob(myNMF ),size="first")
ggsave(file="figure2_4_NMF.pdf", plot=figure_4,bg = 'white', width = 24, height = 18, units = 'cm', dpi = 600)

#MDS
dfff <- read.table("./MDS.txt",sep = " ",header = T)

myMDS <- ggplot()+theme_classic()
myMDS <- myMDS + geom_point(data = dfff, aes(x =MDS1, y = MDS2, shape = Gender, color = region),alpha=0.6,width=0.2,size = 1.5) + 
  # geom_text(data=d,aes(x=PC1,y=PC2,label = as.factor(rownames(d))),color="black",size=2.5 )+
  xlab(paste0("MDS1")) + scale_shape_manual(values=c(19,15,24),guide = guide_legend(override.aes=list(size=3.5)))+
  scale_color_manual(values = gg_color_hue(7),guide = guide_legend(override.aes=list(shape=15,size=3.5)))+
  ylab(paste0("MDS2")) + ggtitle("MDS")
myMDS <- myMDS + theme(panel.background=element_rect(fill='transparent',color='black'),plot.margin=unit(c(1,1,0.5,1),'lines'),plot.title=element_text(size=24,vjust=0.5,hjust=0.5,face='bold'),
                       text=element_text(size=14,face='bold'),legend.key.width=unit(0.6,'cm'),legend.key.height=unit(0.6,'cm'),legend.position='none',
                       legend.margin=margin(t=0.1,r=0.1,b=0,l=0.1,unit='cm'),legend.text=element_text(size=14,face='bold.italic'),axis.text.y=element_text(size=14,face='bold',color='black'),
                       axis.text.x=element_text(size=14,face='bold',color='black'),axis.title.x=element_text(size=16,face='plain',color='black'),axis.title.y=element_text(size=16,hjust=0.5,vjust=2,face='plain',color='black'))
myMDS
figure_3<-rbind(ggplotGrob(myMDS ),size="first")
ggsave(file="figure2_5_MDS.pdf", plot=figure_3,bg = 'white', width = 24, height = 18, units = 'cm', dpi = 600)




figure_all2<-rbind( cbind(ggplotGrob(myMDS),ggplotGrob(myNMF)),
                    cbind(ggplotGrob(myTSNE),ggplotGrob(myUMAP)),size="first")
ggsave(file="figure3_4DR.pdf", plot=figure_all2,bg = 'white', width = 32, height = 26, units = 'cm', dpi = 600)

figure_all2<-cbind(ggplotGrob(myMDS),ggplotGrob(myNMF),ggplotGrob(myTSNE),ggplotGrob(myUMAP),size="first")
ggsave(file="figure3_4DR.pdf", plot=figure_all2,bg = 'white', width = 50, height = 13, units = 'cm', dpi = 600)



myMDS <- ggplot()+theme_classic()
myMDS <- myMDS + geom_point(data = dfff, aes(x =MDS1, y = MDS2, shape = Gender, color = region),alpha=0.9,width=0.2,size = 1.5) + 
  # geom_text(data=d,aes(x=PC1,y=PC2,label = as.factor(rownames(d))),color="black",size=2.5 )+
  xlab(paste0("MDS1")) + scale_shape_manual(values=c(19,15,24),guide = guide_legend(override.aes=list(size=3.5),nrow=2))+
  scale_color_manual(values = gg_color_hue(7),guide = guide_legend(override.aes=list(shape=15,size=3.5),nrow=1))+
  ylab(paste0("MDS2")) + ggtitle("MDS")
myMDS <- myMDS + theme(panel.background=element_rect(fill='transparent',color='black'),plot.margin=unit(c(1,1,0.5,1),'lines'),plot.title=element_text(size=24,vjust=0.5,hjust=0.5,face='bold'),
                       text=element_text(size=14,face='bold'),legend.key.width=unit(0.6,'cm'),legend.key.height=unit(0.6,'cm'),legend.position='top',
                       legend.margin=margin(t=0.1,r=0.1,b=0,l=0.1,unit='cm'),legend.text=element_text(size=14,face='bold.italic'),axis.text.y=element_text(size=14,face='bold',color='black'),
                       axis.text.x=element_text(size=14,face='bold',color='black'),axis.title.x=element_text(size=16,face='plain',color='black'),axis.title.y=element_text(size=16,hjust=0.5,vjust=2,face='plain',color='black'))
myMDS
figure_3<-rbind(ggplotGrob(myMDS ),size="first")
ggsave(file="legend1.pdf", plot=figure_3,bg = 'white', width =48, height = 18, units = 'cm', dpi = 600)








###figure1


xxx <- read.table("../jligm/random.projection.csv",sep = ",",header = T,row.names = "ID")

dffff <- data.frame(V1= xxx[,1],V2=xxx[,2], intgroup.df)

myRP <- ggplot()+theme_classic()
myRP <- myRP + geom_point(data = dffff, aes(x =V1, y = V2, shape = Gender, color = region),alpha=0.6,width=0.2,size = 1.5) + 
  # geom_text(data=d,aes(x=PC1,y=PC2,label = as.factor(rownames(d))),color="black",size=2.5 )+
  xlab(paste0("V1")) + scale_shape_manual(values=c(19,15,24),guide = guide_legend(override.aes=list(size=3.5)))+
  scale_color_manual(values = gg_color_hue(7),guide = guide_legend(override.aes=list(shape=15,size=3.5)))+
  ylab(paste0("V2")) #+ coord_fixed() 
myRP <- myRP + theme(panel.background=element_rect(fill='transparent',color='black'),plot.margin=unit(c(2,1,0.5,1),'lines'),plot.title=element_text(size=24,vjust=0.5,hjust=0.5,face='bold.italic'),
                     text=element_text(size=14,face='bold'),legend.key.width=unit(0.6,'cm'),legend.key.height=unit(0.6,'cm'),legend.position='none',
                     legend.margin=margin(t=0.1,r=0.1,b=0,l=0.1,unit='cm'),legend.text=element_text(size=14,face='bold.italic'),axis.text.y=element_text(size=14,face='bold',color='black'),
                     axis.text.x=element_text(size=14,face='bold',color='black'),axis.title.x=element_text(size=16,face='plain',color='black'),axis.title.y=element_text(size=16,hjust=0.5,vjust=2,face='plain',color='black'))
myRP
figure_6<-rbind(ggplotGrob(myRP ),size="first")
ggsave(file="figure2_6_RP.pdf", plot=figure_6,bg = 'white', width = 24, height = 18, units = 'cm', dpi = 600)




