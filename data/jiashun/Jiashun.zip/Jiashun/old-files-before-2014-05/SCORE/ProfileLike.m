function estlabel = ProfileLike(A,flag) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%This is Zhao et al's algorithm. The%%%%% 
%%problem of their algorithm is that%%%%%% 
%%it needs a guess to start. A simple fix%
%%is to start with estimates by SCORE,%%%% 
%%oPCA, or nPCA.%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%flag = 0,1,2: initial label vector%%%%%% 
%%computed from oPCA, nPCA, and SCORE%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


d = sum(A);
n = length(d);
D = diag(d.^(-1/2));
B = D*A*D;

[vb,db] = eigs(A,2);
vb1 = vb(:,1);
vb2 = vb(:,2);
rb = vb2./vb1;
[vc,dc] = eigs(B,2);

inita = kmeans(vb,2);
initb = kmeans(vc,2); 
initc = kmeans(rb,2);

init = ones(n,1);
if flag == 0
    init = inita;
else if flag == 1
        init = initb;
    else if flag == 2
            init = initc;
        end
    end
end

[XOptimal, VOptimal] = mutiExp(A, init, 2); 
estlabel = XOptimal; 

