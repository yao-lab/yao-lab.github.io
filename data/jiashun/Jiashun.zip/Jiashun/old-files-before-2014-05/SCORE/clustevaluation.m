function evaluation = clustevaluation(groups_true, groups)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Countesy of Tracy Zhen Ke%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = size(groups_true,1);
if (size(groups,1)~= p)
    error('Dimensions do not match!')
end

% compute the sizes of intersections
K = max(groups_true);
G = max(groups);
intersets = zeros(K, G);
for k = 1:K
    for g = 1:G
        intersets(k,g) = sum(groups_true==k & groups==g);
    end
end

% purity
purity1 = sum(max(intersets, [], 2))/p;
purity2 = sum(max(intersets, [], 1))/p;


% NMI(normalized mutural information)
I = 0;
for k = 1:K
    for g = 1:G
        sizek = sum(groups_true==k);
        sizeg = sum(groups== g);
        sizekg = intersets(k,g);
        if (sizekg >0)
            I = I + sizekg/p*log(p*sizekg/sizek/sizeg);
        end
    end
end
Hk = 0;
for k = 1:K
    sizek = sum(groups_true==k);
    Hk = Hk - sizek/p*log(sizek/p);
end
Hg = 0;
for g = 1:G
    sizeg = sum(groups==g);
    Hg = Hg - sizeg/p*log(sizeg/p);
end
NMI = 2*I/(Hk + Hg);


% FP/FN
TP = 0; 
FP = 0;
FN = 0;
TN = 0;
for i = 1:p
    for j = (i+1):p
        if (groups_true(i)==groups_true(j))
            TP = TP + (groups(i)==groups(j));
            FN = FN + (groups(i)~=groups(j));
        else
            TN = TN + (groups(i)~=groups(j));
            FP = FP + (groups(i)==groups(j));
        end
    end
end
typeI = FP/(FP+TN);
typeII = FN/(FN+TP);


evaluation.purity1 = purity1;
evaluation.purity2 = purity2;
evaluation.NMI = NMI;
evaluation.typeI = typeI;
evaluation.typeII = typeII;



end