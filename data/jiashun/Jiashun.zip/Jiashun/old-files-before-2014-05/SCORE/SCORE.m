blogs  = load('polblogsgiant.txt');
blogsy = load('polblogsgianty.txt');
blogindx = find(blogsy == 1);
blogindy = find(blogsy == 2);

nb = length(blogsy);
ellb = (1:nb)';

%%%%%Obtain vector of coordinate-wise ratios 
[vb,db] = eigs(blogs,2);
vb1 = vb(:,1);
vb2 = vb(:,2);
rb = vb2./vb1;


%%%%Clustering with rb using kmeans
kmeanslabel = kmeans(rb,2);
err1 = sum(abs(kmeanslabel - blogsy));
if err1 > nb/2
    kmeanslabel = 3 - kmeanslabel; 
    err1 = sum(abs(kmeanslabel - blogsy));
end