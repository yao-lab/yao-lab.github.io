function estlabel = NewmanSM(A)

k = sum(A); 
m = sum(k); 
b = k'*k/m;
B = A - b;

[xi,ev] = eigs(B,1);
estlabel = (3 + sign(xi))/2;
estlabel = round(estlabel);