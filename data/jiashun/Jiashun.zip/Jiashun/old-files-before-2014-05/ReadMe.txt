﻿
Data Description 


The data set covers all papers between 2003 and the first quarter of 2012 from the Annals of Statistics, Journal of the American Statistical Association, Biometrika and Journal of the Royal Statistical Society Series B. The paper corrections and errata are not included.

Data Sources: 
              MathScinet by the American Mathematical Society
              Web of Science by Thomson Reuters 
 

Data File List:

             4Journals.bib - the raw bibtex data for about 3500 items including papers, book reviews, corrections, etc
     4Journals_cleaned.bib - the cleaned bibtex data for 3248 papers after removing the book reviews, paper corrections and clustering the author names
	 
    	author-cluster.txt - the final clustering rules for the author names
		author-cluster-man.txt - the manually defined clustering rules for the author names
		
           author_list.txt - the list of the 3607 valid authors after disambiguation
author-paper-adjacency.txt - the 3607x3248 bipartite adjacency matrix 
    coauthor-adjacency.txt - the 3607x3607 coauthor adjacency matrix 
    citation-adjacency.txt - the 3607x3607 adjacency matrix for the citation network of authors
	

Coauthorship Analysis File List:    

                 coauthor-component.txt - the 3607x1 component label for each author in the coauthorship network
         coauthor-component-members.txt - the list of members of the big components other than the giant one 
coauthor-giant-component-has-2263-members.txt - the list of 2263 members of the giant component of the coauthorship network

     community-2-1-has-2237-members.txt - the list of 2237 members of the 1st of K=2 communities within the giant component using SCORE. Other similar names follows.
	
	
---------------------		
Data Summary


Collect the data

The coauthor and citation data are everywhere and very accessible to researchers through the free services, such as Google Scholar, or the subscription based services, such as Web of Science by Thomson Reuters or the MathSciNet by the American Mathematical Society, or Scopus by Elsevier.

But when it comes to volume and quality data simultaneously, the sources are surprisingly limited. It took us a few months to collect and combine data from different sources. For example, due to copyright issues, Google Scholar does not provide volume data in any form and aggressively blocks any one, either a human being or a machine, who attempts to retrieve the data in volume in some period of time. Even if you obtain some data little by little from Google, you would always see some very messy and incomplete parts. Scopus is also very strict with volume data, and so this source does not work for our purpose either.

What is more, to maintain their competitive advantage or avoid copyright issues, all services are trying to hide some important information even if you would like to pay them for that. MathSciNet provides the author names as they appear in the journals, but does not provide citation counts or the citing papers to a given paper, while Web of Science is well known for the citation index, and has its own author identification system, but it does not allow complete first or middle names in queries and causes even more ambiguities on our end.

In order to identify the papers and authors accurately, we have to combine the data from the Web of Science and the MathSciNet. Every service has its own paper identifier, but we choose the Digital Object Identifier (DOI) as the universal identifier. The DOI is a unique identifier across all publishers, and has been used by major publishers of statistics journals since 2000. Choosing the DOI also means no data from Google Scholar can be used in our analysis, since it does not include the DOI at all.  It turns out to be the most reliable variable we use to retrieve and combine information from different sources, even though we realize that the Web of Science missed the DOIs of about 200 papers in this study, and the MathSciNet missed another 100 papers. So we have to use other information of these papers to retrieve the citation data from the website.

To obtain the coauthorship network accurately, we have to identify the authors accurately. Due to name abbreviations, changes, different spelling rules, there are a few hundreds of author names which can be ambiguous. In particular, a substantial number of papers in Biometrika do not include the complete first names or middle initials. For instances, there are three authors named "Jun Li", and "L. Wang" can be any one of "Lan Wang", "Li Wang", "Lianming Wang", "Lie Wang", "Lifeng Wang", "Lihong Wang", "Liqun Wang" and "Lu Wang". 


The author misidentification has been a long-standing problem for all citation services. Every service has its own internal identification systems, and tends not to reveal it to the end users. It is not possible to evaluate their systems, but for the range of papers and authors in our study, it is easy to find examples for each identification system to fail or cause more problems for our purpose.

At the technical level, we use R to parse the XML pages and collect the data. We focus on the papers between 2003 and the first quarter of 2012 from the Annals of Statistics, Journal of the American Statistical Association, Biometrika and Journal of the Royal Statistical Society Series B. For each paper in the range, we have collected the DOI, title, author, abstract, keywords, journal name, issue, pages, and also the DOIs of the articles in this range which have cited this paper.  The raw data set includes about 3500 articles, and 4000 authors.

Clean the data

To make our analysis more accurate, we have excluded the book reviews, paper corrections, comments or rejoinders, letters to the editors and other editorial materials in the analysis. Usually, they have signal words such as "Book Review", "Correction:" and so on in the title. Finally, there are about 3248 papers in the study.

The author identification step also takes several rounds and about a few months to finish. We first cluster the informative names such as "Jonathan E. Taylor", "Jonathan Taylor" and "J. E. Taylor" by their similarities defined by the inclusion of one by the other.  Then we try to disambiguate very abbreviated names such as "J. Taylor" , i.e. identifying this author from "Jonathan E. Taylor", "James W. Taylor", "Jeremy M. G. Taylor", or someone else. The latter step can not be automated and has to been done manually through various ways, e.g., their affiliations, email addresses, collaborators or their own websites. 

What is even more challenging is to notice and identify the authors with identical names, such as "Jun Li". Additionally, some Chinese names are spelled in various ways. For example, all "Lixing Zhu", "Li Xing Zhu", "L. X. Zhu" and "Li-Xing Zhu" mean the same author. We inspect short names with different coauthors, and then manually check the email addresses and affiliations.  The number of authors is reduced by about 400, or 10%.  

 